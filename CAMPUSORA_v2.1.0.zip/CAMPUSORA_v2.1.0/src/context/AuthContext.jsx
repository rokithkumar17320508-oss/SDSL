import React, { createContext, useContext, useState, useEffect } from 'react';
import { api } from '../services/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isDemoMode, setIsDemoMode] = useState(false);
  const [demoRole, setDemoRole] = useState('student');

  // Verify authentication on application mount
  useEffect(() => {
    async function checkAuth() {
      setIsLoading(true);
      try {
        const res = await api.getMe();
        if (res.ok && res.data && res.data.id) {
          setUser(res.data);
          setIsAuthenticated(true);
          setIsDemoMode(false);
          localStorage.removeItem('campusora_demo_active');
        } else {
          // Check if previously entered demo mode
          const demoActive = localStorage.getItem('campusora_demo_active') === 'true';
          const savedRole = localStorage.getItem('campusora_demo_role') || 'student';
          if (demoActive) {
            setIsDemoMode(true);
            setDemoRole(savedRole);
          } else {
            setUser(null);
            setIsAuthenticated(false);
            setIsDemoMode(false);
          }
        }
      } catch (err) {
        console.error('Failed to verify authentication status:', err);
        setIsAuthenticated(false);
      } finally {
        setIsLoading(false);
      }
    }

    checkAuth();
  }, []);

  const login = async (username, password) => {
    setIsLoading(true);
    try {
      const res = await api.login(username, password);
      if (res.ok && res.data && res.data.user) {
        setUser(res.data.user);
        setIsAuthenticated(true);
        setIsDemoMode(false);
        localStorage.removeItem('campusora_demo_active');
        localStorage.removeItem('campusora_demo_role');
        return { success: true, user: res.data.user };
      } else {
        const errorMsg =
          res.data?.detail ||
          res.data?.non_field_errors?.[0] ||
          res.error ||
          'Invalid credentials. Please verify your username and password.';
        return { success: false, error: errorMsg };
      }
    } catch (err) {
      return { success: false, error: err.message || 'Network error occurred during sign-in.' };
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    setIsLoading(true);
    try {
      if (isAuthenticated) {
        await api.logout();
      }
    } catch (err) {
      console.warn('Logout API error:', err);
    } finally {
      setUser(null);
      setIsAuthenticated(false);
      setIsDemoMode(false);
      localStorage.removeItem('campusora_demo_active');
      localStorage.removeItem('campusora_demo_role');
      setIsLoading(false);
    }
  };

  const enableDemoMode = (role = 'student') => {
    setUser(null);
    setIsAuthenticated(false);
    setIsDemoMode(true);
    setDemoRole(role);
    localStorage.setItem('campusora_demo_active', 'true');
    localStorage.setItem('campusora_demo_role', role);
  };

  const switchDemoRole = (role) => {
    if (isDemoMode) {
      setDemoRole(role);
      localStorage.setItem('campusora_demo_role', role);
    }
  };

  const exitDemoMode = () => {
    setIsDemoMode(false);
    localStorage.removeItem('campusora_demo_active');
    localStorage.removeItem('campusora_demo_role');
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        role: user ? user.role.toLowerCase() : (isDemoMode ? demoRole : null),
        isAuthenticated,
        isLoading,
        isDemoMode,
        demoRole,
        login,
        logout,
        enableDemoMode,
        switchDemoRole,
        exitDemoMode,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

export default AuthContext;
