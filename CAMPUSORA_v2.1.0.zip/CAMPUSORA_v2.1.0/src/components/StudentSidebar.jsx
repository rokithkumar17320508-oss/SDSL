import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  PlusCircle, 
  FileText, 
  QrCode, 
  User, 
  LogOut,
  X
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { BRAND } from '../config/branding';

const navItems = [
  { to: '/student', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/student/apply', label: 'Apply Leave', icon: PlusCircle },
  { to: '/student/applications', label: 'My Applications', icon: FileText },
  { to: '/student/gate-pass', label: 'Gate Pass', icon: QrCode },
  { to: '/student/profile', label: 'My Profile', icon: User },
];

export default function StudentSidebar({ onClose }) {
  const navigate = useNavigate();
  const { user, logout, isDemoMode } = useAuth();

  const handleLogout = async () => {
    if (onClose) onClose();
    await logout();
    navigate('/login');
  };

  const displayName = user?.name || (isDemoMode ? 'Arjun Sharma' : 'Student');
  const regNumber = user?.registration_number || (isDemoMode ? '2024CSE1084' : '');

  return (
    <aside className="w-64 bg-white border-r border-slate-200 h-full flex flex-col justify-between select-none">
      
      {/* Top Branding & Nav */}
      <div>
        {/* Brand Header */}
        <div className="h-16 px-6 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#2563EB]"></span>
            <span className="text-lg font-bold tracking-tight text-[#1E293B]">
              {BRAND.name}
            </span>
            <span className="text-[10px] font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
              Student
            </span>
          </div>

          {/* Close button for mobile drawer */}
          {onClose && (
            <button
              onClick={onClose}
              className="md:hidden p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-50"
              aria-label="Close sidebar"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Navigation Links */}
        <nav className="p-4 space-y-1.5">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                onClick={onClose}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                    isActive
                      ? 'bg-blue-50 text-[#2563EB] font-semibold shadow-subtle'
                      : 'text-slate-600 hover:text-[#1E293B] hover:bg-slate-50'
                  }`
                }
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{item.label}</span>
              </NavLink>
            );
          })}
        </nav>
      </div>

      {/* Bottom User Quick Info & Logout */}
      <div className="p-4 border-t border-slate-200 space-y-3">
        <div className="px-3 py-2 bg-slate-50 rounded-lg border border-slate-100">
          <p className="text-xs font-semibold text-[#1E293B] truncate">{displayName}</p>
          {regNumber && <p className="text-[11px] text-slate-500 font-mono truncate">{regNumber}</p>}
        </div>

        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm font-medium text-slate-600 hover:text-red-600 hover:bg-red-50/50 transition-colors"
        >
          <LogOut className="w-4 h-4 shrink-0" />
          <span>{isDemoMode ? 'Exit Demo Session' : 'Logout'}</span>
        </button>
      </div>

    </aside>
  );
}
