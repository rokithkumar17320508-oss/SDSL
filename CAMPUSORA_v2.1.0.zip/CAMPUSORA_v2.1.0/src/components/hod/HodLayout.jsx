import React, { useState } from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { Menu } from 'lucide-react';
import HodSidebar from './HodSidebar';
import DemoRoleSwitcher from '../DemoRoleSwitcher';
import NotificationBell from '../NotificationBell';
import { useAuth } from '../../context/AuthContext';
import { SAMPLE_HOD } from '../../data/studentData';
import { BRAND } from '../../config/branding';

export default function HodLayout() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const { user, isDemoMode } = useAuth();

  const getPageTitle = () => {
    if (location.pathname.startsWith('/hod/sections')) {
      return 'First Year CSE Student Directory';
    }
    switch (location.pathname) {
      case '/hod':
      case '/hod/dashboard':
        return 'HOD Executive Dashboard';
      case '/hod/approvals':
        return 'Pending Leave Authorizations';
      case '/hod/history':
        return 'Executive Decisions Archive';
      case '/hod/overview':
        return 'Department Mobility Analytics';
      case '/hod/profile':
        return 'HOD Profile';
      default:
        return 'HOD Portal';
    }
  };

  const displayName = user?.name || (isDemoMode ? SAMPLE_HOD.name : 'Head of Department');
  const displayDepartment = user?.department || SAMPLE_HOD.department;
  const initials = displayName
    .split(' ')
    .map((n) => n[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();

  return (
    <div className="min-h-screen flex bg-[#F8FAFC] text-[#1E293B]">
      
      {/* Desktop Static Sidebar */}
      <div className="hidden md:block w-64 shrink-0 h-screen sticky top-0">
        <HodSidebar />
      </div>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 md:hidden flex">
          <div
            className="fixed inset-0 bg-slate-900/30 backdrop-blur-sm"
            onClick={() => setMobileOpen(false)}
          ></div>
          <div className="relative z-10 w-64 h-full bg-white shadow-xl animate-in slide-in-from-left duration-200">
            <HodSidebar onClose={() => setMobileOpen(false)} />
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        
        {/* Top Navbar */}
        <header className="h-16 bg-white border-b border-slate-200 px-4 sm:px-6 lg:px-8 flex items-center justify-between sticky top-0 z-30">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileOpen(true)}
              className="md:hidden p-2 -ml-2 rounded-lg text-slate-600 hover:text-[#1E293B] hover:bg-slate-100"
              aria-label="Open navigation menu"
            >
              <Menu className="w-5 h-5" />
            </button>

            <div>
              <h1 className="text-base font-bold text-[#1E293B] leading-none">
                {getPageTitle()}
              </h1>
              <p className="text-[11px] text-slate-500 mt-0.5">
                {BRAND.name} • {displayDepartment}
              </p>
            </div>
          </div>

          {/* Right Header Badges */}
          <div className="flex items-center gap-3">
            {isDemoMode ? (
              <span className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-medium bg-amber-50 text-amber-800 border border-amber-200">
                <span className="w-1.5 h-1.5 rounded-full bg-[#EAB308]"></span>
                Demo Simulation
              </span>
            ) : (
              <span className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-medium bg-emerald-50 text-emerald-800 border border-emerald-200">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                PostgreSQL Authenticated
              </span>
            )}

            <NotificationBell />

            <Link
              to="/hod/profile"
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-200 text-xs font-semibold text-[#1E293B] transition-colors"
            >
              <span className="w-6 h-6 rounded-full bg-[#2563EB] text-white flex items-center justify-center text-[10px] font-bold">
                {initials}
              </span>
              <span className="hidden sm:inline">{displayName}</span>
            </Link>
          </div>
        </header>

        {/* Demo Switcher only in Demo Mode */}
        {isDemoMode && <DemoRoleSwitcher />}

        {/* Page Content */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-6xl w-full mx-auto">
          <Outlet />
        </main>

      </div>

    </div>
  );
}
