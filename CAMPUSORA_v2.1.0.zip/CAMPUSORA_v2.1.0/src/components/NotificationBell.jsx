import React, { useState, useEffect, useRef } from 'react';
import { Bell, Mail, MessageSquare, CheckCircle2, AlertCircle, Clock, ChevronDown, ChevronUp, RefreshCw, X } from 'lucide-react';
import { api } from '../services/api';

export default function NotificationBell() {
  const [isOpen, setIsOpen] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [summary, setSummary] = useState({ total: 0, sent: 0, failed: 0, pending: 0 });
  const [loading, setLoading] = useState(false);
  const [filterChannel, setFilterChannel] = useState('ALL');
  const [expandedId, setExpandedId] = useState(null);
  const dropdownRef = useRef(null);

  const fetchNotifications = async () => {
    setLoading(true);
    try {
      const [listRes, sumRes] = await Promise.all([
        api.getNotifications({ limit: 15 }),
        api.getNotificationSummary(),
      ]);

      if (listRes.ok && listRes.data) {
        const items = listRes.data.results || listRes.data;
        setNotifications(Array.isArray(items) ? items : []);
      }
      if (sumRes.ok && sumRes.data) {
        setSummary(sumRes.data);
      }
    } catch {
      // Graceful fallback
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNotifications();
    const interval = setInterval(fetchNotifications, 20000);
    return () => clearInterval(interval);
  }, []);

  // Click outside to close dropdown
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen]);

  const filteredNotifications = notifications.filter((n) => {
    if (filterChannel === 'EMAIL') return n.channel === 'EMAIL';
    if (filterChannel === 'SMS') return n.channel === 'SMS';
    return true;
  });

  const getStatusBadge = (status) => {
    switch (status) {
      case 'SENT':
        return (
          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <CheckCircle2 className="w-2.5 h-2.5" />
            Sent
          </span>
        );
      case 'FAILED':
        return (
          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-semibold bg-red-50 text-red-700 border border-red-200">
            <AlertCircle className="w-2.5 h-2.5" />
            Failed
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-semibold bg-amber-50 text-amber-700 border border-amber-200">
            <Clock className="w-2.5 h-2.5" />
            Pending
          </span>
        );
    }
  };

  const formatTimestamp = (ts) => {
    if (!ts) return '';
    try {
      const d = new Date(ts);
      return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ', ' + d.toLocaleDateString([], { month: 'short', day: 'numeric' });
    } catch {
      return ts;
    }
  };

  return (
    <div className="relative" ref={dropdownRef}>
      {/* Bell Trigger Button */}
      <button
        onClick={() => {
          setIsOpen(!isOpen);
          if (!isOpen) fetchNotifications();
        }}
        className="relative p-2 rounded-lg text-slate-600 hover:text-[#1E293B] hover:bg-slate-100 transition-colors"
        aria-label="Open notifications"
        title="Automated Notifications & Delivery Audit"
      >
        <Bell className="w-5 h-5" />
        {summary.total > 0 && (
          <span className="absolute top-1 right-1 flex h-4 w-4">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-4 w-4 bg-[#2563EB] text-white text-[9px] font-bold items-center justify-center">
              {summary.total > 9 ? '9+' : summary.total}
            </span>
          </span>
        )}
      </button>

      {/* Dropdown Panel */}
      {isOpen && (
        <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-xl shadow-2xl border border-slate-200 z-50 overflow-hidden animate-in fade-in slide-in-from-top-2 duration-150">
          {/* Header */}
          <div className="p-3.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#2563EB]"></span>
              <h3 className="text-xs font-bold text-[#1E293B] uppercase tracking-wider">
                Automated Alerts &amp; Logs
              </h3>
            </div>
            <div className="flex items-center gap-1.5">
              <button
                onClick={fetchNotifications}
                disabled={loading}
                className="p-1 text-slate-400 hover:text-slate-600 rounded"
                title="Refresh logs"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Channel Filters */}
          <div className="px-3 py-2 bg-white border-b border-slate-100 flex items-center justify-between text-xs">
            <div className="flex gap-1">
              {['ALL', 'EMAIL', 'SMS'].map((ch) => (
                <button
                  key={ch}
                  onClick={() => setFilterChannel(ch)}
                  className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                    filterChannel === ch
                      ? 'bg-blue-100 text-[#2563EB] font-bold'
                      : 'text-slate-500 hover:bg-slate-100'
                  }`}
                >
                  {ch}
                </button>
              ))}
            </div>
            <div className="text-[11px] text-slate-500">
              <span className="font-semibold text-emerald-600">{summary.sent}</span> sent
              {summary.failed > 0 && (
                <> • <span className="font-semibold text-red-600">{summary.failed}</span> failed</>
              )}
            </div>
          </div>

          {/* List Content */}
          <div className="max-h-80 overflow-y-auto divide-y divide-slate-100">
            {filteredNotifications.length === 0 ? (
              <div className="py-8 px-4 text-center">
                <Bell className="w-8 h-8 text-slate-300 mx-auto mb-2 stroke-[1.5]" />
                <p className="text-xs font-medium text-slate-600">No notification logs recorded yet</p>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Lifecycle events and departure alerts will appear here in real-time.
                </p>
              </div>
            ) : (
              filteredNotifications.map((notif) => {
                const isExpanded = expandedId === notif.id;
                const isEmail = notif.channel === 'EMAIL';
                const recipient = isEmail ? notif.recipient_email : notif.recipient_phone;

                return (
                  <div key={notif.id} className="p-3 hover:bg-slate-50/70 transition-colors text-xs">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {isEmail ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-200">
                            <Mail className="w-2.5 h-2.5" />
                            Email
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-purple-700 bg-purple-50 px-1.5 py-0.5 rounded border border-purple-200">
                            <MessageSquare className="w-2.5 h-2.5" />
                            SMS
                          </span>
                        )}
                        {getStatusBadge(notif.status)}
                      </div>
                      <span className="text-[10px] text-slate-400 shrink-0">
                        {formatTimestamp(notif.timestamp)}
                      </span>
                    </div>

                    <div className="mt-1.5">
                      <p className="font-semibold text-slate-800 leading-snug">
                        {notif.subject || notif.notification_type_display}
                      </p>
                      <p className="text-[11px] text-slate-500 mt-0.5 truncate">
                        To: <span className="font-medium text-slate-700">{recipient || notif.recipient_name}</span>
                        {notif.related_application_id && (
                          <span className="ml-1 text-slate-400">({notif.related_application_id})</span>
                        )}
                      </p>
                    </div>

                    {/* Expandable message details */}
                    {notif.message_body && (
                      <div className="mt-2">
                        <button
                          onClick={() => setExpandedId(isExpanded ? null : notif.id)}
                          className="flex items-center gap-1 text-[10px] font-medium text-[#2563EB] hover:underline"
                        >
                          <span>{isExpanded ? 'Hide message payload' : 'View message payload'}</span>
                          {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                        </button>

                        {isExpanded && (
                          <div className="mt-1.5 p-2 bg-slate-100/80 rounded border border-slate-200 text-[11px] font-mono text-slate-700 whitespace-pre-wrap max-h-36 overflow-y-auto leading-relaxed">
                            {notif.message_body}
                          </div>
                        )}
                      </div>
                    )}

                    {notif.status === 'FAILED' && notif.error_message && (
                      <div className="mt-1.5 p-1.5 bg-red-50 text-red-700 rounded text-[10px] border border-red-200">
                        <strong>Error:</strong> {notif.error_message}
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>

          {/* Footer note */}
          <div className="p-2.5 bg-slate-50 border-t border-slate-100 text-center">
            <span className="text-[10px] text-slate-400 font-medium">
              CAMPUSORA Automated Dispatch Engine • Day 8
            </span>
          </div>
        </div>
      )}
    </div>
  );
}
