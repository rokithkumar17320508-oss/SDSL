import React from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Loader2 } from 'lucide-react';

export default function ProtectedRoute({ allowedRoles = [] }) {
  const { user, isAuthenticated, isLoading, isDemoMode, demoRole } = useAuth();
  const location = useLocation();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F8FAFC]">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="w-8 h-8 text-[#2563EB] animate-spin" />
          <p className="text-xs font-medium text-slate-500">
            Verifying institutional credentials...
          </p>
        </div>
      </div>
    );
  }

  // 1. Authenticated Mode (Real Django JWT session)
  if (isAuthenticated && user) {
    const userRole = (user.role || '').toLowerCase();
    const isAuthorized = allowedRoles.map((r) => r.toLowerCase()).includes(userRole);

    if (isAuthorized) {
      return <Outlet />;
    }

    // Role mismatch: redirect to the user's own authorized dashboard
    const roleDashboardMap = {
      student: '/student',
      faculty: '/faculty',
      hod: '/hod',
      security: '/security',
    };
    const targetDashboard = roleDashboardMap[userRole] || '/login';
    return <Navigate to={targetDashboard} replace />;
  }

  // 2. Demo Mode (Development simulation workflow only)
  // In production builds, development-only demo bypass is strictly disabled (Requirement 6)
  if (isDemoMode && !import.meta.env.PROD) {
    const isAuthorizedDemo = allowedRoles.map((r) => r.toLowerCase()).includes(demoRole);
    if (isAuthorizedDemo) {
      return <Outlet />;
    }
    // Redirect to the active demo dashboard
    const demoDashboardMap = {
      student: '/student',
      faculty: '/faculty',
      hod: '/hod',
      security: '/security',
    };
    return <Navigate to={demoDashboardMap[demoRole] || '/student'} replace />;
  }

  // 3. Unauthenticated: Redirect to login
  return <Navigate to="/login" state={{ from: location }} replace />;
}
