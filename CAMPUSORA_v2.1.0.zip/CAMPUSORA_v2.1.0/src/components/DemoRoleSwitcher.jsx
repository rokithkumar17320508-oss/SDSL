import React from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import { GraduationCap, UserCheck, Building2, ShieldCheck, LogOut } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function DemoRoleSwitcher() {
  const location = useLocation();
  const navigate = useNavigate();
  const { switchDemoRole, exitDemoMode, isDemoMode, isAuthenticated } = useAuth();

  // Security guard (Requirements 3 & 6):
  // Never render in production or when a real PostgreSQL user is authenticated.
  // Cannot bypass real authentication or backend permissions.
  if (!isDemoMode || isAuthenticated || import.meta.env.PROD) {
    return null;
  }

  const isStudent = location.pathname.startsWith('/student');
  const isFaculty = location.pathname.startsWith('/faculty');
  const isHod = location.pathname.startsWith('/hod');
  const isSecurity = location.pathname.startsWith('/security');

  const handleRoleChange = (role, path) => {
    switchDemoRole(role);
    navigate(path);
  };

  const handleExitDemo = () => {
    exitDemoMode();
    navigate('/login');
  };

  return (
    <div className="bg-amber-50/60 border-b border-amber-200/80 px-4 py-2 select-none">
      <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
        
        {/* Left Indicator */}
        <div className="flex items-center gap-2 text-xs text-amber-900">
          <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
          <span className="font-semibold">Day 3 Demo Simulation:</span>
          <span className="hidden md:inline text-amber-700">
            Simulated localStorage state (Separate from PostgreSQL)
          </span>
        </div>

        {/* Role Pills & Exit */}
        <div className="flex items-center gap-1.5 bg-white p-1 rounded-lg border border-amber-200 text-xs shadow-subtle">
          {/* Student */}
          <button
            type="button"
            onClick={() => handleRoleChange('student', '/student')}
            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md font-medium transition-all ${
              isStudent
                ? 'bg-blue-50 text-[#2563EB] font-semibold border border-blue-200'
                : 'text-slate-600 hover:text-[#1E293B]'
            }`}
          >
            <GraduationCap className="w-3.5 h-3.5 text-[#2563EB]" />
            <span>Student</span>
          </button>

          {/* Faculty */}
          <button
            type="button"
            onClick={() => handleRoleChange('faculty', '/faculty/requests')}
            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md font-medium transition-all ${
              isFaculty
                ? 'bg-blue-50 text-blue-700 font-semibold border border-blue-200'
                : 'text-slate-600 hover:text-[#1E293B]'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5 text-blue-700" />
            <span>Faculty</span>
          </button>

          {/* HOD */}
          <button
            type="button"
            onClick={() => handleRoleChange('hod', '/hod/approvals')}
            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md font-medium transition-all ${
              isHod
                ? 'bg-purple-50 text-purple-700 font-semibold border border-purple-200'
                : 'text-slate-600 hover:text-[#1E293B]'
            }`}
          >
            <Building2 className="w-3.5 h-3.5 text-purple-700" />
            <span>HOD</span>
          </button>

          {/* Security */}
          <button
            type="button"
            onClick={() => handleRoleChange('security', '/security')}
            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md font-medium transition-all ${
              isSecurity
                ? 'bg-emerald-50 text-emerald-700 font-semibold border border-emerald-200'
                : 'text-slate-600 hover:text-[#1E293B]'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
            <span>Security</span>
          </button>

          {/* Exit Demo Mode */}
          <button
            type="button"
            onClick={handleExitDemo}
            className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors ml-1"
            title="Exit Demo Mode"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span className="hidden lg:inline text-[11px]">Exit Demo</span>
          </button>
        </div>

      </div>
    </div>
  );
}
