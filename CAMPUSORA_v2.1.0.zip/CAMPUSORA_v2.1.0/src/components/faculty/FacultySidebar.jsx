import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Inbox, 
  History, 
  User, 
  LogOut,
  X
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { BRAND } from '../../config/branding';
import { SAMPLE_FACULTY } from '../../data/studentData';

const navItems = [
  { to: '/faculty', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/faculty/requests', label: 'Leave Requests', icon: Inbox },
  { to: '/faculty/history', label: 'Approval History', icon: History },
  { to: '/faculty/profile', label: 'My Profile', icon: User },
];

export default function FacultySidebar({ onClose }) {
  const navigate = useNavigate();
  const { user, logout, isDemoMode } = useAuth();

  const handleLogout = async () => {
    if (onClose) onClose();
    await logout();
    navigate('/login');
  };

  const displayName = user?.name || (isDemoMode ? SAMPLE_FACULTY.name : 'Faculty Advisor');
  const employeeId = user?.employee_id || (isDemoMode ? SAMPLE_FACULTY.employeeId : '');

  return (
    <aside className="w-64 bg-white border-r border-slate-200 h-full flex flex-col justify-between select-none">
      
      {/* Top Branding & Navigation */}
      <div>
        {/* Brand Header */}
        <div className="h-16 px-6 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#2563EB]"></span>
            <span className="text-lg font-bold tracking-tight text-[#1E293B]">
              {BRAND.name}
            </span>
            <span className="text-[10px] font-semibold text-blue-700 bg-blue-50 border border-blue-200 px-2 py-0.5 rounded">
              Faculty
            </span>
          </div>

          {/* Close button for mobile drawer */}
          {onClose && (
            <button
              onClick={onClose}
              className="md:hidden p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-50"
              aria-label="Close sidebar"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Navigation Links */}
        <nav className="p-4 space-y-1.5">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                onClick={onClose}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                    isActive
                      ? 'bg-blue-50 text-[#2563EB] font-semibold shadow-subtle'
                      : 'text-slate-600 hover:text-[#1E293B] hover:bg-slate-50'
                  }`
                }
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{item.label}</span>
              </NavLink>
            );
          })}
        </nav>
      </div>

      {/* Bottom Faculty Quick Info & Logout */}
      <div className="p-4 border-t border-slate-200 space-y-3">
        <div className="px-3 py-2 bg-slate-50 rounded-lg border border-slate-100">
          <p className="text-xs font-semibold text-[#1E293B] truncate">{displayName}</p>
          {employeeId && <p className="text-[11px] text-slate-500 font-mono truncate">{employeeId}</p>}
        </div>

        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm font-medium text-slate-600 hover:text-red-600 hover:bg-red-50/50 transition-colors"
        >
          <LogOut className="w-4 h-4 shrink-0" />
          <span>{isDemoMode ? 'Exit Demo Session' : 'Logout'}</span>
        </button>
      </div>

    </aside>
  );
}
