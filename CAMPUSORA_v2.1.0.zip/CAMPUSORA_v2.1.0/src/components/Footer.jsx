import React from 'react';
import { Link } from 'react-router-dom';
import { BRAND } from '../config/branding';

export default function Footer() {
  return (
    <footer className="bg-white border-t border-slate-200 mt-auto">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#2563EB]"></span>
            <span className="font-bold text-[#1E293B] text-sm tracking-tight">{BRAND.name}</span>
            <span className="text-xs text-slate-400">— {BRAND.tagline}</span>
          </div>

          <div className="flex items-center gap-6 text-xs text-slate-500">
            <Link to="/" className="hover:text-[#1E293B] transition-colors">Home</Link>
            <Link to="/login" className="hover:text-[#1E293B] transition-colors">Sign In</Link>
            <span>•</span>
            <span>© {new Date().getFullYear()} {BRAND.name}</span>
          </div>

        </div>
      </div>
    </footer>
  );
}
