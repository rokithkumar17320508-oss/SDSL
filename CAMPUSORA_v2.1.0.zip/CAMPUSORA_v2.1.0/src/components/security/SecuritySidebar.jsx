import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  ShieldCheck, 
  ScanLine, 
  ClipboardList, 
  UserCheck, 
  LogOut,
  Building,
  Users,
  BarChart3,
  X
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { BRAND } from '../../config/branding';

const navItems = [
  { name: 'Security Terminal', path: '/security', icon: ShieldCheck, exact: true },
  { name: 'Gate Scanner', path: '/security/scanner', icon: ScanLine },
  { name: 'Off-Campus & Overdue', path: '/security/outside', icon: Users },
  { name: 'Movement Logs', path: '/security/logs', icon: ClipboardList },
  { name: 'Gate Analytics', path: '/security/analytics', icon: BarChart3 },
  { name: 'Guard Profile', path: '/security/profile', icon: UserCheck },
];

export default function SecuritySidebar({ onClose }) {
  const { logout, isDemoMode } = useAuth();

  return (
    <aside className="w-64 h-full bg-white border-r border-slate-200 flex flex-col justify-between select-none">
      
      {/* Top Branding Section */}
      <div>
        <div className="h-16 px-6 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#2563EB] flex items-center justify-center text-white shadow-subtle">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-sm tracking-tight text-[#1E293B] block">
                {BRAND.name}
              </span>
              <span className="text-[10px] text-slate-500 font-medium block -mt-0.5">
                Security Checkpoint
              </span>
            </div>
          </div>

          {onClose && (
            <button
              onClick={onClose}
              className="md:hidden p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
              aria-label="Close sidebar"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Navigation Items */}
        <div className="px-3 py-4">
          <p className="px-3 mb-2 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
            Main Gate Operations
          </p>
          <nav className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <NavLink
                  key={item.path}
                  to={item.path}
                  end={item.exact}
                  onClick={onClose}
                  className={({ isActive }) =>
                    `flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-medium transition-colors ${
                      isActive
                        ? 'bg-blue-50 text-[#2563EB] font-semibold'
                        : 'text-slate-600 hover:text-[#1E293B] hover:bg-slate-50'
                    }`
                  }
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{item.name}</span>
                </NavLink>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Footer Info & Logout */}
      <div className="p-3 border-t border-slate-200 space-y-1">
        <button
          onClick={logout}
          className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-medium text-red-600 hover:bg-red-50 transition-colors"
        >
          <LogOut className="w-4 h-4 shrink-0" />
          <span>{isDemoMode ? 'Exit Demo Session' : 'Sign Out'}</span>
        </button>

        <div className="px-3 pt-2 text-[10px] text-slate-400 flex items-center gap-1.5">
          <Building className="w-3 h-3 shrink-0" />
          <span>Gate 1 • Central Campus</span>
        </div>
      </div>

    </aside>
  );
}
