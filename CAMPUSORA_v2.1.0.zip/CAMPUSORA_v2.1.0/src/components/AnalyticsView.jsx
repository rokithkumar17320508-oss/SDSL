import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  Users, 
  DoorOpen, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  Calendar, 
  TrendingUp, 
  ShieldCheck, 
  Building,
  RefreshCw,
  ArrowUpRight,
  ArrowDownLeft,
  PieChart
} from 'lucide-react';
import { api } from '../services/api';

export default function AnalyticsView({ title = "Campus Mobility & Curfew Analytics", subtitle }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchAnalytics = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.getAnalyticsOverview();
      if (res.ok && res.data) {
        setData(res.data);
      } else {
        throw new Error(res.data?.detail || res.error || 'Failed to fetch analytics.');
      }
    } catch (err) {
      console.error('Analytics error:', err);
      setError(err.message || 'Unable to retrieve analytics at this time.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAnalytics();
  }, []);

  if (loading) {
    return (
      <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center shadow-card space-y-3">
        <RefreshCw className="w-8 h-8 text-[#2563EB] animate-spin mx-auto" />
        <p className="text-sm font-semibold text-slate-700">Loading campus mobility intelligence...</p>
        <p className="text-xs text-slate-400">Aggregating PostgreSQL leave records and checkpoint logs.</p>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="bg-white border border-red-200 rounded-2xl p-8 text-center shadow-card space-y-3">
        <AlertTriangle className="w-8 h-8 text-red-500 mx-auto" />
        <p className="text-sm font-bold text-red-700">Unable to Load Analytics</p>
        <p className="text-xs text-slate-500">{error || 'Data unavailable.'}</p>
        <button
          onClick={fetchAnalytics}
          className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#2563EB] text-white rounded-lg text-xs font-semibold hover:bg-blue-700 transition-colors"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Retry</span>
        </button>
      </div>
    );
  }

  const apps = data.applications || {};
  const offCampus = data.off_campus || {};
  const dailyStats = data.daily_stats || [];
  const monthlyStats = data.monthly_stats || [];
  const leaveDist = data.leave_distribution || {};
  const gateBreakdown = data.gate_breakdown || {};

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-[#1E293B] flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-[#2563EB]" />
            <span>{title}</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {subtitle || `Scope: ${data.scope} • Real-time synchronization with PostgreSQL 18`}
          </p>
        </div>

        <button
          onClick={fetchAnalytics}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold transition-colors self-start sm:self-auto"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Refresh</span>
        </button>
      </div>

      {/* 4 Core Metric KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Total Applications */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-card hover:border-slate-300 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Leave Applications</span>
            <span className="p-2 bg-blue-50 text-[#2563EB] rounded-lg">
              <Users className="w-4 h-4" />
            </span>
          </div>
          <p className="text-2xl font-bold text-[#1E293B] mt-2">{apps.total || 0}</p>
          <div className="mt-2 flex items-center justify-between text-[11px] text-slate-500">
            <span>Approved: <strong className="text-emerald-600">{apps.approved || 0}</strong></span>
            <span>Pending: <strong className="text-amber-600">{(apps.pending_faculty || 0) + (apps.pending_hod || 0)}</strong></span>
          </div>
        </div>

        {/* Off-Campus Students */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-card hover:border-slate-300 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Outside Campus</span>
            <span className="p-2 bg-amber-50 text-amber-600 rounded-lg">
              <ArrowUpRight className="w-4 h-4" />
            </span>
          </div>
          <p className="text-2xl font-bold text-amber-600 mt-2">{offCampus.students_outside || 0}</p>
          <p className="text-[11px] text-slate-400 mt-2">
            Active gate passes in <strong className="text-slate-600">USED</strong> state
          </p>
        </div>

        {/* Returned Students */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-card hover:border-slate-300 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Students Returned</span>
            <span className="p-2 bg-emerald-50 text-emerald-600 rounded-lg">
              <ArrowDownLeft className="w-4 h-4" />
            </span>
          </div>
          <p className="text-2xl font-bold text-emerald-600 mt-2">{offCampus.students_returned || 0}</p>
          <p className="text-[11px] text-slate-400 mt-2">
            Return entry confirmed at security gate
          </p>
        </div>

        {/* Overdue Students */}
        <div className={`border rounded-xl p-5 shadow-card transition-colors ${
          offCampus.overdue_count > 0 
            ? 'bg-red-50/40 border-red-200' 
            : 'bg-white border-slate-200'
        }`}>
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Curfew Overdue</span>
            <span className={`p-2 rounded-lg ${
              offCampus.overdue_count > 0 ? 'bg-red-100 text-red-600' : 'bg-slate-100 text-slate-500'
            }`}>
              <AlertTriangle className="w-4 h-4" />
            </span>
          </div>
          <p className={`text-2xl font-bold mt-2 ${
            offCampus.overdue_count > 0 ? 'text-red-600' : 'text-[#1E293B]'
          }`}>
            {offCampus.overdue_count || 0}
          </p>
          <p className="text-[11px] text-slate-400 mt-2">
            {offCampus.overdue_count > 0 ? (
              <span className="text-red-700 font-semibold">Immediate safety attention required</span>
            ) : (
              <span>All off-campus students within curfew</span>
            )}
          </p>
        </div>

      </div>

      {/* Overdue Students Detailed Alert List (If any exist) */}
      {offCampus.overdue_students && offCampus.overdue_students.length > 0 && (
        <div className="bg-white border border-red-200 rounded-2xl p-5 shadow-card space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-red-600 animate-ping"></span>
              <h3 className="text-sm font-bold text-red-700">
                Action Required: {offCampus.overdue_students.length} Overdue Student(s) Exceeded Curfew
              </h3>
            </div>
            <span className="text-[11px] font-semibold text-red-700 bg-red-50 border border-red-200 px-2 py-0.5 rounded-full">
              Past Curfew
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-slate-200 text-slate-400 font-semibold">
                  <th className="pb-2">Student</th>
                  <th className="pb-2">Reg No</th>
                  <th className="pb-2">Department</th>
                  <th className="pb-2">Hostel &amp; Room</th>
                  <th className="pb-2">Curfew Deadline</th>
                  <th className="pb-2 text-right">Time Overdue</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {offCampus.overdue_students.map((st) => (
                  <tr key={st.pass_id} className="hover:bg-red-50/30">
                    <td className="py-2.5 font-bold text-[#1E293B]">{st.student_name}</td>
                    <td className="py-2.5 font-mono text-slate-500">{st.registration_number}</td>
                    <td className="py-2.5 text-slate-600">{st.department}</td>
                    <td className="py-2.5 text-slate-600">
                      {st.hostel_block ? `${st.hostel_block} (${st.room_number})` : 'Day Scholar'}
                    </td>
                    <td className="py-2.5 font-mono text-slate-600">
                      {st.expected_return_time ? new Date(st.expected_return_time).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' }) : 'N/A'}
                    </td>
                    <td className="py-2.5 text-right font-bold text-red-600">
                      {st.minutes_overdue} mins late
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Movement Trends & Checkpoint Gate Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Daily Movements (Last 7 Days) */}
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-2xl p-6 shadow-card space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-[#1E293B] flex items-center gap-2">
              <Calendar className="w-4 h-4 text-[#2563EB]" />
              <span>Gate Movement History (Last 7 Days)</span>
            </h3>
            <span className="text-[11px] text-slate-400 font-medium">Exits vs Return Entries</span>
          </div>

          <div className="space-y-3">
            {dailyStats.map((day) => {
              const maxMovements = Math.max(...dailyStats.map(d => d.total_movements || 1), 5);
              const exitWidth = Math.min(100, (day.exits / maxMovements) * 100);
              const entryWidth = Math.min(100, (day.entries / maxMovements) * 100);

              return (
                <div key={day.date} className="p-3 bg-slate-50/60 rounded-xl border border-slate-100 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-700">{day.label}</span>
                    <div className="flex items-center gap-3 text-[11px]">
                      <span className="text-blue-600 font-semibold">{day.exits} exits</span>
                      <span>•</span>
                      <span className="text-emerald-600 font-semibold">{day.entries} entries</span>
                    </div>
                  </div>

                  {/* Horizontal mini bar */}
                  <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden flex">
                    <div 
                      style={{ width: `${exitWidth}%` }} 
                      className="bg-[#2563EB] h-full"
                      title={`${day.exits} exits`}
                    ></div>
                    <div 
                      style={{ width: `${entryWidth}%` }} 
                      className="bg-emerald-500 h-full"
                      title={`${day.entries} entries`}
                    ></div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Checkpoint Gates & Leave Distribution Column */}
        <div className="space-y-6">
          
          {/* Checkpoint Gate Breakdown */}
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-card space-y-4">
            <h3 className="text-sm font-bold text-[#1E293B] flex items-center gap-2">
              <DoorOpen className="w-4 h-4 text-[#2563EB]" />
              <span>Checkpoint Traffic</span>
            </h3>

            <div className="space-y-3">
              {Object.keys(gateBreakdown).length === 0 ? (
                <p className="text-xs text-slate-400 text-center py-4">No checkpoint events recorded yet.</p>
              ) : (
                Object.entries(gateBreakdown).map(([gate, counts]) => (
                  <div key={gate} className="p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs">
                    <p className="font-bold text-[#1E293B] truncate">{gate}</p>
                    <div className="mt-1 flex items-center justify-between text-[11px] text-slate-500">
                      <span>Exits: <strong className="text-blue-600 font-bold">{counts.exits || 0}</strong></span>
                      <span>Entries: <strong className="text-emerald-600 font-bold">{counts.entries || 0}</strong></span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Leave Category Distribution */}
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-card space-y-4">
            <h3 className="text-sm font-bold text-[#1E293B] flex items-center gap-2">
              <PieChart className="w-4 h-4 text-[#2563EB]" />
              <span>Leave Categories</span>
            </h3>

            <div className="space-y-2 text-xs">
              {Object.entries(leaveDist).map(([category, count]) => (
                <div key={category} className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-100">
                  <span className="text-slate-600 font-medium">{category}</span>
                  <span className="font-bold text-[#1E293B] bg-white px-2 py-0.5 rounded border border-slate-200">
                    {count}
                  </span>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
