import React from 'react';
import { User, Mail, Phone, Building2, BookOpen, ShieldCheck, GraduationCap } from 'lucide-react';
import { SAMPLE_FACULTY } from '../../data/studentData';
import { BRAND } from '../../config/branding';

export default function FacultyProfilePage() {
  return (
    <div className="max-w-2xl mx-auto space-y-6">
      
      {/* Profile Overview Card */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-subtle flex flex-col sm:flex-row items-center sm:items-start gap-5">
        <div className="w-16 h-16 rounded-2xl bg-blue-50 border border-blue-100 flex items-center justify-center text-[#2563EB] text-xl font-bold shrink-0">
          SV
        </div>

        <div className="space-y-1 text-center sm:text-left flex-1">
          <div className="flex flex-col sm:flex-row sm:items-center gap-2">
            <h2 className="text-lg font-bold text-[#1E293B]">{SAMPLE_FACULTY.name}</h2>
            <span className="inline-block text-xs font-mono font-medium text-slate-500 bg-slate-100 px-2 py-0.5 rounded w-max mx-auto sm:mx-0">
              {SAMPLE_FACULTY.employeeId}
            </span>
          </div>
          <p className="text-xs text-slate-500">
            {SAMPLE_FACULTY.designation} • {SAMPLE_FACULTY.department}
          </p>
          <div className="pt-2 flex items-center justify-center sm:justify-start gap-2">
            <span className="text-[11px] font-medium text-blue-700 bg-blue-50 border border-blue-200 px-2.5 py-0.5 rounded-full">
              Class Advisor Desk
            </span>
            <span className="text-[11px] font-medium text-slate-600 bg-slate-100 px-2.5 py-0.5 rounded-full">
              {SAMPLE_FACULTY.assignedClass}
            </span>
          </div>
        </div>
      </div>

      {/* Departmental & Academic Details */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-subtle p-6 space-y-4">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
          Academic Responsibilities
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
            <span className="text-slate-400 text-[11px] flex items-center gap-1.5 mb-1">
              <Building2 className="w-3.5 h-3.5 text-[#2563EB]" />
              <span>Department</span>
            </span>
            <p className="font-semibold text-[#1E293B]">{SAMPLE_FACULTY.department}</p>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
            <span className="text-slate-400 text-[11px] flex items-center gap-1.5 mb-1">
              <GraduationCap className="w-3.5 h-3.5 text-[#2563EB]" />
              <span>Mentorship Assignment</span>
            </span>
            <p className="font-semibold text-[#1E293B]">{SAMPLE_FACULTY.assignedClass}</p>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 sm:col-span-2">
            <span className="text-slate-400 text-[11px] flex items-center gap-1.5 mb-1">
              <BookOpen className="w-3.5 h-3.5 text-[#2563EB]" />
              <span>Faculty Role in Clearance Workflow</span>
            </span>
            <p className="text-slate-600 leading-relaxed text-[11px]">
              First-stage clearance authority. Verifies student lab requirements, attendance thresholds (minimum 75%), and parental consent before endorsing applications to the HOD Desk.
            </p>
          </div>

        </div>
      </div>

      {/* Contact & Office Location */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-subtle p-6 space-y-4">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
          Contact Information & Office
        </h3>

        <div className="space-y-3 text-xs">
          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100">
            <span className="text-slate-500 flex items-center gap-2">
              <Mail className="w-4 h-4 text-slate-400" />
              <span>Official Email</span>
            </span>
            <span className="font-medium text-[#1E293B]">{SAMPLE_FACULTY.email}</span>
          </div>

          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100">
            <span className="text-slate-500 flex items-center gap-2">
              <Phone className="w-4 h-4 text-slate-400" />
              <span>Intercom / Phone</span>
            </span>
            <span className="font-medium text-[#1E293B]">{SAMPLE_FACULTY.phone}</span>
          </div>

          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100">
            <span className="text-slate-500 flex items-center gap-2">
              <Building2 className="w-4 h-4 text-slate-400" />
              <span>Office Location</span>
            </span>
            <span className="font-medium text-[#1E293B]">{SAMPLE_FACULTY.officeRoom}</span>
          </div>
        </div>
      </div>

    </div>
  );
}
