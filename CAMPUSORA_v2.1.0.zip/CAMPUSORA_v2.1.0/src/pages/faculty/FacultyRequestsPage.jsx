import React, { useState, useEffect } from 'react';
import { 
  Inbox, 
  Search, 
  Filter, 
  Check, 
  X, 
  Eye, 
  AlertCircle, 
  CheckCircle2, 
  Send,
  User,
  Calendar,
  Percent,
  RefreshCw,
  Loader2,
  Database
} from 'lucide-react';
import { getStoredApplications, updateApplicationStatus } from '../../data/studentData';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';

export default function FacultyRequestsPage() {
  const { isAuthenticated, isDemoMode } = useAuth();
  const [applications, setApplications] = useState([]);
  const [filter, setFilter] = useState('Pending Faculty Review');
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);

  // Modal & Confirmation States
  const [selectedApp, setSelectedApp] = useState(null);
  const [actionType, setActionType] = useState(null); // 'approve' | 'reject' | 'view'
  const [remarks, setRemarks] = useState('');
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [validationError, setValidationError] = useState('');
  const [successToast, setSuccessToast] = useState('');

  const loadData = async () => {
    setLoading(true);
    try {
      if (isAuthenticated) {
        const res = await api.getApplications();
        if (res.ok && res.data) {
          const list = Array.isArray(res.data) ? res.data : (res.data.results || []);
          setApplications(list);
        } else {
          setApplications([]);
        }
      } else {
        setApplications(getStoredApplications());
      }
    } catch (err) {
      console.error('Failed to load faculty applications:', err);
      setApplications([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [isAuthenticated, isDemoMode]);

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Pending Faculty Review':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-amber-50 text-amber-800 border border-amber-200">
            Pending Review
          </span>
        );
      case 'Pending HOD Review':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-blue-50 text-[#2563EB] border border-blue-200">
            Forwarded to HOD
          </span>
        );
      case 'HOD Approved':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
            HOD Approved
          </span>
        );
      case 'Rejected':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-red-50 text-red-700 border border-red-200">
            Rejected
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-slate-100 text-slate-700">
            {status}
          </span>
        );
    }
  };

  const handleOpenAction = (app, type) => {
    setSelectedApp(app);
    setActionType(type);
    setRemarks(
      type === 'approve'
        ? `Attendance verified (${app.attendance || 85}%). Recommended for leave clearance.`
        : ''
    );
    setValidationError('');
    setShowConfirmModal(true);
  };

  const handleConfirmAction = async () => {
    if (actionType === 'reject' && !remarks.trim()) {
      setValidationError('Please provide a mandatory reason for rejecting this leave application.');
      return;
    }

    setIsProcessing(true);
    setValidationError('');
    try {
      if (isAuthenticated) {
        if (actionType === 'approve') {
          const res = await api.forwardApplication(selectedApp.id, remarks.trim());
          if (res.ok) {
            setSuccessToast(`Application ${selectedApp.id} approved and forwarded to HOD approval queue.`);
            setShowConfirmModal(false);
            setSelectedApp(null);
            setRemarks('');
            loadData();
          } else {
            setValidationError(res.data?.detail || 'Failed to forward application.');
            return;
          }
        } else if (actionType === 'reject') {
          const res = await api.rejectApplication(selectedApp.id, remarks.trim());
          if (res.ok) {
            setSuccessToast(`Application ${selectedApp.id} has been rejected.`);
            setShowConfirmModal(false);
            setSelectedApp(null);
            setRemarks('');
            loadData();
          } else {
            setValidationError(res.data?.detail || 'Failed to reject application.');
            return;
          }
        }
      } else {
        const newStatus = actionType === 'approve' ? 'Pending HOD Review' : 'Rejected';
        updateApplicationStatus(selectedApp.id, newStatus, remarks.trim(), 'faculty');

        setSuccessToast(
          actionType === 'approve'
            ? `Application ${selectedApp.id} approved and forwarded to HOD approval queue.`
            : `Application ${selectedApp.id} has been rejected.`
        );

        setShowConfirmModal(false);
        setSelectedApp(null);
        setRemarks('');
        loadData();
      }
    } catch (err) {
      setValidationError(err.message || 'Operation failed. Please retry.');
      return;
    } finally {
      setIsProcessing(false);
    }

    setTimeout(() => setSuccessToast(''), 4000);
  };

  const filteredApps = applications.filter((app) => {
    const matchesFilter =
      filter === 'All' ||
      (filter === 'Pending Faculty Review' && app.status === 'Pending Faculty Review') ||
      (filter === 'Forwarded to HOD' && (app.status === 'Pending HOD Review' || app.status === 'HOD Approved')) ||
      (filter === 'Rejected' && app.status === 'Rejected');

    const matchesSearch =
      app.id.toLowerCase().includes(search.toLowerCase()) ||
      app.studentName.toLowerCase().includes(search.toLowerCase()) ||
      app.regNo.toLowerCase().includes(search.toLowerCase()) ||
      app.type.toLowerCase().includes(search.toLowerCase()) ||
      app.reason.toLowerCase().includes(search.toLowerCase());

    return matchesFilter && matchesSearch;
  });

  return (
    <div className="space-y-6">
      
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-[#1E293B]">Student Leave Requests</h2>
          <p className="text-xs text-slate-500">
            Review student leave applications, check attendance, and forward endorsed passes to the HOD.
          </p>
        </div>

        <button
          onClick={loadData}
          disabled={loading}
          title="Refresh applications"
          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold text-slate-600 bg-white border border-slate-200 hover:bg-slate-50 transition-colors shadow-subtle shrink-0 self-start sm:self-auto disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh</span>
        </button>
      </div>

      {/* Success Toast */}
      {successToast && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs p-3.5 rounded-xl flex items-center justify-between shadow-subtle animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{successToast}</span>
          </div>
          <button onClick={() => setSuccessToast('')} className="text-emerald-600 hover:text-emerald-800">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-3 shadow-subtle flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
          {[
            { id: 'Pending Faculty Review', label: 'Pending Review' },
            { id: 'Forwarded to HOD', label: 'Forwarded / Cleared' },
            { id: 'Rejected', label: 'Rejected' },
            { id: 'All', label: 'All Requests' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilter(tab.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors shrink-0 ${
                filter === tab.id
                  ? 'bg-blue-50 text-[#2563EB] font-semibold'
                  : 'text-slate-600 hover:text-[#1E293B] hover:bg-slate-50'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-72">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search student, Reg No, or pass ID..."
            className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-[#1E293B] placeholder-slate-400 focus:outline-none focus:border-[#2563EB] focus:bg-white"
          />
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
        </div>
      </div>

      {/* Applications Table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-subtle overflow-hidden">
        {loading ? (
          <div className="p-12 text-center space-y-2">
            <Loader2 className="w-8 h-8 text-[#2563EB] animate-spin mx-auto" />
            <p className="text-xs text-slate-500">Loading student requests from PostgreSQL...</p>
          </div>
        ) : filteredApps.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-500">
            No leave requests found matching this filter criteria.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-medium">
                <tr>
                  <th className="px-5 py-3">ID</th>
                  <th className="px-5 py-3">Student Name</th>
                  <th className="px-5 py-3">Reg Number</th>
                  <th className="px-5 py-3">Leave Type</th>
                  <th className="px-5 py-3">Leave Dates</th>
                  <th className="px-5 py-3">Reason</th>
                  <th className="px-5 py-3">Status</th>
                  <th className="px-5 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {filteredApps.map((app) => (
                  <tr key={app.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-5 py-3.5 font-mono font-semibold text-slate-700">
                      {app.id}
                    </td>
                    <td className="px-5 py-3.5 font-semibold text-[#1E293B]">
                      {app.studentName}
                    </td>
                    <td className="px-5 py-3.5 font-mono text-slate-500 text-[11px]">
                      {app.regNo}
                    </td>
                    <td className="px-5 py-3.5 font-medium text-slate-800">
                      {app.type}
                    </td>
                    <td className="px-5 py-3.5 text-slate-600">
                      {app.startDate === app.endDate ? app.startDate : `${app.startDate} — ${app.endDate}`}
                    </td>
                    <td className="px-5 py-3.5 text-slate-600 max-w-xs truncate" title={app.reason}>
                      {app.reason}
                    </td>
                    <td className="px-5 py-3.5">
                      {getStatusBadge(app.status)}
                    </td>
                    <td className="px-5 py-3.5 text-right whitespace-nowrap">
                      <div className="inline-flex items-center gap-1.5">
                        {/* View Details Button */}
                        <button
                          onClick={() => {
                            setSelectedApp(app);
                            setActionType('view');
                            setShowConfirmModal(true);
                          }}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-[#1E293B] hover:bg-slate-100"
                          title="View Details"
                        >
                          <Eye className="w-4 h-4" />
                        </button>

                        {/* Review Action Buttons (Only enabled when Pending Faculty Review) */}
                        {app.status === 'Pending Faculty Review' && (
                          <>
                            <button
                              onClick={() => handleOpenAction(app, 'approve')}
                              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-semibold text-white bg-[#2563EB] hover:bg-[#1D4ED8] transition-colors"
                              title="Approve and forward to HOD"
                            >
                              <Check className="w-3.5 h-3.5" />
                              <span>Approve</span>
                            </button>

                            <button
                              onClick={() => handleOpenAction(app, 'reject')}
                              className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-[11px] font-semibold text-red-700 bg-red-50 hover:bg-red-100 border border-red-200 transition-colors"
                              title="Reject Application"
                            >
                              <X className="w-3.5 h-3.5" />
                              <span>Reject</span>
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Confirmation & Details Modal */}
      {showConfirmModal && selectedApp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs transition-opacity"
            onClick={() => setShowConfirmModal(false)}
          ></div>

          <div className="relative bg-white rounded-2xl border border-slate-200 shadow-xl max-w-lg w-full p-6 space-y-5 animate-in fade-in zoom-in-95 duration-150">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-base font-bold text-[#1E293B]">
                  {actionType === 'view'
                    ? 'Application Details'
                    : actionType === 'approve'
                    ? 'Confirm Approval & Forward to HOD'
                    : 'Confirm Rejection'}
                </h3>
                <p className="text-xs text-slate-500 font-mono">
                  {selectedApp.id} • {selectedApp.type}
                </p>
              </div>
              <button
                onClick={() => setShowConfirmModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Student Info Card Inside Modal */}
            <div className="bg-slate-50 border border-slate-100 rounded-xl p-4 space-y-2 text-xs">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="text-slate-400 text-[11px]">Student Name</span>
                  <p className="font-semibold text-[#1E293B]">{selectedApp.studentName}</p>
                </div>
                <div>
                  <span className="text-slate-400 text-[11px]">Registration Number</span>
                  <p className="font-mono font-semibold text-[#1E293B]">{selectedApp.regNo}</p>
                </div>
                <div>
                  <span className="text-slate-400 text-[11px]">Department & Section</span>
                  <p className="font-medium text-[#1E293B]">{selectedApp.department}</p>
                </div>
                <div>
                  <span className="text-slate-400 text-[11px]">Academic Attendance</span>
                  <p className="font-semibold text-emerald-600">{selectedApp.attendance || 87.5}%</p>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-200">
                <span className="text-slate-400 text-[11px]">Requested Leave Dates</span>
                <p className="font-medium text-[#1E293B]">
                  {selectedApp.startDate} to {selectedApp.endDate}
                </p>
              </div>

              <div>
                <span className="text-slate-400 text-[11px]">Reason for Leave</span>
                <p className="text-slate-700 bg-white p-2.5 rounded-lg border border-slate-200 mt-0.5">
                  {selectedApp.reason}
                </p>
              </div>

              {selectedApp.facultyRemarks && (
                <div>
                  <span className="text-slate-400 text-[11px]">Faculty Endorsement Remark</span>
                  <p className="text-blue-900 bg-blue-50 p-2 rounded-lg border border-blue-200 mt-0.5">
                    {selectedApp.facultyRemarks}
                  </p>
                </div>
              )}
            </div>

            {/* Remarks Input if Action is Approve or Reject */}
            {actionType !== 'view' && (
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-[#1E293B]">
                  {actionType === 'approve'
                    ? 'Faculty Recommendation Remark (Optional)'
                    : 'Reason for Rejection (Mandatory) *'}
                </label>
                <textarea
                  rows={2}
                  value={remarks}
                  onChange={(e) => {
                    setRemarks(e.target.value);
                    if (validationError) setValidationError('');
                  }}
                  placeholder={
                    actionType === 'approve'
                      ? 'Add any remarks for the HOD desk...'
                      : 'Specify academic or policy reason for rejecting this leave...'
                  }
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-lg text-[#1E293B] placeholder-slate-400 focus:outline-none focus:border-[#2563EB]"
                ></textarea>
                {validationError && (
                  <p className="text-[11px] text-red-600 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>{validationError}</span>
                  </p>
                )}
              </div>
            )}

            {/* Advisory Notice */}
            {isAuthenticated ? (
              <div className="p-2.5 rounded-lg bg-emerald-50 border border-emerald-200 text-[11px] text-emerald-900 leading-snug flex items-start gap-2">
                <Database className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <strong className="font-semibold">PostgreSQL Workflow: </strong>
                  Your decision and remarks will be recorded in an immutable audit log and the status updated in the live PostgreSQL database.
                </div>
              </div>
            ) : (
              <div className="p-2.5 rounded-lg bg-amber-50 border border-amber-200 text-[11px] text-amber-900 leading-snug">
                <strong className="font-semibold">Prototype Simulation Notice: </strong>
                This action simulates faculty approval stored in local browser memory (<code className="font-mono bg-white px-1 rounded">localStorage</code>). 
                This is a frontend demonstration without real backend authentication or multi-user sync.
              </div>
            )}

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-slate-100">
              <button
                type="button"
                disabled={isProcessing}
                onClick={() => setShowConfirmModal(false)}
                className="px-4 py-2 rounded-lg text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors disabled:opacity-50"
              >
                {actionType === 'view' ? 'Close' : 'Cancel'}
              </button>

              {actionType === 'approve' && (
                <button
                  type="button"
                  disabled={isProcessing}
                  onClick={handleConfirmAction}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold text-white bg-[#2563EB] hover:bg-[#1D4ED8] transition-colors shadow-subtle disabled:opacity-60"
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Forwarding...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      <span>{isAuthenticated ? 'Forward to HOD' : 'Simulate: Forward to HOD'}</span>
                    </>
                  )}
                </button>
              )}

              {actionType === 'reject' && (
                <button
                  type="button"
                  disabled={isProcessing}
                  onClick={handleConfirmAction}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold text-white bg-red-600 hover:bg-red-700 transition-colors shadow-subtle disabled:opacity-60"
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Rejecting...</span>
                    </>
                  ) : (
                    <>
                      <X className="w-3.5 h-3.5" />
                      <span>{isAuthenticated ? 'Confirm Rejection' : 'Simulate: Reject Request'}</span>
                    </>
                  )}
                </button>
              )}
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
