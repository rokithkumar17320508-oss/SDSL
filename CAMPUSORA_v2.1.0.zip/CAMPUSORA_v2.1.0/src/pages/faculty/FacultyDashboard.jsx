import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Inbox, 
  Clock, 
  CheckCircle, 
  XCircle, 
  FileText, 
  ArrowRight, 
  UserCheck, 
  AlertCircle,
  RefreshCw,
  Loader2
} from 'lucide-react';
import { SAMPLE_FACULTY, getStoredApplications } from '../../data/studentData';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';

export default function FacultyDashboard() {
  const { user, isAuthenticated, isDemoMode } = useAuth();
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    setLoading(true);
    try {
      if (isAuthenticated) {
        const res = await api.getApplications();
        if (res.ok && res.data) {
          const list = Array.isArray(res.data) ? res.data : (res.data.results || []);
          setApplications(list);
        } else {
          setApplications([]);
        }
      } else {
        setApplications(getStoredApplications());
      }
    } catch (err) {
      console.error('Failed to load faculty applications:', err);
      setApplications([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [isAuthenticated, isDemoMode]);

  const totalCount = applications.length;
  const pendingFacultyCount = applications.filter(
    (app) => app.status === 'Pending Faculty Review'
  ).length;
  const approvedCount = applications.filter(
    (app) => app.status === 'Pending HOD Review' || app.status === 'HOD Approved'
  ).length;
  const rejectedCount = applications.filter(
    (app) => app.status === 'Rejected'
  ).length;

  const recentApps = applications.slice(0, 5);

  const displayName = isAuthenticated && user
    ? (user.first_name ? `${user.first_name} ${user.last_name}`.trim() : user.username)
    : SAMPLE_FACULTY.name;

  const displayEmpId = isAuthenticated && user
    ? (user.faculty_profile?.employee_id || 'FAC-CSE-402')
    : SAMPLE_FACULTY.employeeId;

  const displayDept = isAuthenticated && user
    ? (user.department || SAMPLE_FACULTY.department)
    : `${SAMPLE_FACULTY.designation} • ${SAMPLE_FACULTY.department}`;

  const initials = isAuthenticated && user
    ? ((user.first_name?.[0] || 'S') + (user.last_name?.[0] || 'V')).toUpperCase()
    : 'SV';

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Pending Faculty Review':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-amber-50 text-amber-800 border border-amber-200">
            Pending Faculty Review
          </span>
        );
      case 'Pending HOD Review':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-blue-50 text-[#2563EB] border border-blue-200">
            Forwarded to HOD
          </span>
        );
      case 'HOD Approved':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
            HOD Approved
          </span>
        );
      case 'Rejected':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-red-50 text-red-700 border border-red-200">
            Rejected
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-700">
            {status}
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Faculty Profile Overview Card */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 shadow-subtle flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center text-[#2563EB] text-base font-bold shrink-0">
            {initials}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-[#1E293B]">
                {displayName}
              </h2>
              <span className="text-xs font-mono font-medium text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                {displayEmpId}
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              {displayDept}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={loadData}
            disabled={loading}
            title="Refresh dashboard data"
            className="p-2.5 rounded-lg text-slate-600 bg-slate-50 border border-slate-200 hover:bg-slate-100 transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>

          <Link
            to="/faculty/requests"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold text-white bg-[#2563EB] hover:bg-[#1D4ED8] transition-colors shadow-subtle"
          >
            <Inbox className="w-4 h-4" />
            <span>Review Leave Requests ({pendingFacultyCount})</span>
          </Link>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        
        {/* Total Applications */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 shadow-subtle">
          <p className="text-xs font-medium text-slate-500">Total Applications</p>
          <p className="text-2xl font-bold text-[#1E293B] mt-1">{totalCount}</p>
          <p className="text-[11px] text-slate-400 mt-0.5">Assigned submissions</p>
        </div>

        {/* Pending Review */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 shadow-subtle">
          <p className="text-xs font-medium text-slate-500">Pending Review</p>
          <p className="text-2xl font-bold text-[#EAB308] mt-1">{pendingFacultyCount}</p>
          <p className="text-[11px] text-amber-700 font-medium mt-0.5">Action required</p>
        </div>

        {/* Approved / Forwarded */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 shadow-subtle">
          <p className="text-xs font-medium text-slate-500">Approved / Forwarded</p>
          <p className="text-2xl font-bold text-[#2563EB] mt-1">{approvedCount}</p>
          <p className="text-[11px] text-slate-400 mt-0.5">Forwarded to HOD</p>
        </div>

        {/* Rejected */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 shadow-subtle">
          <p className="text-xs font-medium text-slate-500">Rejected</p>
          <p className="text-2xl font-bold text-red-600 mt-1">{rejectedCount}</p>
          <p className="text-[11px] text-slate-400 mt-0.5">Applications denied</p>
        </div>

      </div>

      {/* Recent Applications Table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-subtle overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-[#1E293B]">Recent Applications</h3>
            <p className="text-xs text-slate-500">Recent student requests assigned for your review</p>
          </div>

          <Link
            to="/faculty/requests"
            className="inline-flex items-center gap-1 text-xs font-semibold text-[#2563EB] hover:text-[#1D4ED8] transition-colors"
          >
            <span>View All</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {loading ? (
          <div className="p-8 text-center text-xs text-slate-500 flex items-center justify-center gap-2">
            <Loader2 className="w-4 h-4 animate-spin text-[#2563EB]" />
            <span>Loading applications...</span>
          </div>
        ) : recentApps.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-500">
            No applications currently assigned for review.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-medium">
                <tr>
                  <th className="px-5 py-3">ID</th>
                  <th className="px-5 py-3">Student Name</th>
                  <th className="px-5 py-3">Reg Number</th>
                  <th className="px-5 py-3">Leave Type</th>
                  <th className="px-5 py-3">Dates</th>
                  <th className="px-5 py-3">Status</th>
                  <th className="px-5 py-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {recentApps.map((app) => (
                  <tr key={app.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-5 py-3.5 font-mono font-medium text-slate-600">
                      {app.id}
                    </td>
                    <td className="px-5 py-3.5 font-semibold text-[#1E293B]">
                      {app.studentName}
                    </td>
                    <td className="px-5 py-3.5 font-mono text-slate-500 text-[11px]">
                      {app.regNo}
                    </td>
                    <td className="px-5 py-3.5 font-medium text-slate-700">
                      {app.type}
                    </td>
                    <td className="px-5 py-3.5 text-slate-600">
                      {app.startDate === app.endDate
                        ? app.startDate
                        : `${app.startDate} to ${app.endDate}`}
                    </td>
                    <td className="px-5 py-3.5">
                      {getStatusBadge(app.status)}
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      <Link
                        to="/faculty/requests"
                        className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#2563EB] hover:text-[#1D4ED8]"
                      >
                        <span>Review</span>
                        <ArrowRight className="w-3 h-3" />
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

    </div>
  );
}