import React, { useState, useEffect } from 'react';
import { useSearchParams, Link, useNavigate, useLocation } from 'react-router-dom';
import { 
  Eye, 
  EyeOff, 
  ArrowLeft, 
  AlertCircle, 
  Info,
  GraduationCap, 
  UserCheck, 
  Building2, 
  Shield,
  Loader2,
  Lock,
  Sparkles
} from 'lucide-react';
import { BRAND } from '../config/branding';
import { useAuth } from '../context/AuthContext';

const roleIcons = {
  student: GraduationCap,
  faculty: UserCheck,
  hod: Building2,
  security: Shield,
};

const DEMO_CREDENTIALS = {
  student: { username: 'arjun', password: 'StudentPassword123!', label: 'Arjun Sharma (Student)' },
  faculty: { username: 'skverma', password: 'FacultyPassword123!', label: 'Dr. S. K. Verma (Faculty)' },
  hod: { username: 'rmehra', password: 'HodPassword123!', label: 'Prof. R. Mehra (HOD)' },
  security: { username: 'security_gate1', password: 'SecurityPassword123!', label: 'Officer Vikram Singh (Security)' },
};

export default function LoginPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const location = useLocation();
  const { login, enableDemoMode } = useAuth();
  const initialRole = searchParams.get('role') || 'student';

  const [selectedRole, setSelectedRole] = useState(
    BRAND.roles.some((r) => r.id === initialRole) ? initialRole : 'student'
  );

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [infoMessage, setInfoMessage] = useState('');

  // Sync role with search parameters
  useEffect(() => {
    const roleParam = searchParams.get('role');
    if (roleParam && BRAND.roles.some((r) => r.id === roleParam)) {
      setSelectedRole(roleParam);
    }
  }, [searchParams]);

  const handleRoleSelect = (roleId) => {
    setSelectedRole(roleId);
    setSearchParams({ role: roleId });
    setErrorMessage('');
    setInfoMessage('');
  };

  const handleFillCredentials = (roleKey) => {
    const creds = DEMO_CREDENTIALS[roleKey];
    if (creds) {
      setUsername(creds.username);
      setPassword(creds.password);
      handleRoleSelect(roleKey);
      setErrorMessage('');
      setInfoMessage(`Filled credentials for ${creds.label}. Click 'Sign In' to authenticate with PostgreSQL.`);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMessage('');
    setInfoMessage('');

    if (!username.trim() || !password.trim()) {
      setErrorMessage('Please enter both username and password.');
      return;
    }

    setIsSubmitting(true);
    try {
      const result = await login(username.trim(), password);
      if (result.success) {
        const userRole = (result.user.role || '').toLowerCase();
        
        // Redirect according to authenticated role
        const roleRoutes = {
          student: '/student',
          faculty: '/faculty',
          hod: '/hod',
          security: '/security',
        };

        const target = location.state?.from?.pathname || roleRoutes[userRole] || '/student';
        navigate(target, { replace: true });
      } else {
        setErrorMessage(result.error || 'Authentication failed. Please verify your credentials.');
      }
    } catch (err) {
      setErrorMessage(
        'Unable to connect to the CAMPUSORA backend server. Ensure Django is running on http://127.0.0.1:8000/.'
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLaunchDemo = (roleId) => {
    enableDemoMode(roleId);
    const demoRoutes = {
      student: '/student',
      faculty: '/faculty',
      hod: '/hod',
      security: '/security',
    };
    navigate(demoRoutes[roleId] || '/student');
  };

  const activeRoleData = BRAND.roles.find((r) => r.id === selectedRole) || BRAND.roles[0];

  return (
    <div className="min-h-[calc(100vh-130px)] flex flex-col justify-center py-10 px-4 sm:px-6 lg:px-8 bg-[#F8FAFC]">
      <div className="max-w-md w-full mx-auto space-y-6">
        
        {/* Back Link */}
        <Link
          to="/"
          className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-500 hover:text-[#1E293B] transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Home</span>
        </Link>

        {/* White Login Card */}
        <div className="bg-white border border-slate-200 rounded-xl shadow-card p-6 sm:p-8 space-y-6">
          
          {/* Header */}
          <div className="text-center space-y-1">
            <div className="inline-flex items-center gap-2 mb-1">
              <span className="w-2.5 h-2.5 rounded-full bg-[#2563EB]"></span>
              <span className="text-xl font-bold tracking-tight text-[#1E293B]">
                {BRAND.name}
              </span>
            </div>
            <h1 className="text-lg font-semibold text-[#1E293B]">
              Sign in to your account
            </h1>
            <p className="text-xs text-slate-500">
              Secured with PostgreSQL 18 & Argon2 JWT Authentication
            </p>
          </div>

          {/* Quick Credential Fill Helpers */}
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-700 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-[#2563EB]" />
                <span>Quick Test Logins (PostgreSQL DB)</span>
              </span>
              <span className="text-[10px] text-emerald-700 font-medium">DB Connected</span>
            </div>
            <div className="grid grid-cols-2 gap-1.5 text-[11px]">
              <button
                type="button"
                onClick={() => handleFillCredentials('student')}
                className="py-1 px-2 text-left rounded bg-white border border-slate-200 hover:border-blue-400 hover:bg-blue-50/50 transition-colors text-slate-700 truncate"
              >
                <strong>Student:</strong> arjun
              </button>
              <button
                type="button"
                onClick={() => handleFillCredentials('faculty')}
                className="py-1 px-2 text-left rounded bg-white border border-slate-200 hover:border-blue-400 hover:bg-blue-50/50 transition-colors text-slate-700 truncate"
              >
                <strong>Faculty:</strong> skverma
              </button>
              <button
                type="button"
                onClick={() => handleFillCredentials('hod')}
                className="py-1 px-2 text-left rounded bg-white border border-slate-200 hover:border-purple-400 hover:bg-purple-50/50 transition-colors text-slate-700 truncate"
              >
                <strong>HOD:</strong> rmehra
              </button>
              <button
                type="button"
                onClick={() => handleFillCredentials('security')}
                className="py-1 px-2 text-left rounded bg-white border border-slate-200 hover:border-emerald-400 hover:bg-emerald-50/50 transition-colors text-slate-700 truncate"
              >
                <strong>Security:</strong> security_gate1
              </button>
            </div>
          </div>

          {/* Role Segmented Selector */}
          <div>
            <label className="block text-xs font-medium text-slate-500 mb-2">
              Select Role
            </label>
            <div className="grid grid-cols-4 gap-1.5 p-1 bg-slate-50 border border-slate-200 rounded-lg">
              {BRAND.roles.map((role) => {
                const isSelected = selectedRole === role.id;
                const Icon = roleIcons[role.id] || GraduationCap;
                return (
                  <button
                    key={role.id}
                    type="button"
                    onClick={() => handleRoleSelect(role.id)}
                    className={`flex flex-col items-center justify-center py-2 px-1 rounded-md text-xs font-medium transition-all ${
                      isSelected
                        ? 'bg-white text-[#2563EB] shadow-subtle font-semibold'
                        : 'text-slate-600 hover:text-[#1E293B]'
                    }`}
                  >
                    <Icon className="w-4 h-4 mb-1" />
                    <span className="text-[11px] leading-tight">{role.title}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Role Guidance Helper */}
          <div className="text-xs text-slate-500 bg-slate-50 border border-slate-100 rounded-lg p-2.5">
            <span className="font-semibold text-slate-700">{activeRoleData.badge}: </span>
            {activeRoleData.description}
          </div>

          {/* Error Alert */}
          {errorMessage && (
            <div className="flex items-start gap-2.5 p-3 text-xs text-red-700 bg-red-50 border border-red-200 rounded-lg">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-500 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Info Alert */}
          {infoMessage && (
            <div className="flex items-start gap-2.5 p-3 text-xs text-blue-800 bg-blue-50 border border-blue-200 rounded-lg">
              <Info className="w-4 h-4 shrink-0 text-[#2563EB] mt-0.5" />
              <span>{infoMessage}</span>
            </div>
          )}

          {/* Real Backend Login Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* Username Field */}
            <div className="space-y-1">
              <label 
                htmlFor="username" 
                className="block text-xs font-medium text-slate-700"
              >
                {activeRoleData.fieldLabel}
              </label>
              <input
                id="username"
                type="text"
                value={username}
                disabled={isSubmitting}
                onChange={(e) => {
                  setUsername(e.target.value);
                  if (errorMessage) setErrorMessage('');
                }}
                placeholder={activeRoleData.fieldPlaceholder}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg text-[#1E293B] placeholder-slate-400 focus:outline-none focus:border-[#2563EB] focus:ring-1 focus:ring-[#2563EB] transition-colors disabled:bg-slate-100"
              />
            </div>

            {/* Password Field with Show/Hide */}
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <label 
                  htmlFor="password" 
                  className="block text-xs font-medium text-slate-700"
                >
                  Password
                </label>
              </div>
              <div className="relative">
                <input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  disabled={isSubmitting}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (errorMessage) setErrorMessage('');
                  }}
                  placeholder="Enter your password"
                  className="w-full px-3 py-2 pr-10 text-sm bg-white border border-slate-200 rounded-lg text-[#1E293B] placeholder-slate-400 focus:outline-none focus:border-[#2563EB] focus:ring-1 focus:ring-[#2563EB] transition-colors disabled:bg-slate-100"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600 focus:outline-none"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full inline-flex items-center justify-center gap-2 py-2.5 px-4 text-sm font-semibold text-white bg-[#2563EB] hover:bg-[#1D4ED8] disabled:bg-blue-400 rounded-lg transition-colors shadow-subtle"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Authenticating...</span>
                </>
              ) : (
                <>
                  <Lock className="w-4 h-4" />
                  <span>Sign In</span>
                </>
              )}
            </button>

          </form>

          {/* Separator for Demo Mode (Development simulation only - disabled in production) */}
          {!import.meta.env.PROD && (
            <div className="pt-4 border-t border-slate-100 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-500">Day 3 Demo Simulation</span>
                <span className="text-[10px] text-amber-700 font-mono">Development Mode</span>
              </div>
              <p className="text-[11px] text-slate-500">
                Want to evaluate without entering credentials? Launch an isolated dev simulation:
              </p>
              <div className="grid grid-cols-4 gap-1.5 pt-1">
                <button
                  type="button"
                  onClick={() => handleLaunchDemo('student')}
                  className="py-1 px-1.5 text-center rounded text-[11px] font-medium text-slate-600 bg-slate-50 hover:bg-slate-100 border border-slate-200 transition-colors"
                >
                  Student
                </button>
                <button
                  type="button"
                  onClick={() => handleLaunchDemo('faculty')}
                  className="py-1 px-1.5 text-center rounded text-[11px] font-medium text-blue-700 bg-slate-50 hover:bg-blue-50 border border-slate-200 transition-colors"
                >
                  Faculty
                </button>
                <button
                  type="button"
                  onClick={() => handleLaunchDemo('hod')}
                  className="py-1 px-1.5 text-center rounded text-[11px] font-medium text-purple-700 bg-slate-50 hover:bg-purple-50 border border-slate-200 transition-colors"
                >
                  HOD
                </button>
                <button
                  type="button"
                  onClick={() => handleLaunchDemo('security')}
                  className="py-1 px-1.5 text-center rounded text-[11px] font-medium text-emerald-700 bg-slate-50 hover:bg-emerald-50 border border-slate-200 transition-colors"
                >
                  Security
                </button>
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
}
