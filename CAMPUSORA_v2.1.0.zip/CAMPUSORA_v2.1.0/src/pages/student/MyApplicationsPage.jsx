import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { PlusCircle, Search, Filter, FileText, RefreshCw, Loader2, QrCode } from 'lucide-react';
import { getStoredApplications } from '../../data/studentData';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';

export default function MyApplicationsPage() {
  const { isAuthenticated, isDemoMode } = useAuth();
  const [applications, setApplications] = useState([]);
  const [filter, setFilter] = useState('All');
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  const fetchApplications = async () => {
    setLoading(true);
    try {
      if (isAuthenticated) {
        const res = await api.getApplications();
        if (res.ok && res.data) {
          const list = Array.isArray(res.data) ? res.data : (res.data.results || []);
          setApplications(list);
        } else {
          setApplications([]);
        }
      } else {
        setApplications(getStoredApplications());
      }
    } catch (err) {
      console.error('Failed to load applications:', err);
      setApplications([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchApplications();
  }, [isAuthenticated, isDemoMode]);

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Pending Faculty Review':
      case 'Pending':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-amber-50 text-amber-800 border border-amber-200">
            Pending Faculty Review
          </span>
        );
      case 'Pending HOD Review':
      case 'Faculty Approved':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-blue-50 text-[#2563EB] border border-blue-200">
            Pending HOD Review
          </span>
        );
      case 'HOD Approved':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
            HOD Approved
          </span>
        );
      case 'Rejected':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-red-50 text-red-700 border border-red-200">
            Rejected
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-slate-100 text-slate-700">
            {status}
          </span>
        );
    }
  };

  const filteredApps = applications.filter((app) => {
    const matchesFilter = 
      filter === 'All' ||
      (filter === 'Pending Faculty' && (app.status === 'Pending Faculty Review' || app.status === 'Pending')) ||
      (filter === 'Pending HOD' && (app.status === 'Pending HOD Review' || app.status === 'Faculty Approved')) ||
      (filter === 'Approved' && app.status === 'HOD Approved') ||
      (filter === 'Rejected' && app.status === 'Rejected');

    const matchesSearch = 
      app.id.toLowerCase().includes(search.toLowerCase()) ||
      app.type.toLowerCase().includes(search.toLowerCase()) ||
      app.reason.toLowerCase().includes(search.toLowerCase());

    return matchesFilter && matchesSearch;
  });

  return (
    <div className="space-y-6">
      
      {/* Header with Title, Refresh, and Apply CTA */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-[#1E293B]">My Leave Applications</h2>
          <p className="text-xs text-slate-500">Track all submitted leave requests and multi-level clearance stages</p>
        </div>

        <div className="flex items-center gap-2 shrink-0 self-start sm:self-auto">
          <button
            onClick={fetchApplications}
            disabled={loading}
            title="Refresh applications"
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold text-slate-600 bg-white border border-slate-200 hover:bg-slate-50 transition-colors shadow-subtle disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>

          <Link
            to="/student/apply"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold text-white bg-[#2563EB] hover:bg-[#1D4ED8] transition-colors shadow-subtle"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>New Application</span>
          </Link>
        </div>
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-3 shadow-subtle flex flex-col sm:flex-row items-center justify-between gap-3">
        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
          {[
            { id: 'All', label: 'All' },
            { id: 'Pending Faculty', label: 'Faculty Review' },
            { id: 'Pending HOD', label: 'HOD Review' },
            { id: 'Approved', label: 'Approved' },
            { id: 'Rejected', label: 'Rejected' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilter(tab.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors shrink-0 ${
                filter === tab.id
                  ? 'bg-blue-50 text-[#2563EB] font-semibold'
                  : 'text-slate-600 hover:text-[#1E293B] hover:bg-slate-50'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Search Input */}
        <div className="relative w-full sm:w-64">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by ID, type, reason..."
            className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-[#1E293B] placeholder-slate-400 focus:outline-none focus:border-[#2563EB] focus:bg-white"
          />
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
        </div>
      </div>

      {/* Applications Table Card */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-subtle overflow-hidden">
        {loading ? (
          <div className="p-12 text-center space-y-2">
            <Loader2 className="w-8 h-8 text-[#2563EB] animate-spin mx-auto" />
            <p className="text-xs text-slate-500">Loading leave records from database...</p>
          </div>
        ) : filteredApps.length === 0 ? (
          <div className="p-12 text-center space-y-2">
            <FileText className="w-8 h-8 text-slate-300 mx-auto" />
            <p className="text-sm font-semibold text-[#1E293B]">No applications match your filter</p>
            <p className="text-xs text-slate-500">Try changing your search term or apply for a new pass.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-medium">
                <tr>
                  <th className="px-5 py-3">Application ID</th>
                  <th className="px-5 py-3">Leave Type</th>
                  <th className="px-5 py-3">Dates</th>
                  <th className="px-5 py-3">Reason</th>
                  <th className="px-5 py-3">Remarks</th>
                  <th className="px-5 py-3">Status</th>
                  <th className="px-5 py-3 text-right">Clearance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {filteredApps.map((app) => (
                  <tr key={app.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-5 py-3.5 font-mono font-semibold text-slate-700">
                      {app.id}
                    </td>
                    <td className="px-5 py-3.5 font-medium text-[#1E293B]">
                      {app.type}
                    </td>
                    <td className="px-5 py-3.5 text-slate-600">
                      {app.startDate === app.endDate
                        ? app.startDate
                        : `${app.startDate} — ${app.endDate}`}
                    </td>
                    <td className="px-5 py-3.5 text-slate-600 max-w-xs truncate" title={app.reason}>
                      {app.reason}
                    </td>
                    <td className="px-5 py-3.5 text-slate-500 text-[11px] max-w-xs truncate" title={app.hodRemarks || app.facultyRemarks}>
                      {app.hodRemarks || app.facultyRemarks || '—'}
                    </td>
                    <td className="px-5 py-3.5">
                      {getStatusBadge(app.status)}
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      {app.status === 'HOD Approved' ? (
                        <Link
                          to="/student/gate-pass"
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold text-[#2563EB] bg-blue-50 hover:bg-blue-100 transition-colors"
                        >
                          <QrCode className="w-3.5 h-3.5" />
                          <span>QR Pass</span>
                        </Link>
                      ) : (
                        <span className="text-slate-400 font-mono text-xs">—</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

    </div>
  );
}
