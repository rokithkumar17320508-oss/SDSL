import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  PlusCircle, 
  Clock, 
  CheckCircle, 
  Percent, 
  ArrowRight, 
  FileText,
  AlertCircle,
  RefreshCw,
  Loader2,
  XCircle,
  QrCode
} from 'lucide-react';
import { SAMPLE_STUDENT, getStoredApplications } from '../../data/studentData';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';

export default function StudentDashboard() {
  const { user, isAuthenticated, isDemoMode } = useAuth();
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchApplications = async () => {
    setLoading(true);
    try {
      if (isAuthenticated) {
        const res = await api.getApplications();
        if (res.ok && res.data) {
          const list = Array.isArray(res.data) ? res.data : (res.data.results || []);
          setApplications(list);
        } else {
          setApplications([]);
        }
      } else {
        setApplications(getStoredApplications());
      }
    } catch (err) {
      console.error('Failed to load applications:', err);
      setApplications([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchApplications();
  }, [isAuthenticated, isDemoMode]);

  const totalCount = applications.length;
  const pendingCount = applications.filter(
    (app) => app.status === 'Pending Faculty Review' || app.status === 'Pending HOD Review' || app.status === 'Pending'
  ).length;

  const approvedCount = applications.filter(
    (app) => app.status === 'HOD Approved'
  ).length;

  const rejectedCount = applications.filter(
    (app) => app.status === 'Rejected'
  ).length;

  const recentApplications = applications.slice(0, 4);

  const displayName = isAuthenticated && user
    ? (user.first_name ? `${user.first_name} ${user.last_name}`.trim() : user.username)
    : SAMPLE_STUDENT.name;

  const displayReg = isAuthenticated && user
    ? (user.student_profile?.registration_number || user.username)
    : SAMPLE_STUDENT.regNo;

  const displayDept = isAuthenticated && user
    ? (user.department || 'Computer Science & Engineering')
    : `${SAMPLE_STUDENT.department} • ${SAMPLE_STUDENT.year} (${SAMPLE_STUDENT.section})`;

  const initials = isAuthenticated && user
    ? ((user.first_name?.[0] || user.username?.[0] || 'S') + (user.last_name?.[0] || 'T')).toUpperCase()
    : 'AS';

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Pending Faculty Review':
      case 'Pending':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-amber-50 text-amber-800 border border-amber-200">
            Pending Faculty
          </span>
        );
      case 'Pending HOD Review':
      case 'Faculty Approved':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-50 text-[#2563EB] border border-blue-200">
            Pending HOD
          </span>
        );
      case 'HOD Approved':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
            HOD Approved
          </span>
        );
      case 'Rejected':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-red-50 text-red-700 border border-red-200">
            Rejected
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-slate-50 text-slate-700 border border-slate-200">
            {status}
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Student Profile Overview Card */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 shadow-subtle flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center text-[#2563EB] text-base font-bold shrink-0">
            {initials}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-[#1E293B]">
                {displayName}
              </h2>
              <span className="text-xs font-mono font-medium text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                {displayReg}
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              {displayDept}
            </p>
          </div>
        </div>

        {/* Quick Action Buttons */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={fetchApplications}
            disabled={loading}
            title="Refresh application data"
            className="p-2.5 rounded-lg text-slate-600 bg-slate-50 border border-slate-200 hover:bg-slate-100 transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>

          <Link
            to="/student/apply"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold text-white bg-[#2563EB] hover:bg-[#1D4ED8] transition-colors shadow-subtle"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Apply Leave</span>
          </Link>
        </div>
      </div>

      {/* Active Gate Pass Notification Banner */}
      {approvedCount > 0 && (
        <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-700 rounded-2xl p-5 text-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-card">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur-sm border border-white/30 flex items-center justify-center shrink-0">
              <QrCode className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2 mb-0.5">
                <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-emerald-400 text-emerald-950">
                  Ready to Scan
                </span>
                <span className="text-xs text-blue-100 font-medium">HOD Clearance Granted</span>
              </div>
              <h3 className="text-sm sm:text-base font-bold tracking-tight">
                Digital QR Gate Pass Available
              </h3>
              <p className="text-xs text-blue-100/90 mt-0.5">
                Your approved leave outpass has generated an official cryptographic QR barcode for security checkpoint clearance.
              </p>
            </div>
          </div>

          <Link
            to="/student/gate-pass"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold bg-white text-[#2563EB] hover:bg-blue-50 transition-colors shadow-subtle shrink-0"
          >
            <span>Open QR Gate Pass</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      )}

      {/* Key Metrics / Stats Row */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        
        {/* Attendance Card */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-subtle flex items-center justify-between">
          <div>
            <p className="text-xs font-medium text-slate-500">Attendance</p>
            <p className="text-2xl font-bold text-[#1E293B] mt-1">{SAMPLE_STUDENT.attendance}%</p>
            <p className="text-[11px] text-emerald-600 font-medium mt-0.5">Eligible for leave</p>
          </div>
          <div className="w-10 h-10 rounded-lg bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-600">
            <Percent className="w-5 h-5" />
          </div>
        </div>

        {/* Pending Requests */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-subtle flex items-center justify-between">
          <div>
            <p className="text-xs font-medium text-slate-500">Pending Requests</p>
            <p className="text-2xl font-bold text-[#1E293B] mt-1">{pendingCount}</p>
            <p className="text-[11px] text-slate-500 mt-0.5">In review queue</p>
          </div>
          <div className="w-10 h-10 rounded-lg bg-amber-50 border border-amber-100 flex items-center justify-center text-[#EAB308]">
            <Clock className="w-5 h-5" />
          </div>
        </div>

        {/* Approved Requests */}
        <Link 
          to="/student/gate-pass"
          className="bg-white border border-slate-200 rounded-xl p-5 shadow-subtle flex items-center justify-between hover:border-blue-300 hover:shadow-card transition-all group"
        >
          <div>
            <p className="text-xs font-medium text-slate-500 group-hover:text-[#2563EB] transition-colors">Approved Passes</p>
            <p className="text-2xl font-bold text-[#1E293B] mt-1">{approvedCount}</p>
            <p className="text-[11px] text-blue-600 font-semibold mt-0.5 flex items-center gap-1">
              <span>View QR Pass</span>
              <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
            </p>
          </div>
          <div className="w-10 h-10 rounded-lg bg-blue-50 border border-blue-100 flex items-center justify-center text-[#2563EB] group-hover:bg-[#2563EB] group-hover:text-white transition-colors">
            <QrCode className="w-5 h-5" />
          </div>
        </Link>

        {/* Rejected Requests */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-subtle flex items-center justify-between">
          <div>
            <p className="text-xs font-medium text-slate-500">Rejected</p>
            <p className="text-2xl font-bold text-[#1E293B] mt-1">{rejectedCount}</p>
            <p className="text-[11px] text-slate-500 mt-0.5">Denied requests</p>
          </div>
          <div className="w-10 h-10 rounded-lg bg-red-50 border border-red-100 flex items-center justify-center text-red-500">
            <XCircle className="w-5 h-5" />
          </div>
        </div>

      </div>

      {/* Recent Applications Section */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-subtle overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-[#1E293B]">Recent Applications</h3>
            <p className="text-xs text-slate-500">Latest leave requests and clearance stages</p>
          </div>

          <Link
            to="/student/applications"
            className="inline-flex items-center gap-1 text-xs font-semibold text-[#2563EB] hover:text-[#1D4ED8] transition-colors"
          >
            <span>View All</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {loading ? (
          <div className="p-8 text-center text-xs text-slate-500 flex items-center justify-center gap-2">
            <Loader2 className="w-4 h-4 animate-spin text-[#2563EB]" />
            <span>Loading applications...</span>
          </div>
        ) : recentApplications.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-500">
            No applications found. Click "Apply Leave" to submit your first request.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-medium">
                <tr>
                  <th className="px-5 py-3">ID</th>
                  <th className="px-5 py-3">Type</th>
                  <th className="px-5 py-3">Dates</th>
                  <th className="px-5 py-3">Reason</th>
                  <th className="px-5 py-3">Status</th>
                  <th className="px-5 py-3 text-right">Clearance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {recentApplications.map((app) => (
                  <tr key={app.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-5 py-3.5 font-mono font-medium text-slate-600">
                      {app.id}
                    </td>
                    <td className="px-5 py-3.5 font-semibold text-[#1E293B]">
                      {app.type}
                    </td>
                    <td className="px-5 py-3.5 text-slate-600">
                      {app.startDate === app.endDate 
                        ? app.startDate 
                        : `${app.startDate} to ${app.endDate}`}
                    </td>
                    <td className="px-5 py-3.5 text-slate-600 max-w-xs truncate" title={app.reason}>
                      {app.reason}
                    </td>
                    <td className="px-5 py-3.5">
                      {getStatusBadge(app.status)}
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      {app.status === 'HOD Approved' ? (
                        <Link
                          to="/student/gate-pass"
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold text-[#2563EB] bg-blue-50 hover:bg-blue-100 transition-colors"
                        >
                          <QrCode className="w-3.5 h-3.5" />
                          <span>QR Pass</span>
                        </Link>
                      ) : (
                        <span className="text-slate-400 font-mono text-xs">—</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

    </div>
  );
}
