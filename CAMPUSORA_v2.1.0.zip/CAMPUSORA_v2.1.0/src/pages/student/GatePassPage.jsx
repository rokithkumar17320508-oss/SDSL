import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  ShieldCheck, 
  Info, 
  Clock, 
  CheckCircle2, 
  Calendar, 
  User, 
  ArrowRight,
  AlertTriangle,
  QrCode,
  Copy,
  Check,
  RefreshCw,
  XCircle,
  MapPin,
  Building,
  Lock,
  DoorOpen,
  FileText
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { BRAND } from '../../config/branding';
import api from '../../services/api';
import { getStoredApplications, SAMPLE_STUDENT } from '../../data/studentData';

export default function GatePassPage() {
  const { user, isDemoMode } = useAuth();
  const [passData, setPassData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [copied, setCopied] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const fetchActivePass = async (isManualRefresh = false) => {
    if (isManualRefresh) setRefreshing(true);
    else setLoading(true);
    setError(null);

    try {
      if (isDemoMode) {
        // Demo mode fallback using local storage
        const apps = getStoredApplications();
        const approved = apps.find(app => app.status === 'HOD Approved');
        const pending = apps.find(app => 
          app.status === 'Pending Faculty Review' || 
          app.status === 'Pending HOD Review' || 
          app.status === 'Pending' || 
          app.status === 'Faculty Approved'
        );

        if (approved) {
          setPassData({
            pass_id: 'GP-DEMO-7648',
            application_id: approved.id || 'APP-7648',
            student_name: user?.name || SAMPLE_STUDENT.name,
            student_registration: user?.student_profile?.registration_number || SAMPLE_STUDENT.regNo,
            department: user?.student_profile?.department || SAMPLE_STUDENT.department,
            room_number: user?.student_profile?.room_number || SAMPLE_STUDENT.roomNumber || 'B-302',
            leave_type: approved.type || 'Hostel Outpass',
            reason: approved.reason || 'Weekend family visit',
            gate_type: 'Both Gates (Main & Hostel)',
            status: 'ACTIVE',
            valid_from: approved.startDate || '2026-11-17',
            valid_until: approved.endDate || '2026-11-19',
            is_expired: false,
            raw_token: 'CMP-DEMO-SECURE-TOKEN-XYZ123',
            qr_code_image: null, // Demo mode text fallback
          });
        } else if (pending) {
          setPassData({
            status: 'PENDING',
            message: `Your application ${pending.id} (${pending.type}) is under institutional review. Gate pass will activate upon HOD approval.`,
            application_id: pending.id,
            leave_type: pending.type,
          });
        } else {
          setPassData({
            status: 'NONE',
            message: 'No active or approved leave application found. Please apply for leave to generate an authorized gate pass.',
          });
        }
      } else {
        // Live PostgreSQL API call
        const res = await api.getActiveGatePass();
        if (res.ok && res.data) {
          setPassData(res.data);
        } else {
          throw new Error(res.data?.detail || res.error || 'Failed to retrieve active gate pass.');
        }
      }
    } catch (err) {
      console.error('Failed to fetch active gate pass:', err);
      // If error, check demo data as fallback
      const apps = getStoredApplications();
      const approved = apps.find(app => app.status === 'HOD Approved');
      if (approved) {
        setPassData({
          pass_id: 'GP-FALLBACK-01',
          application_id: approved.id,
          student_name: user?.name || 'Arjun Sharma',
          student_registration: user?.student_profile?.registration_number || '2024CSE1084',
          department: user?.student_profile?.department || 'Computer Science and Engineering',
          leave_type: approved.type,
          reason: approved.reason,
          gate_type: 'Both Gates',
          status: 'ACTIVE',
          valid_from: approved.startDate,
          valid_until: approved.endDate,
          is_expired: false,
          raw_token: 'CMP-TOKEN-FALLBACK',
        });
      } else {
        setError(err.message || 'Unable to connect to gate pass clearance service.');
      }
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchActivePass();
  }, [isDemoMode]);

  const copyTokenToClipboard = () => {
    if (!passData?.raw_token) return;
    navigator.clipboard.writeText(passData.raw_token);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  // Status Badge Helper
  const renderStatusBadge = (status, isExpired) => {
    if (isExpired || status === 'EXPIRED') {
      return (
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200">
          <Clock className="w-3.5 h-3.5" />
          Pass Expired
        </span>
      );
    }
    if (status === 'RETURNED') {
      return (
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-300">
          <CheckCircle2 className="w-3.5 h-3.5 text-blue-600" />
          Campus Return Completed
        </span>
      );
    }
    if (status === 'USED') {
      return (
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-300">
          <DoorOpen className="w-3.5 h-3.5 text-slate-500" />
          Departure Confirmed (Used)
        </span>
      );
    }
    if (status === 'REVOKED') {
      return (
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-red-50 text-red-700 border border-red-200">
          <XCircle className="w-3.5 h-3.5" />
          Revoked by Admin
        </span>
      );
    }
    if (status === 'ACTIVE') {
      return (
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 shadow-sm">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          Authorized & Ready to Scan
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200">
        <Clock className="w-3.5 h-3.5" />
        Awaiting Authorization
      </span>
    );
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      
      {/* Top Header & Refresh */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-[#1E293B]">Digital Gate Pass</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Single-use cryptographic security pass for verified campus exit clearance
          </p>
        </div>

        <button
          onClick={() => fetchActivePass(true)}
          disabled={loading || refreshing}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 hover:text-[#2563EB] transition-colors shadow-subtle disabled:opacity-50"
          title="Refresh Pass Status"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin text-[#2563EB]' : ''}`} />
          <span>{refreshing ? 'Checking...' : 'Refresh'}</span>
        </button>
      </div>

      {/* Security Guidance Notice */}
      <div className="bg-blue-50/70 border border-blue-100 rounded-xl p-4 flex items-start gap-3">
        <ShieldCheck className="w-5 h-5 text-[#2563EB] shrink-0 mt-0.5" />
        <div className="text-xs text-slate-700 leading-relaxed">
          <strong className="font-semibold text-blue-900">CAMPUSORA Zero-Trust Clearance: </strong>
          Gate passes are generated only after verified Head of Department (HOD) approval. Once verified and stamped by security at the gate terminal, each single-use token becomes permanently marked as used to prevent unauthorized reuse or pass-sharing.
        </div>
      </div>

      {/* Main Content Loading State */}
      {loading ? (
        <div className="bg-white border border-slate-200 rounded-xl p-12 text-center shadow-card space-y-3">
          <RefreshCw className="w-8 h-8 text-[#2563EB] animate-spin mx-auto" />
          <p className="text-sm font-semibold text-[#1E293B]">Retrieving Gate Pass Authorization...</p>
          <p className="text-xs text-slate-400">Verifying signed status against PostgreSQL security ledger</p>
        </div>
      ) : error ? (
        <div className="bg-white border border-red-200 rounded-xl p-8 text-center shadow-card space-y-3">
          <AlertTriangle className="w-8 h-8 text-red-500 mx-auto" />
          <h3 className="text-sm font-bold text-red-900">Verification Service Unavailable</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">{error}</p>
          <button
            onClick={() => fetchActivePass()}
            className="px-4 py-2 bg-[#2563EB] text-white text-xs font-semibold rounded-lg hover:bg-[#1D4ED8]"
          >
            Retry Connection
          </button>
        </div>
      ) : passData?.status === 'ACTIVE' || passData?.status === 'USED' || passData?.status === 'RETURNED' || passData?.status === 'EXPIRED' || passData?.status === 'REVOKED' ? (
        
        /* Official Digital Gate Pass Card */
        <div className="bg-white border border-slate-200 rounded-2xl shadow-card overflow-hidden transition-all">
          
          {/* Card Header Strip */}
          <div className="bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-800 p-5 text-white flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 flex items-center justify-center font-bold text-base tracking-wider">
                CO
              </div>
              <div>
                <h2 className="text-base font-bold tracking-tight">{BRAND.name} Official Gate Pass</h2>
                <p className="text-[11px] text-blue-100/80">Campus Security & Departure Clearance</p>
              </div>
            </div>

            <div className="text-right">
              <span className="text-[10px] uppercase font-mono tracking-wider text-blue-200 block">Pass Reference</span>
              <span className="text-sm font-mono font-bold tracking-wider">{passData.pass_id || passData.id}</span>
            </div>
          </div>

          {/* Subheader Status Strip */}
          <div className="px-6 py-3.5 bg-slate-50/80 border-b border-slate-200/80 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="text-xs font-medium text-slate-500">Status:</span>
              {renderStatusBadge(passData.status, passData.is_expired)}
            </div>

            <div className="flex items-center gap-1.5 text-xs text-slate-600 font-medium">
              <MapPin className="w-3.5 h-3.5 text-[#2563EB]" />
              <span>Gate Authorization:</span>
              <span className="font-semibold text-[#1E293B] bg-white px-2 py-0.5 rounded border border-slate-200">
                {passData.gate_type}
              </span>
            </div>
          </div>

          <div className="p-6 space-y-6">

            {/* Student Photograph & Identity Banner */}
            <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 flex flex-col sm:flex-row items-center sm:items-start gap-4">
              <div className="relative shrink-0">
                <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-xl overflow-hidden bg-slate-200 border-2 border-[#2563EB]/40 shadow-sm flex items-center justify-center">
                  <img
                    src="https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=256&h=256"
                    alt={passData.student_name || "Student Photograph"}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      e.target.style.display = 'none';
                      e.target.parentElement.innerHTML = '<div class="w-full h-full bg-[#2563EB] text-white flex flex-col items-center justify-center font-bold text-xl"><span>AS</span><span class="text-[9px] font-mono mt-1 opacity-80">VERIFIED ID</span></div>';
                    }}
                  />
                </div>
                <span className="absolute -bottom-2 -right-1 px-1.5 py-0.5 rounded text-[9px] font-bold uppercase bg-emerald-600 text-white shadow-xs border border-white">
                  Photo ID
                </span>
              </div>

              <div className="flex-1 text-center sm:text-left space-y-1">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                  <div>
                    <h3 className="text-base font-bold text-[#1E293B] leading-tight">
                      {passData.student_name || user?.name || 'Arjun Sharma'}
                    </h3>
                    <p className="text-xs font-mono font-semibold text-[#2563EB]">
                      Reg: {passData.student_registration || user?.student_profile?.registration_number || '2024CSE1084'}
                    </p>
                  </div>
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 self-center sm:self-start">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    Enrolled Student
                  </span>
                </div>

                <div className="pt-1 text-xs text-slate-600 space-y-0.5">
                  <p><span className="text-slate-400 font-medium">Department:</span> <span className="font-semibold text-slate-700">{passData.department || 'Computer Science and Engineering'}</span></p>
                  <p><span className="text-slate-400 font-medium">Hostel Block:</span> <span className="font-semibold text-slate-700">{passData.room_number || 'BH-2, Room 405'}</span></p>
                </div>
              </div>
            </div>

            {/* Student & Leave Info Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-0.5">
                <span className="text-slate-400 text-[11px] uppercase font-semibold tracking-wider">Student Name</span>
                <p className="font-bold text-[#1E293B] text-sm">{passData.student_name || user?.name}</p>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-0.5">
                <span className="text-slate-400 text-[11px] uppercase font-semibold tracking-wider">Registration Number</span>
                <p className="font-mono font-bold text-[#1E293B] text-sm">
                  {passData.student_registration || user?.student_profile?.registration_number || '2024CSE1084'}
                </p>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-0.5">
                <span className="text-slate-400 text-[11px] uppercase font-semibold tracking-wider">Department</span>
                <p className="font-semibold text-slate-700">
                  {passData.department || user?.student_profile?.department || 'Computer Science and Engineering'}
                </p>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-0.5">
                <span className="text-slate-400 text-[11px] uppercase font-semibold tracking-wider">Leave Category</span>
                <p className="font-semibold text-[#2563EB]">
                  {passData.leave_type}
                </p>
              </div>
            </div>

            {/* Authorization Window & Reason */}
            <div className="p-3.5 bg-blue-50/50 rounded-xl border border-blue-100 space-y-2 text-xs">
              <div className="flex flex-wrap items-center justify-between gap-2 text-slate-700">
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-[#2563EB]" />
                  <span className="font-semibold">Validity Window:</span>
                  <span>{passData.valid_from ? new Date(passData.valid_from).toLocaleDateString() : passData.start_date} — {passData.valid_until ? new Date(passData.valid_until).toLocaleDateString() : passData.end_date}</span>
                </div>
                <div className="flex items-center gap-1 text-[11px] text-slate-500 font-mono">
                  <span>Linked App:</span>
                  <span className="font-bold text-slate-700">{passData.application_id}</span>
                </div>
              </div>
              <p className="text-[11px] text-slate-600">
                <span className="font-semibold text-slate-700">Purpose of Leave:</span> {passData.reason}
              </p>
            </div>

            {/* QR Code Security Clearance Box */}
            <div className="relative border-2 border-dashed border-slate-200 rounded-2xl p-6 bg-[#FAFCFF] text-center space-y-4">
              
              {/* Return Entry Watermark when RETURNED */}
              {passData.status === 'RETURNED' && (
                <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-[2px] rounded-2xl flex flex-col items-center justify-center p-6 text-white z-10">
                  <div className="w-14 h-14 rounded-full bg-blue-500/20 border-2 border-blue-400 flex items-center justify-center mb-2">
                    <CheckCircle2 className="w-8 h-8 text-blue-400" />
                  </div>
                  <span className="text-xs uppercase font-mono tracking-widest text-blue-300 font-bold">Pass Status</span>
                  <h3 className="text-xl font-black tracking-wide text-white mt-0.5">CAMPUS RETURN COMPLETED</h3>
                  <p className="text-xs text-slate-200 mt-1 max-w-sm">
                    Return entry verified & stamped by Security Checkpoint at{' '}
                    <span className="font-mono font-semibold text-white">
                      {passData.entry_recorded_at ? new Date(passData.entry_recorded_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Checkpoint'}
                    </span>.
                    Pass cycle is fully completed and archived.
                  </p>
                </div>
              )}

              {/* Departure Watermark when USED */}
              {passData.status === 'USED' && (
                <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-[2px] rounded-2xl flex flex-col items-center justify-center p-6 text-white z-10">
                  <div className="w-14 h-14 rounded-full bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center mb-2">
                    <CheckCircle2 className="w-8 h-8 text-emerald-400" />
                  </div>
                  <span className="text-xs uppercase font-mono tracking-widest text-emerald-300 font-bold">Pass Status</span>
                  <h3 className="text-xl font-black tracking-wide text-white mt-0.5">CAMPUS EXIT COMPLETED</h3>
                  <p className="text-xs text-slate-200 mt-1 max-w-sm">
                    Departure recorded by Security Checkpoint at{' '}
                    <span className="font-mono font-semibold text-white">
                      {passData.exit_recorded_at ? new Date(passData.exit_recorded_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Checkpoint'}
                    </span>.
                    This single-use clearance token is now retired.
                  </p>
                </div>
              )}

              {/* Expired Watermark */}
              {(passData.status === 'EXPIRED' || passData.is_expired) && (
                <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-[2px] rounded-2xl flex flex-col items-center justify-center p-6 text-white z-10">
                  <Clock className="w-12 h-12 text-rose-400 mb-2" />
                  <h3 className="text-lg font-bold text-white">GATE PASS EXPIRED</h3>
                  <p className="text-xs text-slate-200 mt-1 max-w-sm">
                    The departure authorization window closed on{' '}
                    <span className="font-mono text-rose-300">
                      {passData.valid_until ? new Date(passData.valid_until).toLocaleString() : 'Date'}
                    </span>.
                  </p>
                </div>
              )}

              {/* QR Image Rendering */}
              <div className="mx-auto w-52 h-52 bg-white p-3 rounded-2xl shadow-subtle border border-slate-200 flex items-center justify-center">
                {passData.qr_code_image ? (
                  <img
                    src={passData.qr_code_image}
                    alt="Cryptographic QR Gate Pass"
                    className="w-full h-full object-contain"
                  />
                ) : (
                  <div className="flex flex-col items-center justify-center text-slate-400 space-y-2">
                    <QrCode className="w-20 h-20 text-[#2563EB]" />
                    <span className="text-[11px] font-semibold text-slate-500">Scan at Gate Terminal</span>
                  </div>
                )}
              </div>

              <div>
                <h4 className="text-xs font-bold text-[#1E293B] uppercase tracking-wider">
                  Present at College Security Terminal
                </h4>
                <p className="text-[11px] text-slate-500 max-w-sm mx-auto mt-0.5">
                  Point this QR barcode directly towards the security terminal camera scanner for instant verification.
                </p>
              </div>

              {/* Manual Token Fallback for Offline / Hardware failure */}
              {passData.raw_token && (
                <div className="pt-2 border-t border-slate-200/80">
                  <div className="max-w-md mx-auto bg-white border border-slate-200 rounded-xl p-3 flex items-center justify-between gap-3">
                    <div className="text-left overflow-hidden">
                      <span className="text-[10px] text-slate-400 uppercase font-mono block">
                        Manual Verification Token (Fallback)
                      </span>
                      <p className="text-xs font-mono font-bold text-[#1E293B] truncate">
                        {passData.raw_token}
                      </p>
                    </div>

                    <button
                      onClick={copyTokenToClipboard}
                      className="shrink-0 inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-[#2563EB] bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors"
                      title="Copy Token"
                    >
                      {copied ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                          <span className="text-emerald-700">Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>
                  </div>
                  <span className="text-[10px] text-slate-400 mt-1 block">
                    If scanner camera is dirty or offline, the officer can enter this code manually.
                  </span>
                </div>
              )}

            </div>

            {/* Official Instructions */}
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 text-xs text-slate-600 space-y-1.5">
              <span className="font-semibold text-slate-800 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-slate-500" />
                Security Rules & Departure Protocols:
              </span>
              <ul className="list-disc list-inside space-y-1 text-[11px] text-slate-500">
                <li>Present this pass to the on-duty security officer at your designated checkpoint.</li>
                <li>Your student identity and facial likeness will be checked on the terminal monitor.</li>
                <li>Single-use pass immediately transitions to <strong className="text-slate-700">USED</strong> upon departure confirmation.</li>
                <li>Automated departure notice and SMS alert will be dispatched to your registered parent/guardian upon gate exit.</li>
                <li>Ensure return to campus before your specified hostel curfew.</li>
              </ul>
            </div>

          </div>

        </div>

      ) : passData?.status === 'PENDING' ? (

        /* Pending Review State */
        <div className="bg-white border border-slate-200 rounded-2xl p-8 text-center shadow-card space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600 mx-auto">
            <Clock className="w-7 h-7" />
          </div>
          <div>
            <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200 inline-block mb-2">
              Application Under Institutional Review
            </span>
            <h3 className="text-base font-bold text-[#1E293B]">Gate Pass Clearance Pending</h3>
            <p className="text-xs text-slate-500 max-w-md mx-auto mt-2 leading-relaxed">
              {passData.message || 'Your leave application is awaiting final HOD review. Once approved, your cryptographic QR gate pass will be automatically generated here.'}
            </p>
          </div>

          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-100 max-w-sm mx-auto text-xs text-left space-y-1">
            <div className="flex justify-between">
              <span className="text-slate-400">Application ID:</span>
              <span className="font-mono font-semibold text-[#1E293B]">{passData.application_id}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Leave Type:</span>
              <span className="font-semibold text-[#2563EB]">{passData.leave_type}</span>
            </div>
          </div>

          <div className="pt-2">
            <Link
              to="/student/applications"
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold text-[#2563EB] bg-blue-50 hover:bg-blue-100 transition-colors"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Track Application Progress</span>
            </Link>
          </div>
        </div>

      ) : passData?.status === 'REJECTED' ? (

        /* Rejected State */
        <div className="bg-white border border-slate-200 rounded-2xl p-8 text-center shadow-card space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-rose-50 border border-rose-200 flex items-center justify-center text-rose-600 mx-auto">
            <XCircle className="w-7 h-7" />
          </div>
          <div>
            <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200 inline-block mb-2">
              Leave Not Approved
            </span>
            <h3 className="text-base font-bold text-[#1E293B]">No Clearance Authorized</h3>
            <p className="text-xs text-slate-500 max-w-md mx-auto mt-2 leading-relaxed">
              {passData.message || 'Your recent leave request was rejected. Gate pass clearance is only granted for approved outpasses.'}
            </p>
          </div>

          <div className="pt-2">
            <Link
              to="/student/apply"
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-semibold text-white bg-[#2563EB] hover:bg-[#1D4ED8] transition-colors shadow-subtle"
            >
              <span>Submit New Application</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>

      ) : (

        /* No Pass State (NONE) */
        <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center shadow-card space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-slate-100 flex items-center justify-center text-slate-500 mx-auto">
            <Clock className="w-7 h-7" />
          </div>
          <div>
            <h3 className="text-base font-bold text-[#1E293B]">No Active Gate Pass</h3>
            <p className="text-xs text-slate-500 max-w-md mx-auto mt-1 leading-relaxed">
              You currently do not have any active or approved leave clearance. Submit a leave application through the student portal to receive a secure QR gate pass.
            </p>
          </div>

          <div className="pt-2">
            <Link
              to="/student/apply"
              className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-xl text-xs font-semibold text-white bg-[#2563EB] hover:bg-[#1D4ED8] transition-colors shadow-subtle"
            >
              <span>Apply for Outpass / Leave</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>

      )}

    </div>
  );
}
