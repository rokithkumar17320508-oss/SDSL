import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { 
  Send, 
  AlertCircle, 
  CheckCircle2, 
  Calendar, 
  FileText, 
  Info,
  ArrowRight,
  Database,
  Loader2
} from 'lucide-react';
import { saveNewApplication } from '../../data/studentData';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';

const LEAVE_TYPES = [
  { id: 'Regular Leave', label: 'Regular Leave', desc: 'Standard absence from classes for personal or family needs' },
  { id: 'On-Duty', label: 'On-Duty (OD)', desc: 'Official participation in competitions, symposiums, or sports' },
  { id: 'Day Pass', label: 'Day Pass', desc: 'Campus exit during working hours with planned same-day return' },
  { id: 'Hostel Outpass', label: 'Hostel Outpass', desc: 'Overnight or weekend permission to travel outside hostel' },
];

export default function ApplyLeavePage() {
  const navigate = useNavigate();
  const { isAuthenticated, isDemoMode } = useAuth();

  const [leaveType, setLeaveType] = useState('Day Pass');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [reason, setReason] = useState('');
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedApp, setSubmittedApp] = useState(null);

  const validate = () => {
    const errs = {};
    if (!leaveType) errs.leaveType = 'Please select a leave category.';
    if (!startDate) errs.startDate = 'Start date is required.';
    if (!endDate) errs.endDate = 'End date is required.';
    if (startDate && endDate && new Date(endDate) < new Date(startDate)) {
      errs.endDate = 'End date cannot be earlier than start date.';
    }
    if (!reason.trim()) {
      errs.reason = 'Please state a valid reason for your leave request.';
    } else if (reason.trim().length < 5) {
      errs.reason = 'Reason must be at least 5 characters long.';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setServerError('');
    if (!validate()) return;

    setIsSubmitting(true);
    try {
      if (isAuthenticated) {
        const res = await api.createApplication({
          leave_type: leaveType,
          start_date: startDate,
          end_date: endDate,
          reason: reason.trim(),
        });

        if (res.ok && res.data) {
          setSubmittedApp(res.data);
          setStartDate('');
          setEndDate('');
          setReason('');
          setErrors({});
        } else {
          const detail =
            res.data?.end_date?.[0] ||
            res.data?.start_date?.[0] ||
            res.data?.reason?.[0] ||
            res.data?.detail ||
            'Failed to submit leave application. Please check your entries.';
          setServerError(detail);
        }
      } else {
        // Fallback for isolated offline demo mode
        const newApp = saveNewApplication({
          type: leaveType,
          startDate,
          endDate,
          reason: reason.trim(),
        });

        if (newApp) {
          setSubmittedApp(newApp);
          setStartDate('');
          setEndDate('');
          setReason('');
          setErrors({});
        }
      }
    } catch (err) {
      setServerError('An error occurred while submitting the application.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      
      {/* System Status Banner */}
      {isAuthenticated ? (
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 flex items-start gap-3">
          <Database className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
          <div className="text-xs text-emerald-800 leading-relaxed">
            <strong className="font-semibold text-emerald-900">PostgreSQL Connected: </strong>
            Your leave application will be recorded in the live database and forwarded to your assigned Faculty Advisor for academic verification.
          </div>
        </div>
      ) : (
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 flex items-start gap-3">
          <Info className="w-4 h-4 text-[#2563EB] shrink-0 mt-0.5" />
          <div className="text-xs text-slate-600 leading-relaxed">
            <strong className="text-[#1E293B] font-semibold">Frontend Prototype Notice: </strong>
            Submitted leave applications are stored in your browser's <code className="bg-white px-1.5 py-0.5 rounded border border-blue-200 font-mono text-blue-900">localStorage</code>. 
            Applications remain available across refreshes and appear under status <span className="font-semibold text-amber-800">Pending</span>.
          </div>
        </div>
      )}

      {/* Server Error Alert */}
      {serverError && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-center gap-3 text-xs text-red-700">
          <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
          <span>{serverError}</span>
        </div>
      )}

      {/* Success Dialog */}
      {submittedApp ? (
        <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 shadow-subtle text-center space-y-4">
          <div className="w-12 h-12 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-600 flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-6 h-6" />
          </div>

          <div>
            <h2 className="text-lg font-bold text-[#1E293B]">Leave Request Submitted</h2>
            <p className="text-xs text-slate-500 mt-1">
              Your application has been logged and assigned Application ID:
            </p>
            <p className="text-base font-mono font-bold text-[#2563EB] mt-1">
              {submittedApp.id}
            </p>
          </div>

          <div className="bg-slate-50 border border-slate-100 rounded-lg p-3 text-xs text-slate-600 max-w-sm mx-auto space-y-1">
            <div className="flex justify-between">
              <span className="text-slate-400">Category:</span>
              <span className="font-medium text-[#1E293B]">{submittedApp.type}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Initial Status:</span>
              <span className="font-semibold text-amber-700">{submittedApp.status}</span>
            </div>
          </div>

          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
            <Link
              to="/student/applications"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg text-xs font-semibold text-white bg-[#2563EB] hover:bg-[#1D4ED8] transition-colors"
            >
              <span>View All Applications</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>

            <button
              onClick={() => setSubmittedApp(null)}
              className="w-full sm:w-auto px-4 py-2.5 rounded-lg text-xs font-semibold text-slate-600 hover:text-[#1E293B] hover:bg-slate-100 transition-colors"
            >
              Apply Another
            </button>
          </div>
        </div>
      ) : (
        /* Leave Form Card */
        <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 shadow-subtle space-y-6">
          
          <div className="border-b border-slate-100 pb-4">
            <h2 className="text-base font-bold text-[#1E293B]">Apply for Leave / Gate Pass</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Fill in your departure details for faculty and department endorsement.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            
            {/* Leave Type Selector */}
            <div className="space-y-2">
              <label className="block text-xs font-semibold text-[#1E293B]">
                Leave Category <span className="text-red-500">*</span>
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {LEAVE_TYPES.map((type) => {
                  const isSelected = leaveType === type.id;
                  return (
                    <button
                      key={type.id}
                      type="button"
                      onClick={() => {
                        setLeaveType(type.id);
                        if (errors.leaveType) setErrors({ ...errors, leaveType: null });
                      }}
                      className={`text-left p-3 rounded-lg border transition-all ${
                        isSelected
                          ? 'bg-blue-50/70 border-[#2563EB] ring-1 ring-[#2563EB]'
                          : 'bg-white border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className={`text-xs font-bold ${isSelected ? 'text-[#2563EB]' : 'text-[#1E293B]'}`}>
                          {type.label}
                        </span>
                        <span className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${isSelected ? 'border-[#2563EB] bg-[#2563EB]' : 'border-slate-300'}`}>
                          {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-white"></span>}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-1 leading-snug">
                        {type.desc}
                      </p>
                    </button>
                  );
                })}
              </div>
              {errors.leaveType && (
                <p className="text-[11px] text-red-600 mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>{errors.leaveType}</span>
                </p>
              )}
            </div>

            {/* Date Range Inputs */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              
              {/* Start Date */}
              <div className="space-y-1.5">
                <label htmlFor="startDate" className="block text-xs font-semibold text-[#1E293B]">
                  Start Date <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <input
                    id="startDate"
                    type="date"
                    value={startDate}
                    onChange={(e) => {
                      setStartDate(e.target.value);
                      if (errors.startDate) setErrors({ ...errors, startDate: null });
                    }}
                    className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-lg text-[#1E293B] focus:outline-none focus:border-[#2563EB] focus:ring-1 focus:ring-[#2563EB]"
                  />
                </div>
                {errors.startDate && (
                  <p className="text-[11px] text-red-600 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>{errors.startDate}</span>
                  </p>
                )}
              </div>

              {/* End Date */}
              <div className="space-y-1.5">
                <label htmlFor="endDate" className="block text-xs font-semibold text-[#1E293B]">
                  End Date <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <input
                    id="endDate"
                    type="date"
                    value={endDate}
                    onChange={(e) => {
                      setEndDate(e.target.value);
                      if (errors.endDate) setErrors({ ...errors, endDate: null });
                    }}
                    className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-lg text-[#1E293B] focus:outline-none focus:border-[#2563EB] focus:ring-1 focus:ring-[#2563EB]"
                  />
                </div>
                {errors.endDate && (
                  <p className="text-[11px] text-red-600 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>{errors.endDate}</span>
                  </p>
                )}
              </div>

            </div>

            {/* Reason Textarea */}
            <div className="space-y-1.5">
              <label htmlFor="reason" className="block text-xs font-semibold text-[#1E293B]">
                Reason for Leave <span className="text-red-500">*</span>
              </label>
              <textarea
                id="reason"
                rows={3}
                value={reason}
                onChange={(e) => {
                  setReason(e.target.value);
                  if (errors.reason) setErrors({ ...errors, reason: null });
                }}
                placeholder="State the purpose of leave or visit destination clearly..."
                className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-lg text-[#1E293B] placeholder-slate-400 focus:outline-none focus:border-[#2563EB] focus:ring-1 focus:ring-[#2563EB]"
              ></textarea>
              {errors.reason && (
                <p className="text-[11px] text-red-600 mt-0.5 flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>{errors.reason}</span>
                </p>
              )}
            </div>

            {/* Submit Button */}
            <div className="pt-2 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => navigate('/student')}
                className="px-4 py-2 rounded-lg text-xs font-semibold text-slate-600 hover:text-[#1E293B] hover:bg-slate-100 transition-colors"
              >
                Cancel
              </button>

              <button
                type="submit"
                disabled={isSubmitting}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg text-xs font-semibold text-white bg-[#2563EB] hover:bg-[#1D4ED8] transition-colors shadow-subtle disabled:opacity-60"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Submitting...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-3.5 h-3.5" />
                    <span>Submit Application</span>
                  </>
                )}
              </button>
            </div>

          </form>

        </div>
      )}

    </div>
  );
}
