import React from 'react';
import { User, Mail, Phone, BookOpen, GraduationCap, Building2, Calendar, ShieldCheck, HeartHandshake } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { SAMPLE_STUDENT } from '../../data/studentData';
import { BRAND } from '../../config/branding';

export default function StudentProfilePage() {
  const { user } = useAuth();
  const academic = user?.academic_details || {};
  const parentName = academic.parent_name || 'Sunil Sharma';
  const parentEmail = academic.parent_email || 'parent.sharma@campusora.edu';
  const parentPhone = academic.parent_phone || '+91 98765 00001';
  const hostelBlock = academic.hostel_block || 'BH-2';
  const roomNumber = academic.room_number || 'BH-2, Room 405';

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      
      {/* Profile Overview Card */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-subtle flex flex-col sm:flex-row items-center sm:items-start gap-5">
        <div className="w-16 h-16 rounded-2xl bg-blue-50 border border-blue-100 flex items-center justify-center text-[#2563EB] text-xl font-bold shrink-0">
          AS
        </div>

        <div className="space-y-1 text-center sm:text-left flex-1">
          <div className="flex flex-col sm:flex-row sm:items-center gap-2">
            <h2 className="text-lg font-bold text-[#1E293B]">{SAMPLE_STUDENT.name}</h2>
            <span className="inline-block text-xs font-mono font-medium text-slate-500 bg-slate-100 px-2 py-0.5 rounded w-max mx-auto sm:mx-0">
              {SAMPLE_STUDENT.regNo}
            </span>
          </div>
          <p className="text-xs text-slate-500">
            {SAMPLE_STUDENT.degree} • {SAMPLE_STUDENT.department}
          </p>
          <div className="pt-2 flex items-center justify-center sm:justify-start gap-2">
            <span className="text-[11px] font-medium text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
              Active Student Status
            </span>
            <span className="text-[11px] font-medium text-slate-600 bg-slate-100 px-2 py-0.5 rounded-full">
              Attendance: {SAMPLE_STUDENT.attendance}%
            </span>
          </div>
        </div>
      </div>

      {/* Academic Details Card */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-subtle p-6 space-y-4">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
          Academic Information
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
            <span className="text-slate-400 text-[11px] flex items-center gap-1.5 mb-1">
              <GraduationCap className="w-3.5 h-3.5 text-[#2563EB]" />
              <span>Year of Study</span>
            </span>
            <p className="font-semibold text-[#1E293B]">{SAMPLE_STUDENT.year}</p>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
            <span className="text-slate-400 text-[11px] flex items-center gap-1.5 mb-1">
              <Calendar className="w-3.5 h-3.5 text-[#2563EB]" />
              <span>Current Semester</span>
            </span>
            <p className="font-semibold text-[#1E293B]">{SAMPLE_STUDENT.semester}</p>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
            <span className="text-slate-400 text-[11px] flex items-center gap-1.5 mb-1">
              <BookOpen className="w-3.5 h-3.5 text-[#2563EB]" />
              <span>Class Section</span>
            </span>
            <p className="font-semibold text-[#1E293B]">{SAMPLE_STUDENT.section}</p>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
            <span className="text-slate-400 text-[11px] flex items-center gap-1.5 mb-1">
              <User className="w-3.5 h-3.5 text-[#2563EB]" />
              <span>Faculty Advisor</span>
            </span>
            <p className="font-semibold text-[#1E293B]">{SAMPLE_STUDENT.facultyAdvisor}</p>
          </div>

        </div>
      </div>

      {/* Contact & Accommodation Card */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-subtle p-6 space-y-4">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
          Contact & Campus Residence
        </h3>

        <div className="space-y-3 text-xs">
          
          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100">
            <span className="text-slate-500 flex items-center gap-2">
              <Mail className="w-4 h-4 text-slate-400" />
              <span>Institutional Email</span>
            </span>
            <span className="font-medium text-[#1E293B]">{SAMPLE_STUDENT.email}</span>
          </div>

          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100">
            <span className="text-slate-500 flex items-center gap-2">
              <Phone className="w-4 h-4 text-slate-400" />
              <span>Contact Number</span>
            </span>
            <span className="font-medium text-[#1E293B]">{SAMPLE_STUDENT.phone}</span>
          </div>

          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100">
            <span className="text-slate-500 flex items-center gap-2">
              <Building2 className="w-4 h-4 text-slate-400" />
              <span>Hostel Residence</span>
            </span>
            <span className="font-medium text-[#1E293B]">{hostelBlock} ({roomNumber})</span>
          </div>

        </div>
      </div>

      {/* Verified Parent & Guardian Alert Destination Card (Day 8 Feature) */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-subtle p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#2563EB]" />
            <span>Verified Parent / Guardian Alert Channels</span>
          </h3>
          <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
            Active Alerts
          </span>
        </div>

        <p className="text-xs text-slate-500">
          Automated email departure notices and SMS alerts are dispatched to these verified contacts whenever campus gate security confirms your exit.
        </p>

        <div className="space-y-3 text-xs">
          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100">
            <span className="text-slate-500 flex items-center gap-2">
              <User className="w-4 h-4 text-slate-400" />
              <span>Parent / Legal Guardian</span>
            </span>
            <span className="font-medium text-[#1E293B]">{parentName}</span>
          </div>

          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100">
            <span className="text-slate-500 flex items-center gap-2">
              <Mail className="w-4 h-4 text-slate-400" />
              <span>Departure Alert Email</span>
            </span>
            <span className="font-medium text-[#1E293B]">{parentEmail}</span>
          </div>

          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100">
            <span className="text-slate-500 flex items-center gap-2">
              <Phone className="w-4 h-4 text-slate-400" />
              <span>Departure Alert SMS</span>
            </span>
            <span className="font-medium text-[#1E293B]">{parentPhone}</span>
          </div>
        </div>
      </div>

    </div>
  );
}
