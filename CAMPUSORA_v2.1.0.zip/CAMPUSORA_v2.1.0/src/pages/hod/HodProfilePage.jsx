import React from 'react';
import { User, Mail, Phone, Building2, BookOpen, ShieldCheck, Award } from 'lucide-react';
import { SAMPLE_HOD } from '../../data/studentData';
import { BRAND } from '../../config/branding';

export default function HodProfilePage() {
  return (
    <div className="max-w-2xl mx-auto space-y-6">
      
      {/* Profile Overview Card */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-subtle flex flex-col sm:flex-row items-center sm:items-start gap-5">
        <div className="w-16 h-16 rounded-2xl bg-purple-50 border border-purple-100 flex items-center justify-center text-purple-700 text-xl font-bold shrink-0">
          RM
        </div>

        <div className="space-y-1 text-center sm:text-left flex-1">
          <div className="flex flex-col sm:flex-row sm:items-center gap-2">
            <h2 className="text-lg font-bold text-[#1E293B]">{SAMPLE_HOD.name}</h2>
            <span className="inline-block text-xs font-mono font-medium text-slate-500 bg-slate-100 px-2 py-0.5 rounded w-max mx-auto sm:mx-0">
              {SAMPLE_HOD.employeeId}
            </span>
          </div>
          <p className="text-xs text-slate-500">
            {SAMPLE_HOD.designation} • {SAMPLE_HOD.department}
          </p>
          <div className="pt-2 flex items-center justify-center sm:justify-start gap-2">
            <span className="text-[11px] font-medium text-purple-700 bg-purple-50 border border-purple-200 px-2.5 py-0.5 rounded-full">
              Final Approval Authority
            </span>
            <span className="text-[11px] font-medium text-slate-600 bg-slate-100 px-2.5 py-0.5 rounded-full">
              CSE Department Chair
            </span>
          </div>
        </div>
      </div>

      {/* Departmental Authority Details */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-subtle p-6 space-y-4">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
          Departmental Authority & Overview
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
            <span className="text-slate-400 text-[11px] flex items-center gap-1.5 mb-1">
              <Building2 className="w-3.5 h-3.5 text-[#2563EB]" />
              <span>Department</span>
            </span>
            <p className="font-semibold text-[#1E293B]">{SAMPLE_HOD.department}</p>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
            <span className="text-slate-400 text-[11px] flex items-center gap-1.5 mb-1">
              <Award className="w-3.5 h-3.5 text-[#2563EB]" />
              <span>Executive Responsibility</span>
            </span>
            <p className="font-semibold text-[#1E293B]">Final Outpass Clearance & OD Approvals</p>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 sm:col-span-2">
            <span className="text-slate-400 text-[11px] flex items-center gap-1.5 mb-1">
              <ShieldCheck className="w-3.5 h-3.5 text-[#2563EB]" />
              <span>Role in 4-Stage Architecture</span>
            </span>
            <p className="text-slate-600 leading-relaxed text-[11px]">
              Final academic approval authority. Once the HOD signs an application, it converts into an authorized gate clearance outpass, logging the departure authorization to the Main Security Gate.
            </p>
          </div>
        </div>
      </div>

      {/* Office & Contact Card */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-subtle p-6 space-y-4">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
          Office & Contact Information
        </h3>

        <div className="space-y-3 text-xs">
          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100">
            <span className="text-slate-500 flex items-center gap-2">
              <Mail className="w-4 h-4 text-slate-400" />
              <span>Executive Email</span>
            </span>
            <span className="font-medium text-[#1E293B]">{SAMPLE_HOD.email}</span>
          </div>

          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100">
            <span className="text-slate-500 flex items-center gap-2">
              <Phone className="w-4 h-4 text-slate-400" />
              <span>Office Phone</span>
            </span>
            <span className="font-medium text-[#1E293B]">{SAMPLE_HOD.phone}</span>
          </div>

          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100">
            <span className="text-slate-500 flex items-center gap-2">
              <Building2 className="w-4 h-4 text-slate-400" />
              <span>Office Location</span>
            </span>
            <span className="font-medium text-[#1E293B]">{SAMPLE_HOD.officeRoom}</span>
          </div>
        </div>
      </div>

    </div>
  );
}
