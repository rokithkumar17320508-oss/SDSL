import React, { useState, useEffect } from 'react';
import { 
  CheckSquare, 
  Search, 
  Check, 
  X, 
  Eye, 
  AlertCircle, 
  CheckCircle2, 
  FileText,
  User,
  Calendar,
  MessageSquare,
  RefreshCw,
  Loader2,
  Database
} from 'lucide-react';
import { getStoredApplications, updateApplicationStatus } from '../../data/studentData';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';

export default function HodApprovalsPage() {
  const { isAuthenticated, isDemoMode } = useAuth();
  const [applications, setApplications] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);

  // Modal & Confirmation States
  const [selectedApp, setSelectedApp] = useState(null);
  const [actionType, setActionType] = useState(null); // 'approve' | 'reject' | 'view'
  const [remarks, setRemarks] = useState('');
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [validationError, setValidationError] = useState('');
  const [successToast, setSuccessToast] = useState('');

  const loadData = async () => {
    setLoading(true);
    try {
      if (isAuthenticated) {
        const res = await api.getApplications();
        if (res.ok && res.data) {
          const list = Array.isArray(res.data) ? res.data : (res.data.results || []);
          // In HOD pending approvals page, show applications awaiting HOD review
          const pendingHOD = list.filter((app) => app.status === 'Pending HOD Review');
          setApplications(pendingHOD);
        } else {
          setApplications([]);
        }
      } else {
        const all = getStoredApplications();
        const pendingHOD = all.filter((app) => app.status === 'Pending HOD Review');
        setApplications(pendingHOD);
      }
    } catch (err) {
      console.error('Failed to load HOD applications:', err);
      setApplications([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [isAuthenticated, isDemoMode]);

  const handleOpenAction = (app, type) => {
    setSelectedApp(app);
    setActionType(type);
    setRemarks(
      type === 'approve'
        ? 'Final departmental clearance granted. Digital pass authorized for gate exit.'
        : ''
    );
    setValidationError('');
    setShowConfirmModal(true);
  };

  const handleConfirmAction = async () => {
    if (actionType === 'reject' && !remarks.trim()) {
      setValidationError('Please provide a mandatory reason for denying this final clearance.');
      return;
    }

    setIsProcessing(true);
    setValidationError('');
    try {
      if (isAuthenticated) {
        if (actionType === 'approve') {
          const res = await api.approveApplication(selectedApp.id, remarks.trim());
          if (res.ok) {
            setSuccessToast(`Application ${selectedApp.id} has received final HOD approval.`);
            setShowConfirmModal(false);
            setSelectedApp(null);
            setRemarks('');
            loadData();
          } else {
            setValidationError(res.data?.detail || 'Failed to approve application.');
            return;
          }
        } else if (actionType === 'reject') {
          const res = await api.rejectApplication(selectedApp.id, remarks.trim());
          if (res.ok) {
            setSuccessToast(`Application ${selectedApp.id} has been rejected by HOD.`);
            setShowConfirmModal(false);
            setSelectedApp(null);
            setRemarks('');
            loadData();
          } else {
            setValidationError(res.data?.detail || 'Failed to reject application.');
            return;
          }
        }
      } else {
        const newStatus = actionType === 'approve' ? 'HOD Approved' : 'Rejected';
        updateApplicationStatus(selectedApp.id, newStatus, remarks.trim(), 'hod');

        setSuccessToast(
          actionType === 'approve'
            ? `Application ${selectedApp.id} has received final HOD approval.`
            : `Application ${selectedApp.id} has been rejected by HOD.`
        );

        setShowConfirmModal(false);
        setSelectedApp(null);
        setRemarks('');
        loadData();
      }
    } catch (err) {
      setValidationError(err.message || 'Operation failed. Please retry.');
      return;
    } finally {
      setIsProcessing(false);
    }

    setTimeout(() => setSuccessToast(''), 4000);
  };

  const filteredApps = applications.filter((app) =>
    (app.id || '').toLowerCase().includes(search.toLowerCase()) ||
    (app.studentName || '').toLowerCase().includes(search.toLowerCase()) ||
    (app.regNo || '').toLowerCase().includes(search.toLowerCase()) ||
    (app.type || '').toLowerCase().includes(search.toLowerCase()) ||
    (app.reason || '').toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-[#1E293B]">Pending HOD Approvals</h2>
          <p className="text-xs text-slate-500">
            Final authorization desk. Only applications verified and endorsed by class faculty advisors appear in this queue.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0 self-start sm:self-auto">
          <button
            onClick={loadData}
            disabled={loading}
            title="Refresh pending approvals"
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold text-slate-600 bg-white border border-slate-200 hover:bg-slate-50 transition-colors shadow-subtle disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>

          <div className="relative w-full sm:w-64">
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search pending queue..."
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg text-[#1E293B] placeholder-slate-400 focus:outline-none focus:border-[#2563EB]"
            />
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
          </div>
        </div>
      </div>

      {/* Success Toast */}
      {successToast && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs p-3.5 rounded-xl flex items-center justify-between shadow-subtle animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{successToast}</span>
          </div>
          <button onClick={() => setSuccessToast('')} className="text-emerald-600 hover:text-emerald-800">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Approvals Table Card */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-subtle overflow-hidden">
        {loading ? (
          <div className="p-12 text-center space-y-2">
            <Loader2 className="w-8 h-8 text-[#2563EB] animate-spin mx-auto" />
            <p className="text-xs text-slate-500">Loading forwarded applications from PostgreSQL...</p>
          </div>
        ) : filteredApps.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-500 space-y-1">
            <CheckSquare className="w-8 h-8 text-slate-300 mx-auto" />
            <p className="font-semibold text-slate-700">No applications pending HOD clearance</p>
            <p className="text-slate-400">All forwarded requests have been evaluated and authorized.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-medium">
                <tr>
                  <th className="px-5 py-3">ID</th>
                  <th className="px-5 py-3">Student Name</th>
                  <th className="px-5 py-3">Reg Number</th>
                  <th className="px-5 py-3">Leave Type</th>
                  <th className="px-5 py-3">Dates</th>
                  <th className="px-5 py-3">Faculty Endorsement</th>
                  <th className="px-5 py-3 text-right">Clearance Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {filteredApps.map((app) => (
                  <tr key={app.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-5 py-3.5 font-mono font-semibold text-slate-700">
                      {app.id}
                    </td>
                    <td className="px-5 py-3.5 font-semibold text-[#1E293B]">
                      {app.studentName}
                    </td>
                    <td className="px-5 py-3.5 font-mono text-slate-500 text-[11px]">
                      {app.regNo}
                    </td>
                    <td className="px-5 py-3.5 font-medium text-slate-800">
                      {app.type}
                    </td>
                    <td className="px-5 py-3.5 text-slate-600">
                      {app.startDate === app.endDate
                        ? app.startDate
                        : `${app.startDate} — ${app.endDate}`}
                    </td>
                    <td className="px-5 py-3.5 text-slate-600 max-w-xs truncate" title={app.facultyRemarks || 'Attendance verified'}>
                      <span className="inline-block px-2 py-0.5 rounded bg-blue-50 text-blue-700 text-[11px]">
                        {app.facultyRemarks || 'Attendance verified. Recommended.'}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleOpenAction(app, 'view')}
                          className="px-2 py-1 rounded text-slate-600 hover:text-[#1E293B] hover:bg-slate-100 text-[11px] font-medium"
                        >
                          View
                        </button>
                        <button
                          type="button"
                          onClick={() => handleOpenAction(app, 'reject')}
                          className="px-2 py-1 rounded bg-red-50 text-red-600 hover:bg-red-100 text-[11px] font-medium"
                        >
                          Deny
                        </button>
                        <button
                          type="button"
                          onClick={() => handleOpenAction(app, 'approve')}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-semibold shadow-subtle"
                        >
                          <Check className="w-3 h-3" />
                          <span>Approve</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Confirmation & Details Modal */}
      {showConfirmModal && selectedApp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-xl shadow-xl max-w-lg w-full p-6 space-y-4 border border-slate-200">
            
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <span className="font-mono font-bold text-xs bg-slate-100 px-2 py-0.5 rounded text-slate-700">
                  {selectedApp.id}
                </span>
                <h3 className="font-bold text-sm text-[#1E293B]">
                  {actionType === 'approve' && 'Authorize Departmental Leave Clearance'}
                  {actionType === 'reject' && 'Deny Student Leave Application'}
                  {actionType === 'view' && 'Leave Application Details'}
                </h3>
              </div>
              <button 
                onClick={() => setShowConfirmModal(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Applicant Details */}
            <div className="bg-slate-50 p-3.5 rounded-lg border border-slate-100 text-xs space-y-2">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="text-slate-400 text-[11px]">Student</span>
                  <p className="font-semibold text-[#1E293B]">{selectedApp.studentName}</p>
                </div>
                <div>
                  <span className="text-slate-400 text-[11px]">Roll / Reg Number</span>
                  <p className="font-mono text-slate-700">{selectedApp.regNo}</p>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-200">
                <span className="text-slate-400 text-[11px]">Departure & Return Dates</span>
                <p className="font-medium text-[#1E293B]">
                  {selectedApp.startDate} to {selectedApp.endDate}
                </p>
              </div>

              <div>
                <span className="text-slate-400 text-[11px]">Student Stated Reason</span>
                <p className="text-slate-700 bg-white p-2.5 rounded-lg border border-slate-200 mt-0.5">
                  {selectedApp.reason}
                </p>
              </div>

              <div>
                <span className="text-slate-400 text-[11px]">Faculty Mentor Endorsement</span>
                <p className="text-blue-900 bg-blue-50 p-2.5 rounded-lg border border-blue-200 mt-0.5">
                  {selectedApp.facultyRemarks || 'Class mentor has verified attendance and granted initial endorsement.'}
                </p>
              </div>
            </div>

            {actionType !== 'view' && (
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-[#1E293B]">
                  {actionType === 'approve'
                    ? 'HOD Remarks & Outpass Conditions (Optional)'
                    : 'Reason for Denial (Mandatory) *'}
                </label>
                <textarea
                  rows={2}
                  value={remarks}
                  onChange={(e) => {
                    setRemarks(e.target.value);
                    if (validationError) setValidationError('');
                  }}
                  placeholder={
                    actionType === 'approve'
                      ? 'Add any departmental conditions or gate return instructions...'
                      : 'Specify the reason for refusing outpass clearance...'
                  }
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-lg text-[#1E293B] placeholder-slate-400 focus:outline-none focus:border-[#2563EB]"
                ></textarea>
                {validationError && (
                  <p className="text-[11px] text-red-600 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>{validationError}</span>
                  </p>
                )}
              </div>
            )}

            {/* Advisory */}
            {isAuthenticated ? (
              <div className="p-2.5 rounded-lg bg-emerald-50 border border-emerald-200 text-[11px] text-emerald-900 leading-snug flex items-start gap-2">
                <Database className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <strong className="font-semibold">PostgreSQL Database: </strong>
                  Your final approval decision and digital clearance authorization are recorded in the PostgreSQL audit log.
                </div>
              </div>
            ) : (
              <div className="p-2.5 rounded-lg bg-amber-50 border border-amber-200 text-[11px] text-amber-900 leading-snug">
                <strong className="font-semibold">Prototype Simulation Notice: </strong>
                This action simulates final HOD clearance stored in local browser memory (<code className="font-mono bg-white px-1 rounded">localStorage</code>). 
                This is a frontend demonstration without real backend authorization or multi-user sync.
              </div>
            )}

            <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-slate-100">
              <button
                type="button"
                disabled={isProcessing}
                onClick={() => setShowConfirmModal(false)}
                className="px-4 py-2 rounded-lg text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors disabled:opacity-50"
              >
                {actionType === 'view' ? 'Close' : 'Cancel'}
              </button>

              {actionType === 'approve' && (
                <button
                  type="button"
                  disabled={isProcessing}
                  onClick={handleConfirmAction}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 transition-colors shadow-subtle disabled:opacity-60"
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Approving...</span>
                    </>
                  ) : (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>{isAuthenticated ? 'Grant Final Approval' : 'Simulate: Grant Final Approval'}</span>
                    </>
                  )}
                </button>
              )}

              {actionType === 'reject' && (
                <button
                  type="button"
                  disabled={isProcessing}
                  onClick={handleConfirmAction}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold text-white bg-red-600 hover:bg-red-700 transition-colors shadow-subtle disabled:opacity-60"
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Rejecting...</span>
                    </>
                  ) : (
                    <>
                      <X className="w-3.5 h-3.5" />
                      <span>{isAuthenticated ? 'Deny Clearance' : 'Simulate: Reject Request'}</span>
                    </>
                  )}
                </button>
              )}
            </div>

          </div>
        </div>
      )}

    </div>
  );
}