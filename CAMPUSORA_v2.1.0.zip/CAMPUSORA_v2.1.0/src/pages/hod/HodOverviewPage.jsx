import React from 'react';
import AnalyticsView from '../../components/AnalyticsView';
import { useAuth } from '../../context/AuthContext';

export default function HodOverviewPage() {
  const { user } = useAuth();
  const dept = user?.department || 'Computer Science & Engineering';

  return (
    <div className="space-y-6">
      <AnalyticsView 
        title={`Department Mobility Analytics — ${dept}`}
        subtitle={`Real-time PostgreSQL tracking of ${dept} student departures, return entries, and curfew overdues.`}
      />
    </div>
  );
}
