import React, { useState, useEffect } from 'react';
import { 
  X, 
  User, 
  Calendar, 
  Clock, 
  CheckCircle, 
  XCircle, 
  AlertCircle, 
  Building2, 
  Home, 
  Phone, 
  Mail, 
  ShieldCheck, 
  FileText, 
  Award,
  Loader2
} from 'lucide-react';
import { api } from '../../services/api';
import { getFallbackStudentProfile } from '../../data/demoSectionsData';

export default function HodStudentProfileModal({ studentId, onClose }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!studentId) return;

    let isMounted = true;
    const fetchProfile = async () => {
      setLoading(true);
      setError(null);
      try {
        const res = await api.getStudentLeaveProfile(studentId);
        if (isMounted) {
          if (res.ok && res.data) {
            setData(res.data);
          } else {
            // Fallback for demo or offline mode
            const fallback = getFallbackStudentProfile(studentId);
            setData(fallback);
          }
        }
      } catch (err) {
        if (isMounted) {
          const fallback = getFallbackStudentProfile(studentId);
          setData(fallback);
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    fetchProfile();

    const handleKeyDown = (e) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      isMounted = false;
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [studentId, onClose]);

  const getStatusBadge = (status) => {
    switch (status) {
      case 'HOD Approved':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <CheckCircle className="w-3 h-3" />
            Approved
          </span>
        );
      case 'Pending HOD Review':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-amber-50 text-amber-800 border border-amber-200">
            <Clock className="w-3 h-3" />
            Pending HOD
          </span>
        );
      case 'Pending Faculty Review':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-blue-50 text-blue-700 border border-blue-200">
            <Clock className="w-3 h-3" />
            Pending Faculty
          </span>
        );
      case 'Rejected':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-red-50 text-red-700 border border-red-200">
            <XCircle className="w-3 h-3" />
            Rejected
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-700">
            {status}
          </span>
        );
    }
  };

  const getLeaveTypeBadge = (type) => {
    switch (type) {
      case 'On-Duty':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-purple-50 text-purple-700 border border-purple-200">
            On-Duty (OD)
          </span>
        );
      case 'Hostel Outpass':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200">
            Hostel Outpass
          </span>
        );
      case 'Day Pass':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-sky-50 text-sky-700 border border-sky-200">
            Day Pass
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-100 text-slate-800 border border-slate-200">
            Regular Leave
          </span>
        );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/50 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden animate-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        
        {/* Header Bar */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-slate-950 font-bold text-sm shadow-md">
              <User className="w-5 h-5 text-slate-900" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">
                Student Profile & Leave Audit Dossier
              </h2>
              <p className="text-xs text-slate-400">
                Departmental Executive Dossier • Computer Science & Engineering
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-slate-800">
          {loading ? (
            <div className="py-20 text-center flex flex-col items-center justify-center gap-3 text-slate-500">
              <Loader2 className="w-8 h-8 animate-spin text-[#2563EB]" />
              <p className="text-sm font-medium">Fetching individual leave statistics from PostgreSQL...</p>
            </div>
          ) : error ? (
            <div className="p-6 bg-red-50 border border-red-200 rounded-xl text-red-700 flex items-center gap-3">
              <AlertCircle className="w-5 h-5 shrink-0" />
              <p className="text-sm">{error}</p>
            </div>
          ) : data ? (
            <>
              {/* Student Bio Card */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-5">
                <div className="flex items-center gap-4">
                  <div className="relative shrink-0">
                    <img
                      src={data.student_information.photo_url}
                      alt={data.student_information.name}
                      className="w-16 h-16 rounded-2xl object-cover border-2 border-white shadow-md bg-slate-200"
                    />
                    <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-emerald-500 border-2 border-white flex items-center justify-center text-white text-[9px] font-bold">
                      ✓
                    </span>
                  </div>

                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-lg font-bold text-[#0F172A]">
                        {data.student_information.name}
                      </h3>
                      <span className="font-mono text-xs font-semibold px-2 py-0.5 rounded bg-slate-200 text-slate-800">
                        {data.student_information.register_number}
                      </span>
                      <span className="text-xs font-semibold px-2 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-300">
                        {data.student_information.section}
                      </span>
                    </div>

                    <p className="text-xs text-slate-600 mt-1">
                      {data.student_information.department} • Year {data.student_information.year} • Semester 2
                    </p>

                    <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500 mt-2">
                      <span className="flex items-center gap-1 font-medium text-slate-700">
                        <Home className="w-3.5 h-3.5 text-slate-400" />
                        {data.student_information.student_type}
                      </span>
                      {data.student_information.room_number && (
                        <span>{data.student_information.room_number}</span>
                      )}
                      <span className="flex items-center gap-1 text-slate-500">
                        <ShieldCheck className="w-3.5 h-3.5 text-purple-600" />
                        Advisor: {data.student_information.advisor_name}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Parent Contact Pill */}
                <div className="bg-white border border-slate-200 rounded-xl p-3 text-xs space-y-1 shrink-0 w-full md:w-auto">
                  <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Guardian Contact</p>
                  <p className="font-semibold text-slate-800">{data.student_information.parent_name || 'Guardian'}</p>
                  <div className="flex items-center gap-2 text-slate-600 font-mono text-[11px]">
                    <Phone className="w-3 h-3 text-emerald-600" />
                    <span>{data.student_information.parent_phone || 'N/A'}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-600 text-[11px]">
                    <Mail className="w-3 h-3 text-blue-600" />
                    <span className="truncate max-w-[180px]">{data.student_information.parent_email || 'N/A'}</span>
                  </div>
                </div>
              </div>

              {/* Leave Statistics Grid (Feature 3) */}
              <div>
                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">
                  Departmental Leave Statistics & Accrual
                </h4>

                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
                  
                  {/* Total Applications */}
                  <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-sm">
                    <p className="text-[11px] font-medium text-slate-500">Total Applications</p>
                    <p className="text-xl font-bold text-[#0F172A] mt-0.5">
                      {data.leave_statistics.total_applications}
                    </p>
                    <p className="text-[10px] text-slate-400 mt-0.5">Submitted all-time</p>
                  </div>

                  {/* Approved Applications */}
                  <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-sm">
                    <p className="text-[11px] font-medium text-slate-500">Approved Passes</p>
                    <p className="text-xl font-bold text-emerald-600 mt-0.5">
                      {data.leave_statistics.approved_applications}
                    </p>
                    <p className="text-[10px] text-emerald-700/80 mt-0.5">Sanctioned by HOD</p>
                  </div>

                  {/* Total Approved Leave Days */}
                  <div className="bg-white border border-amber-200 bg-amber-50/40 rounded-xl p-3.5 shadow-sm">
                    <p className="text-[11px] font-bold text-amber-900">Approved Leave Days</p>
                    <p className="text-xl font-extrabold text-amber-700 mt-0.5">
                      {data.leave_statistics.total_approved_leave_days} <span className="text-xs font-semibold">Days</span>
                    </p>
                    <p className="text-[10px] text-amber-800/80 mt-0.5">Excluding OD & Hostel</p>
                  </div>

                  {/* Pending Approvals */}
                  <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-sm">
                    <p className="text-[11px] font-medium text-slate-500">Pending Review</p>
                    <p className="text-xl font-bold text-[#EAB308] mt-0.5">
                      {data.leave_statistics.pending_applications}
                    </p>
                    <p className="text-[10px] text-slate-400 mt-0.5">In approval queue</p>
                  </div>

                  {/* Rejected */}
                  <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-sm">
                    <p className="text-[11px] font-medium text-slate-500">Rejected</p>
                    <p className="text-xl font-bold text-red-600 mt-0.5">
                      {data.leave_statistics.rejected_applications}
                    </p>
                    <p className="text-[10px] text-slate-400 mt-0.5">Policy violations</p>
                  </div>

                </div>

                {/* Granular Sub-Category Counters (Separated OD, Hostel, Regular as per Feature 3 & 4) */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-3">
                  
                  {/* On-Duty (OD) */}
                  <div className="bg-purple-50/60 border border-purple-200 rounded-xl p-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold text-purple-900">On-Duty (OD)</span>
                      <Award className="w-3.5 h-3.5 text-purple-600" />
                    </div>
                    <p className="text-lg font-bold text-purple-800 mt-1">
                      {data.leave_statistics.od_count} <span className="text-xs font-normal text-purple-600">({data.leave_statistics.od_days} Days)</span>
                    </p>
                    <p className="text-[10px] text-purple-700/80 mt-0.5">Hackathons & Symposia</p>
                  </div>

                  {/* Hostel Outpass */}
                  <div className="bg-indigo-50/60 border border-indigo-200 rounded-xl p-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold text-indigo-900">Hostel Outpass</span>
                      <Home className="w-3.5 h-3.5 text-indigo-600" />
                    </div>
                    <p className="text-lg font-bold text-indigo-800 mt-1">
                      {data.leave_statistics.hostel_leave_count} <span className="text-xs font-normal text-indigo-600">({data.leave_statistics.hostel_leave_days} Days)</span>
                    </p>
                    <p className="text-[10px] text-indigo-700/80 mt-0.5">Overnight residential passes</p>
                  </div>

                  {/* Regular / Medical */}
                  <div className="bg-slate-100 border border-slate-200 rounded-xl p-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold text-slate-800">Medical Leaves</span>
                      <FileText className="w-3.5 h-3.5 text-slate-600" />
                    </div>
                    <p className="text-lg font-bold text-slate-900 mt-1">
                      {data.leave_statistics.medical_leave_count} <span className="text-xs font-normal text-slate-500">Apps</span>
                    </p>
                    <p className="text-[10px] text-slate-500 mt-0.5">Doctor & clinical consults</p>
                  </div>

                  {/* Personal Leaves */}
                  <div className="bg-slate-100 border border-slate-200 rounded-xl p-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold text-slate-800">Personal / Day Pass</span>
                      <Calendar className="w-3.5 h-3.5 text-slate-600" />
                    </div>
                    <p className="text-lg font-bold text-slate-900 mt-1">
                      {data.leave_statistics.personal_leave_count + data.leave_statistics.day_pass_count} <span className="text-xs font-normal text-slate-500">Apps</span>
                    </p>
                    <p className="text-[10px] text-slate-500 mt-0.5">Family & personal visits</p>
                  </div>

                </div>
              </div>

              {/* Student Leave History Table (Feature 4) */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                    Full Leave Application Ledger ({data.leave_history.length})
                  </h4>
                  <span className="text-[11px] text-slate-400 font-mono">
                    Audit Log Verified • PostgreSQL Ledger
                  </span>
                </div>

                {data.leave_history.length === 0 ? (
                  <div className="p-8 text-center text-xs text-slate-500 bg-slate-50 border border-slate-200 rounded-xl">
                    No leave applications recorded for this student.
                  </div>
                ) : (
                  <div className="border border-slate-200 rounded-xl overflow-hidden shadow-sm">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[10px]">
                          <tr>
                            <th className="px-4 py-3">Application ID</th>
                            <th className="px-4 py-3">Category</th>
                            <th className="px-4 py-3">Timeline & Duration</th>
                            <th className="px-4 py-3 min-w-[200px]">Reason</th>
                            <th className="px-4 py-3">Faculty Rec.</th>
                            <th className="px-4 py-3">HOD Decision</th>
                            <th className="px-4 py-3 text-right">Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {data.leave_history.map((app) => (
                            <tr key={app.id} className="hover:bg-slate-50/70 transition-colors">
                              
                              {/* Application ID & Submission */}
                              <td className="px-4 py-3 align-top">
                                <span className="font-mono font-bold text-[#0F172A] block">
                                  {app.application_id}
                                </span>
                                <span className="text-[10px] text-slate-400">
                                  {app.submission_date}
                                </span>
                              </td>

                              {/* Category Badge */}
                              <td className="px-4 py-3 align-top">
                                {getLeaveTypeBadge(app.leave_type)}
                              </td>

                              {/* Dates & Duration */}
                              <td className="px-4 py-3 align-top whitespace-nowrap">
                                <div className="font-medium text-slate-800">
                                  {app.start_date} <span className="text-slate-400">→</span> {app.end_date}
                                </div>
                                <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded mt-0.5">
                                  {app.duration_days} {app.duration_days === 1 ? 'Day' : 'Days'}
                                </span>
                              </td>

                              {/* Reason */}
                              <td className="px-4 py-3 align-top">
                                <p className="text-slate-700 text-xs leading-relaxed">
                                  {app.reason}
                                </p>
                                {app.rejection_reason && (
                                  <div className="mt-1 text-[11px] text-red-700 bg-red-50 border border-red-200 rounded p-1.5 font-medium">
                                    <strong>Rejection Rationale:</strong> {app.rejection_reason}
                                  </div>
                                )}
                              </td>

                              {/* Faculty Recommendation */}
                              <td className="px-4 py-3 align-top">
                                {app.faculty_recommendation ? (
                                  <div>
                                    <span className="text-[11px] font-semibold text-emerald-700">
                                      ✓ {app.faculty_recommendation.decision === 'FORWARDED_TO_HOD' ? 'Recommended' : app.faculty_recommendation.decision}
                                    </span>
                                    <p className="text-[10px] text-slate-500 italic mt-0.5 line-clamp-2">
                                      "{app.faculty_recommendation.remarks}"
                                    </p>
                                    <p className="text-[9px] text-slate-400 mt-0.5">
                                      — {app.faculty_recommendation.reviewer_name}
                                    </p>
                                  </div>
                                ) : (
                                  <span className="text-[11px] text-slate-400 italic">
                                    Pending Review
                                  </span>
                                )}
                              </td>

                              {/* HOD Decision */}
                              <td className="px-4 py-3 align-top">
                                {app.hod_decision ? (
                                  <div>
                                    <span className={`text-[11px] font-semibold ${
                                      app.hod_decision.decision === 'HOD_APPROVED' ? 'text-emerald-700' : 'text-red-700'
                                    }`}>
                                      {app.hod_decision.decision === 'HOD_APPROVED' ? '✓ Authorized' : '✗ Disapproved'}
                                    </span>
                                    {app.hod_decision.remarks && (
                                      <p className="text-[10px] text-slate-500 italic mt-0.5 line-clamp-2">
                                        "{app.hod_decision.remarks}"
                                      </p>
                                    )}
                                  </div>
                                ) : (
                                  <span className="text-[11px] text-slate-400 italic">
                                    Awaiting HOD
                                  </span>
                                )}
                              </td>

                              {/* Status Badge */}
                              <td className="px-4 py-3 align-top text-right">
                                {getStatusBadge(app.status)}
                              </td>

                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            </>
          ) : null}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0 text-xs">
          <p className="text-slate-500 text-[11px]">
            CAMPUSORA v2.1.0 • Institutional Governance Ledger
          </p>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-100 transition-colors shadow-sm"
          >
            Close Dossier
          </button>
        </div>

      </div>
    </div>
  );
}
