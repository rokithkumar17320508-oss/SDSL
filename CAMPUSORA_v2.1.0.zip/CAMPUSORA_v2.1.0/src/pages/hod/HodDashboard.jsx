import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  CheckSquare, 
  Clock, 
  CheckCircle, 
  XCircle, 
  ArrowRight,
  ShieldCheck,
  Building2,
  RefreshCw,
  Loader2,
  GraduationCap,
  Users
} from 'lucide-react';
import { SAMPLE_HOD, getStoredApplications } from '../../data/studentData';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import { getFallbackDepartmentSections } from '../../data/demoSectionsData';

export default function HodDashboard() {
  const navigate = useNavigate();
  const { user, isAuthenticated, isDemoMode } = useAuth();
  const [applications, setApplications] = useState([]);
  const [sections, setSections] = useState([]);
  const [sectionsLoading, setSectionsLoading] = useState(true);
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    setLoading(true);
    setSectionsLoading(true);
    try {
      // 1. Fetch HOD applications
      if (isAuthenticated) {
        const res = await api.getApplications();
        if (res.ok && res.data) {
          const list = Array.isArray(res.data) ? res.data : (res.data.results || []);
          setApplications(list);
        } else {
          setApplications([]);
        }
      } else {
        setApplications(getStoredApplications());
      }

      // 2. Fetch live Department Sections metrics (Feature 1)
      try {
        const secRes = await api.getDepartmentSections();
        if (secRes.ok && secRes.data && secRes.data.sections) {
          setSections(secRes.data.sections);
        } else {
          const fallback = getFallbackDepartmentSections();
          setSections(fallback.sections);
        }
      } catch (secErr) {
        console.error('Failed to load sections metrics, using fallback:', secErr);
        const fallback = getFallbackDepartmentSections();
        setSections(fallback.sections);
      }
    } catch (err) {
      console.error('Failed to load HOD applications:', err);
      setApplications([]);
    } finally {
      setLoading(false);
      setSectionsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [isAuthenticated, isDemoMode]);

  // Applications forwarded to HOD (either pending HOD review or already decided by HOD)
  const forwardedToHod = applications.filter(
    (app) => app.status !== 'Pending Faculty Review'
  );
  const pendingHodCount = applications.filter(
    (app) => app.status === 'Pending HOD Review'
  ).length;
  const approvedHodCount = applications.filter(
    (app) => app.status === 'HOD Approved'
  ).length;
  const rejectedCount = applications.filter(
    (app) => app.status === 'Rejected'
  ).length;

  const recentDecisions = applications
    .filter((app) => app.status === 'HOD Approved' || app.status === 'Rejected')
    .slice(0, 5);

  const displayName = isAuthenticated && user
    ? (user.first_name ? `${user.first_name} ${user.last_name}`.trim() : user.username)
    : SAMPLE_HOD.name;

  const displayEmpId = isAuthenticated && user
    ? (user.faculty_profile?.employee_id || 'HOD-CSE-01')
    : SAMPLE_HOD.employeeId;

  const displayDept = isAuthenticated && user
    ? (user.department || SAMPLE_HOD.department)
    : `${SAMPLE_HOD.designation} • ${SAMPLE_HOD.department}`;

  const initials = isAuthenticated && user
    ? ((user.first_name?.[0] || 'R') + (user.last_name?.[0] || 'M')).toUpperCase()
    : 'RM';

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Pending HOD Review':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-amber-50 text-amber-800 border border-amber-200">
            Awaiting HOD Signature
          </span>
        );
      case 'HOD Approved':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
            HOD Approved
          </span>
        );
      case 'Rejected':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-red-50 text-red-700 border border-red-200">
            Rejected
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-700">
            {status}
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      
      {/* HOD Profile Header Card */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 shadow-subtle flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-purple-50 border border-purple-100 flex items-center justify-center text-purple-700 text-base font-bold shrink-0">
            {initials}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-[#1E293B]">
                {displayName}
              </h2>
              <span className="text-xs font-mono font-medium text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                {displayEmpId}
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              {displayDept}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={loadData}
            disabled={loading}
            title="Refresh dashboard data"
            className="p-2.5 rounded-lg text-slate-600 bg-slate-50 border border-slate-200 hover:bg-slate-100 transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>

          <Link
            to="/hod/approvals"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold text-white bg-[#2563EB] hover:bg-[#1D4ED8] transition-colors shadow-subtle"
          >
            <CheckSquare className="w-4 h-4" />
            <span>Pending Approvals ({pendingHodCount})</span>
          </Link>
        </div>
      </div>

      {/* 4 Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        
        {/* Total Forwarded */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 shadow-subtle">
          <p className="text-xs font-medium text-slate-500">Total Forwarded</p>
          <p className="text-2xl font-bold text-[#1E293B] mt-1">{forwardedToHod.length}</p>
          <p className="text-[11px] text-slate-400 mt-0.5">Endorsed by faculty</p>
        </div>

        {/* Pending HOD Approval */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 shadow-subtle">
          <p className="text-xs font-medium text-slate-500">Pending Approvals</p>
          <p className="text-2xl font-bold text-[#EAB308] mt-1">{pendingHodCount}</p>
          <p className="text-[11px] text-amber-700 font-medium mt-0.5">Requires final decision</p>
        </div>

        {/* HOD Approved */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 shadow-subtle">
          <p className="text-xs font-medium text-slate-500">Authorized Passes</p>
          <p className="text-2xl font-bold text-emerald-600 mt-1">{approvedHodCount}</p>
          <p className="text-[11px] text-slate-400 mt-0.5">Issued gate clearance</p>
        </div>

        {/* Rejected */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 shadow-subtle">
          <p className="text-xs font-medium text-slate-500">Rejected</p>
          <p className="text-2xl font-bold text-red-600 mt-1">{rejectedCount}</p>
          <p className="text-[11px] text-slate-400 mt-0.5">Disapproved passes</p>
        </div>

      </div>

      {/* FEATURE 1 — HOD Section Governance Cards (CSE-A, CSE-B, CSE-C, CSE-D) */}
      <div className="space-y-3.5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-base font-bold text-[#0F172A] flex items-center gap-2">
              <Building2 className="w-4 h-4 text-[#2563EB]" />
              <span>First Year CSE Department — Section Leave Governance</span>
            </h3>
            <p className="text-xs text-slate-500">
              4 Academic Sections • 240 Enrolled Students • Live PostgreSQL Database Analytics
            </p>
          </div>

          <Link
            to="/hod/sections"
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#2563EB] hover:text-[#1D4ED8] bg-blue-50 hover:bg-blue-100 border border-blue-200 px-3 py-1.5 rounded-lg transition-colors self-start sm:self-auto"
          >
            <Users className="w-3.5 h-3.5" />
            <span>Browse Full Directory (240)</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {sections.map((sec) => (
            <div
              key={sec.section}
              className="bg-white border border-slate-200 hover:border-slate-300 rounded-xl p-5 shadow-subtle hover:shadow-md transition-all flex flex-col justify-between group"
            >
              <div>
                {/* Section Header */}
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-slate-900 text-amber-400 font-extrabold flex items-center justify-center text-sm shadow-sm shrink-0">
                      {sec.section_code || sec.section.replace('CSE-', '')}
                    </div>
                    <div>
                      <h4 className="text-base font-bold text-[#0F172A] group-hover:text-[#2563EB] transition-colors">
                        {sec.section}
                      </h4>
                      <p className="text-[11px] text-slate-500 font-medium">
                        Year {sec.year} • {sec.total_students} Students
                      </p>
                    </div>
                  </div>

                  <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-200">
                    60 Seats
                  </span>
                </div>

                {/* Section Stats Grid */}
                <div className="mt-4 pt-4 border-t border-slate-100 grid grid-cols-2 gap-2 text-xs">
                  
                  {/* Total Applications */}
                  <div className="bg-slate-50 rounded-lg p-2.5 border border-slate-100">
                    <p className="text-[10px] font-medium text-slate-500 uppercase tracking-wider">Total Leaves</p>
                    <p className="text-base font-bold text-slate-900 mt-0.5">
                      {sec.total_applications}
                    </p>
                  </div>

                  {/* Pending Approvals */}
                  <div className="bg-amber-50/70 rounded-lg p-2.5 border border-amber-200">
                    <p className="text-[10px] font-bold text-amber-900 uppercase tracking-wider">Pending</p>
                    <p className="text-base font-bold text-[#EAB308] mt-0.5">
                      {sec.pending_applications}
                    </p>
                  </div>

                  {/* Approved */}
                  <div className="bg-emerald-50/70 rounded-lg p-2.5 border border-emerald-200">
                    <p className="text-[10px] font-bold text-emerald-900 uppercase tracking-wider">Approved</p>
                    <p className="text-base font-bold text-emerald-600 mt-0.5">
                      {sec.approved_applications}
                    </p>
                  </div>

                  {/* Rejected */}
                  <div className="bg-red-50/70 rounded-lg p-2.5 border border-red-200">
                    <p className="text-[10px] font-bold text-red-900 uppercase tracking-wider">Rejected</p>
                    <p className="text-base font-bold text-red-600 mt-0.5">
                      {sec.rejected_applications}
                    </p>
                  </div>

                </div>
              </div>

              {/* View Students Button */}
              <div className="mt-4 pt-3 border-t border-slate-100">
                <Link
                  to={`/hod/sections/${sec.section}`}
                  className="w-full inline-flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-xs font-semibold text-white bg-[#0F172A] hover:bg-slate-800 transition-colors shadow-sm"
                >
                  <Users className="w-3.5 h-3.5 text-amber-400" />
                  <span>View Students ({sec.total_students})</span>
                  <ArrowRight className="w-3.5 h-3.5 ml-0.5" />
                </Link>
              </div>

            </div>
          ))}
        </div>
      </div>

      {/* Recent Decisions Section */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-subtle overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-[#1E293B]">Recent Decisions & Signed Outpasses</h3>
            <p className="text-xs text-slate-500">Log of recent authorizations granted by HOD Desk</p>
          </div>

          <Link
            to="/hod/history"
            className="inline-flex items-center gap-1 text-xs font-semibold text-[#2563EB] hover:text-[#1D4ED8] transition-colors"
          >
            <span>Full History</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {loading ? (
          <div className="p-8 text-center text-xs text-slate-500 flex items-center justify-center gap-2">
            <Loader2 className="w-4 h-4 animate-spin text-[#2563EB]" />
            <span>Loading recent decisions...</span>
          </div>
        ) : recentDecisions.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-500">
            No recent decisions recorded. Check the pending approvals queue.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-medium">
                <tr>
                  <th className="px-5 py-3">ID</th>
                  <th className="px-5 py-3">Student Name</th>
                  <th className="px-5 py-3">Reg Number</th>
                  <th className="px-5 py-3">Category</th>
                  <th className="px-5 py-3">Dates</th>
                  <th className="px-5 py-3">Status</th>
                  <th className="px-5 py-3 text-right">Review</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {recentDecisions.map((app) => (
                  <tr key={app.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-5 py-3.5 font-mono font-medium text-slate-600">
                      {app.id}
                    </td>
                    <td className="px-5 py-3.5 font-semibold text-[#1E293B]">
                      {app.studentName}
                    </td>
                    <td className="px-5 py-3.5 font-mono text-slate-500 text-[11px]">
                      {app.regNo}
                    </td>
                    <td className="px-5 py-3.5 font-medium text-slate-700">
                      {app.type}
                    </td>
                    <td className="px-5 py-3.5 text-slate-600">
                      {app.startDate === app.endDate ? app.startDate : `${app.startDate} to ${app.endDate}`}
                    </td>
                    <td className="px-5 py-3.5">
                      {getStatusBadge(app.status)}
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      <Link
                        to="/hod/history"
                        className="text-xs font-semibold text-[#2563EB] hover:underline"
                      >
                        View
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

    </div>
  );
}