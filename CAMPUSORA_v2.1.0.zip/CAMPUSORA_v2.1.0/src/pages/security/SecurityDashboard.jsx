import React, { useState, useEffect, useRef } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { 
  ShieldCheck, 
  ScanLine, 
  Clock, 
  CheckCircle2, 
  AlertTriangle,
  ArrowRight,
  ArrowDownLeft,
  ArrowUpRight,
  MapPin,
  Lock,
  Camera,
  CameraOff,
  User,
  Users,
  Search,
  Filter,
  RefreshCw,
  XCircle,
  AlertCircle,
  Building,
  Calendar,
  Check,
  ClipboardList,
  DoorOpen,
  Send,
  Sparkles,
  BarChart3,
  Phone
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { BRAND } from '../../config/branding';
import api from '../../services/api';
import AnalyticsView from '../../components/AnalyticsView';

export default function SecurityDashboard() {
  const { user, isDemoMode } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  // Active Tab: sync with route pathname if present
  const getInitialTab = () => {
    if (location.pathname.includes('/scanner')) return 'terminal';
    if (location.pathname.includes('/outside')) return 'outside';
    if (location.pathname.includes('/analytics')) return 'analytics';
    if (location.pathname.includes('/logs')) return 'logs';
    if (location.pathname.includes('/profile')) return 'profile';
    return 'terminal';
  };

  const [activeTab, setActiveTab] = useState(getInitialTab());

  useEffect(() => {
    if (location.pathname.includes('/scanner')) setActiveTab('terminal');
    else if (location.pathname.includes('/outside')) setActiveTab('outside');
    else if (location.pathname.includes('/analytics')) setActiveTab('analytics');
    else if (location.pathname.includes('/logs')) setActiveTab('logs');
    else if (location.pathname.includes('/profile')) setActiveTab('profile');
    else setActiveTab('terminal');
  }, [location.pathname]);

  const handleTabChange = (tab) => {
    setActiveTab(tab);
    if (tab === 'terminal') navigate('/security');
    else if (tab === 'outside') navigate('/security/outside');
    else if (tab === 'analytics') navigate('/security/analytics');
    else if (tab === 'logs') navigate('/security/logs');
    else if (tab === 'profile') navigate('/security/profile');
  };

  // Officer details
  const officerName = user?.name || user?.username || 'Officer Vikram Singh';
  const officerGate = user?.assigned_gate || 'College Main Gate';
  const employeeId = user?.employee_id || 'SEC-GT01-984';

  // Scanner & Verification States
  const [scanMode, setScanMode] = useState('EXIT'); // 'EXIT' (Departure) or 'ENTRY' (Return)
  const [tokenInput, setTokenInput] = useState('');
  const [verifying, setVerifying] = useState(false);
  const [verificationResult, setVerificationResult] = useState(null);
  const [verificationError, setVerificationError] = useState(null);
  const [actionLoading, setActionLoading] = useState(false);
  const [actionSuccess, setActionSuccess] = useState(null);
  const [guardRemarks, setGuardRemarks] = useState('');

  // Denial state modal
  const [showDenialModal, setShowDenialModal] = useState(false);
  const [denialReason, setDenialReason] = useState('');

  // Camera States
  const videoRef = useRef(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState(null);

  // Movement Events Log State
  const [events, setEvents] = useState([]);
  const [eventsLoading, setEventsLoading] = useState(false);
  const [eventFilter, setEventFilter] = useState('ALL');

  // Off-Campus & Overdue Tracking State
  const [outsideStudents, setOutsideStudents] = useState([]);
  const [outsideLoading, setOutsideLoading] = useState(false);
  const [outsideFilter, setOutsideFilter] = useState('ALL'); // 'ALL' or 'OVERDUE'
  const [outsideSearch, setOutsideSearch] = useState('');

  // Load events
  const loadEvents = async () => {
    setEventsLoading(true);
    try {
      if (isDemoMode) {
        setEvents([
          {
            id: 1,
            pass_id: 'GP-7648',
            student_name: 'Arjun Sharma',
            student_registration: '2024CSE1084',
            security_officer_name: officerName,
            gate_type: officerGate,
            event_type: 'EXIT',
            verification_outcome: 'SUCCESS',
            remarks: 'Authorized departure for weekend leave.',
            timestamp: new Date().toISOString(),
          },
          {
            id: 2,
            pass_id: 'GP-6421',
            student_name: 'Priya Patel',
            student_registration: '2024ECE1092',
            security_officer_name: officerName,
            gate_type: officerGate,
            event_type: 'ENTRY',
            verification_outcome: 'SUCCESS',
            remarks: 'Return entry cleared within curfew.',
            timestamp: new Date(Date.now() - 3600000).toISOString(),
          }
        ]);
      } else {
        const res = await api.getGateEvents();
        if (res.ok && Array.isArray(res.data)) {
          setEvents(res.data);
        } else if (res.ok && res.data && Array.isArray(res.data.results)) {
          setEvents(res.data.results);
        } else {
          setEvents([]);
        }
      }
    } catch (err) {
      console.error('Failed to load gate events:', err);
    } finally {
      setEventsLoading(false);
    }
  };

  // Load Outside & Overdue Students
  const loadOutsideStudents = async () => {
    setOutsideLoading(true);
    try {
      if (isDemoMode) {
        setOutsideStudents([
          {
            pass_id: 'GP-DEMO-7648',
            application_id: 'APP-7648',
            student_name: 'Arjun Sharma',
            registration_number: '2024CSE1084',
            department: 'Computer Science and Engineering',
            hostel_block: 'BH-2',
            room_number: 'B-302',
            parent_name: 'Ramesh Sharma',
            parent_phone: '+91 98765 43210',
            leave_type: 'Hostel Outpass',
            gate_type: officerGate,
            exit_recorded_at: new Date(Date.now() - 7200000).toISOString(),
            expected_return_time: new Date(Date.now() + 18000000).toISOString(),
            is_overdue: false,
            minutes_overdue: 0,
            photo_url: '/photos/students/arjun.jpg',
          },
          {
            pass_id: 'GP-DEMO-5521',
            application_id: 'APP-5521',
            student_name: 'Rohan Verma',
            registration_number: '2024MECH1032',
            department: 'Mechanical Engineering',
            hostel_block: 'BH-1',
            room_number: 'A-108',
            parent_name: 'Sunil Verma',
            parent_phone: '+91 98451 22334',
            leave_type: 'Day Pass',
            gate_type: officerGate,
            exit_recorded_at: new Date(Date.now() - 86400000).toISOString(),
            expected_return_time: new Date(Date.now() - 7200000).toISOString(),
            is_overdue: true,
            minutes_overdue: 120,
            photo_url: '/photos/students/rohan.jpg',
          }
        ]);
      } else {
        const res = await api.getActiveOutsideStudents();
        if (res.ok && res.data) {
          const list = Array.isArray(res.data.results) ? res.data.results : (Array.isArray(res.data) ? res.data : []);
          setOutsideStudents(list);
        } else {
          setOutsideStudents([]);
        }
      }
    } catch (err) {
      console.error('Failed to load outside students:', err);
    } finally {
      setOutsideLoading(false);
    }
  };

  useEffect(() => {
    loadEvents();
    loadOutsideStudents();
  }, [isDemoMode]);

  // Clean up camera stream on unmount
  useEffect(() => {
    return () => {
      stopCameraStream();
    };
  }, []);

  const startCameraStream = async () => {
    setCameraError(null);
    try {
      if (!navigator?.mediaDevices?.getUserMedia) {
        throw new Error('Camera hardware access is not supported by your browser environment.');
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
        setCameraActive(true);
      }
    } catch (err) {
      console.warn('Camera stream error:', err);
      setCameraError('Camera access unavailable or permission denied. Please enter the QR token manually below.');
      setCameraActive(false);
    }
  };

  const stopCameraStream = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject;
      const tracks = stream.getTracks();
      tracks.forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setCameraActive(false);
  };

  const handleModeSwitch = (newMode) => {
    setScanMode(newMode);
    setVerificationResult(null);
    setVerificationError(null);
    setTokenInput('');
    setActionSuccess(null);
  };

  // Verify Gate Pass (Departure vs Return)
  const handleVerify = async (manualToken) => {
    const rawToken = manualToken !== undefined ? manualToken : tokenInput;
    if (!rawToken || !rawToken.trim()) {
      setVerificationError({
        outcome: 'EMPTY_INPUT',
        detail: 'Please enter a clearance token or scan a QR barcode.'
      });
      return;
    }

    setVerifying(true);
    setVerificationResult(null);
    setVerificationError(null);
    setActionSuccess(null);

    try {
      if (isDemoMode) {
        // Demo Mode verification simulation
        if (rawToken.includes('DEMO') || rawToken.includes('7648') || rawToken.length > 8) {
          const isOverdueDemo = rawToken.includes('OVERDUE');
          setVerificationResult({
            valid: true,
            outcome: 'SUCCESS',
            pass_id: 'GP-DEMO-7648',
            application_id: 'APP-7648',
            student: {
              name: 'Arjun Sharma',
              registration_number: '2024CSE1084',
              department: 'Computer Science and Engineering',
              room_number: 'B-302',
              phone: '+91 98765 43210'
            },
            leave_type: 'Hostel Outpass',
            reason: 'Weekend family visit',
            authorized_gate: 'Both Gates',
            valid_from: '2026-11-17T06:00:00Z',
            valid_until: '2026-11-19T21:00:00Z',
            status: scanMode === 'ENTRY' ? 'USED' : 'ACTIVE',
            exit_recorded_at: '2026-11-17T08:30:00Z',
            expected_return_time: '2026-11-19T21:00:00Z',
            is_overdue: isOverdueDemo,
            officer_terminal_gate: officerGate,
            token: rawToken.trim(),
          });
        } else {
          setVerificationError({
            outcome: 'INVALID_TOKEN',
            detail: 'Unrecognized clearance code. Token not found in institutional database.'
          });
        }
      } else {
        // Live API call: Entry vs Exit
        const res = scanMode === 'ENTRY' 
          ? await api.verifyGatePassReturn(rawToken.trim())
          : await api.verifyGatePass(rawToken.trim());

        if (res.ok && res.data && res.data.valid) {
          setVerificationResult(res.data);
        } else {
          const detail = res.data?.detail || res.error || 'Pass verification rejected.';
          const outcome = res.data?.outcome || 'DENIED';
          setVerificationError({ outcome, detail });
        }
      }
    } catch (err) {
      console.error('Verification error:', err);
      setVerificationError({
        outcome: 'SYSTEM_ERROR',
        detail: err.message || 'Network error communicating with verification service.'
      });
    } finally {
      setVerifying(false);
    }
  };

  // Confirm Departure Exit
  const handleConfirmExit = async () => {
    if (!verificationResult) return;
    const activeToken = verificationResult.token || tokenInput;
    setActionLoading(true);

    try {
      if (isDemoMode) {
        setActionSuccess(`Departure cleared for ${verificationResult.student.name} (${verificationResult.student.registration_number}). Pass status marked as USED.`);
        setVerificationResult(null);
        setTokenInput('');
        loadEvents();
        loadOutsideStudents();
      } else {
        const res = await api.confirmGateExit(activeToken, guardRemarks);
        if (res.ok) {
          setActionSuccess(`Departure recorded successfully! Pass ${res.data?.pass_id || verificationResult.pass_id} marked as USED.`);
          setVerificationResult(null);
          setTokenInput('');
          setGuardRemarks('');
          loadEvents();
          loadOutsideStudents();
        } else {
          setVerificationError({
            outcome: 'ACTION_FAILED',
            detail: res.data?.detail || res.error || 'Failed to record exit confirmation.'
          });
        }
      }
    } catch (err) {
      setVerificationError({
        outcome: 'SYSTEM_ERROR',
        detail: err.message || 'Error executing atomic exit confirmation.'
      });
    } finally {
      setActionLoading(false);
    }
  };

  // Confirm Return Entry
  const handleConfirmReturn = async () => {
    if (!verificationResult) return;
    const activeToken = verificationResult.token || tokenInput;
    setActionLoading(true);

    try {
      if (isDemoMode) {
        setActionSuccess(`Return entry confirmed for ${verificationResult.student.name} (${verificationResult.student.registration_number})! Pass closed and marked as RETURNED.${verificationResult.is_overdue ? ' (NOTE: Marked as OVERDUE in audit ledger)' : ''}`);
        setVerificationResult(null);
        setTokenInput('');
        setGuardRemarks('');
        loadEvents();
        loadOutsideStudents();
      } else {
        const res = await api.confirmGateReturn(activeToken, guardRemarks);
        if (res.ok) {
          const overdueNotice = res.data?.is_overdue ? ' [ALERT: Return was recorded PAST curfew deadline]' : '';
          setActionSuccess(`Return entry recorded successfully! Pass ${res.data?.pass_id || verificationResult.pass_id} closed as RETURNED.${overdueNotice}`);
          setVerificationResult(null);
          setTokenInput('');
          setGuardRemarks('');
          loadEvents();
          loadOutsideStudents();
        } else {
          setVerificationError({
            outcome: 'ACTION_FAILED',
            detail: res.data?.detail || res.error || 'Failed to record return entry.'
          });
        }
      }
    } catch (err) {
      setVerificationError({
        outcome: 'SYSTEM_ERROR',
        detail: err.message || 'Error executing atomic return entry confirmation.'
      });
    } finally {
      setActionLoading(false);
    }
  };

  // Deny Departure
  const handleDenyExit = async () => {
    if (!verificationResult || !denialReason.trim()) return;
    const activeToken = verificationResult.token || tokenInput;
    setActionLoading(true);

    try {
      if (isDemoMode) {
        setActionSuccess(`Exit clearance denied for ${verificationResult.student.name}. Reason: ${denialReason}`);
        setShowDenialModal(false);
        setDenialReason('');
        setVerificationResult(null);
        setTokenInput('');
        loadEvents();
      } else {
        const res = await api.denyGateExit(activeToken, denialReason);
        if (res.ok) {
          setActionSuccess(`Exit clearance denied and logged in security ledger.`);
          setShowDenialModal(false);
          setDenialReason('');
          setVerificationResult(null);
          setTokenInput('');
          loadEvents();
        } else {
          setVerificationError({
            outcome: 'ACTION_FAILED',
            detail: res.data?.detail || res.error || 'Failed to record denial.'
          });
        }
      }
    } catch (err) {
      setVerificationError({
        outcome: 'SYSTEM_ERROR',
        detail: err.message || 'Error recording gate denial.'
      });
    } finally {
      setActionLoading(false);
    }
  };

  // Quick Action: Preload student token into return scanner
  const handleQuickReturnVerify = (student) => {
    setActiveTab('terminal');
    setScanMode('ENTRY');
    setVerificationResult(null);
    setVerificationError(null);
    // In our system, the token can be derived or pass_id can be verified
    setTokenInput(student.pass_id);
    handleVerify(student.pass_id);
  };

  // Calculate Metrics
  const todayDepartures = events.filter(e => e.event_type === 'EXIT' && e.verification_outcome === 'SUCCESS').length;
  const todayReturns = events.filter(e => e.event_type === 'ENTRY' && (e.verification_outcome === 'SUCCESS' || e.verification_outcome === 'RETURN_SUCCESS')).length;
  const overdueCount = outsideStudents.filter(s => s.is_overdue).length;

  // Filtered Events
  const filteredEvents = events.filter(e => {
    if (eventFilter === 'EXITS') return e.event_type === 'EXIT';
    if (eventFilter === 'RETURNS') return e.event_type === 'ENTRY';
    if (eventFilter === 'FLAGGED') return e.verification_outcome !== 'SUCCESS' && e.verification_outcome !== 'RETURN_SUCCESS';
    return true;
  });

  // Filtered Outside Students
  const filteredOutsideStudents = outsideStudents.filter(s => {
    if (outsideFilter === 'OVERDUE' && !s.is_overdue) return false;
    if (outsideSearch.trim()) {
      const q = outsideSearch.toLowerCase();
      const matchName = (s.student_name || '').toLowerCase().includes(q);
      const matchReg = (s.registration_number || '').toLowerCase().includes(q);
      const matchDept = (s.department || '').toLowerCase().includes(q);
      const matchPass = (s.pass_id || '').toLowerCase().includes(q);
      const matchRoom = (s.room_number || '').toLowerCase().includes(q);
      return matchName || matchReg || matchDept || matchPass || matchRoom;
    }
    return true;
  });

  return (
    <div className="space-y-6">
      
      {/* Officer Welcome & Terminal Status Banner */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-card flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="px-2.5 py-0.5 rounded text-[10px] font-bold uppercase bg-blue-100 text-[#2563EB] tracking-wide">
              Live Security Checkpoint
            </span>
            <span className="text-xs text-slate-500 font-mono">Terminal #01</span>
          </div>
          <h1 className="text-xl font-bold text-[#1E293B]">
            Welcome, {officerName}
          </h1>
          <p className="text-xs text-slate-500 mt-1 flex items-center gap-2">
            <span>ID: <strong className="font-mono text-slate-700">{employeeId}</strong></span>
            <span>•</span>
            <span className="inline-flex items-center gap-1 font-semibold text-[#2563EB]">
              <MapPin className="w-3.5 h-3.5" />
              {officerGate}
            </span>
          </p>
        </div>

        <div className="flex items-center gap-2">
          {overdueCount > 0 && (
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-50 border border-rose-200 rounded-xl text-xs font-bold text-rose-700 animate-pulse">
              <AlertTriangle className="w-4 h-4 text-rose-600" />
              <span>{overdueCount} Overdue Curfew Alert{overdueCount > 1 ? 's' : ''}</span>
            </div>
          )}
          <div className="flex items-center gap-2 px-3.5 py-2 bg-emerald-50 border border-emerald-200 rounded-xl text-xs font-semibold text-emerald-800">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>PostgreSQL RBAC Active</span>
          </div>
        </div>
      </div>

      {/* Terminal Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-card">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Today's Departures</span>
            <span className="p-2 rounded-lg bg-emerald-50 text-emerald-700">
              <DoorOpen className="w-4 h-4" />
            </span>
          </div>
          <p className="text-2xl font-bold text-[#1E293B] mt-3">{todayDepartures}</p>
          <span className="text-[11px] text-emerald-700 mt-1 block font-medium">Verified exit departures</span>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-card">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Today's Return Entries</span>
            <span className="p-2 rounded-lg bg-blue-50 text-[#2563EB]">
              <ArrowDownLeft className="w-4 h-4" />
            </span>
          </div>
          <p className="text-2xl font-bold text-[#1E293B] mt-3">{todayReturns}</p>
          <span className="text-[11px] text-[#2563EB] mt-1 block font-medium">Verified return entries</span>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-card">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Currently Outside</span>
            <span className="p-2 rounded-lg bg-indigo-50 text-indigo-700">
              <Users className="w-4 h-4" />
            </span>
          </div>
          <div className="flex items-baseline gap-2 mt-3">
            <p className="text-2xl font-bold text-[#1E293B]">{outsideStudents.length}</p>
            {overdueCount > 0 && (
              <span className="text-xs font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-full border border-rose-200">
                {overdueCount} Overdue
              </span>
            )}
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block font-medium">Students off campus</span>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-card">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Assigned Station</span>
            <span className="p-2 rounded-lg bg-slate-100 text-slate-700">
              <MapPin className="w-4 h-4" />
            </span>
          </div>
          <p className="text-sm font-bold text-[#1E293B] mt-3 truncate">{officerGate}</p>
          <span className="text-[11px] text-slate-500 mt-1 block">Zero-trust gate enforcement</span>
        </div>
      </div>

      {/* Navigation Pills */}
      <div className="flex border-b border-slate-200 space-x-6 text-sm overflow-x-auto">
        <button
          onClick={() => handleTabChange('terminal')}
          className={`pb-3 font-semibold text-xs tracking-wide transition-colors border-b-2 flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'terminal'
              ? 'border-[#2563EB] text-[#2563EB]'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <ScanLine className="w-4 h-4" />
          <span>Scanner & Verification Terminal</span>
        </button>

        <button
          onClick={() => handleTabChange('outside')}
          className={`pb-3 font-semibold text-xs tracking-wide transition-colors border-b-2 flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'outside'
              ? 'border-[#2563EB] text-[#2563EB]'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Off-Campus & Overdue ({outsideStudents.length})</span>
          {overdueCount > 0 && (
            <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
          )}
        </button>

        <button
          onClick={() => handleTabChange('logs')}
          className={`pb-3 font-semibold text-xs tracking-wide transition-colors border-b-2 flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'logs'
              ? 'border-[#2563EB] text-[#2563EB]'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <ClipboardList className="w-4 h-4" />
          <span>Movement History ({events.length})</span>
        </button>

        <button
          onClick={() => handleTabChange('analytics')}
          className={`pb-3 font-semibold text-xs tracking-wide transition-colors border-b-2 flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'analytics'
              ? 'border-[#2563EB] text-[#2563EB]'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>Gate Analytics</span>
        </button>

        <button
          onClick={() => handleTabChange('profile')}
          className={`pb-3 font-semibold text-xs tracking-wide transition-colors border-b-2 flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'profile'
              ? 'border-[#2563EB] text-[#2563EB]'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <User className="w-4 h-4" />
          <span>Checkpoint Details</span>
        </button>
      </div>

      {/* Global Success Banner */}
      {actionSuccess && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs flex items-center justify-between gap-3 shadow-sm">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span className="font-semibold">{actionSuccess}</span>
          </div>
          <button
            onClick={() => setActionSuccess(null)}
            className="text-emerald-700 hover:text-emerald-900 font-bold"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* TAB 1: SCANNER & VERIFICATION TERMINAL */}
      {activeTab === 'terminal' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Left Column: Mode Selector, QR Scanner & Token Entry (5 cols) */}
          <div className="lg:col-span-5 space-y-6">
            
            <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-card space-y-5">
              
              {/* Scan Mode Toggle (Departure vs Return) */}
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-2 uppercase tracking-wider">
                  Checkpoint Clearance Mode
                </label>
                <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-xl border border-slate-200">
                  <button
                    type="button"
                    onClick={() => handleModeSwitch('EXIT')}
                    className={`py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                      scanMode === 'EXIT'
                        ? 'bg-white text-emerald-700 shadow-sm border border-slate-200/60'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <ArrowUpRight className="w-4 h-4 text-emerald-600" />
                    <span>Departure Exit</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleModeSwitch('ENTRY')}
                    className={`py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                      scanMode === 'ENTRY'
                        ? 'bg-white text-[#2563EB] shadow-sm border border-slate-200/60'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <ArrowDownLeft className="w-4 h-4 text-[#2563EB]" />
                    <span>Return Entry</span>
                  </button>
                </div>
              </div>

              {/* Mode Guidance Tag */}
              <div className={`p-3 rounded-xl border text-xs flex items-center gap-2 ${
                scanMode === 'EXIT'
                  ? 'bg-emerald-50/70 border-emerald-200 text-emerald-800'
                  : 'bg-blue-50/70 border-blue-200 text-blue-800'
              }`}>
                {scanMode === 'EXIT' ? (
                  <>
                    <DoorOpen className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span><strong>Outgoing Mode:</strong> Verifies HOD approval and single-use departure clearance.</span>
                  </>
                ) : (
                  <>
                    <Clock className="w-4 h-4 text-[#2563EB] shrink-0" />
                    <span><strong>Incoming Mode:</strong> Verifies previous departure exit and checks curfew deadline.</span>
                  </>
                )}
              </div>

              {/* Camera Header */}
              <div className="flex items-center justify-between pt-1">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#2563EB] flex items-center justify-center">
                    <ScanLine className="w-4 h-4" />
                  </div>
                  <div>
                    <h2 className="text-sm font-bold text-[#1E293B]">Barcode Scanner</h2>
                    <p className="text-[11px] text-slate-500">Camera scanning or manual token entry</p>
                  </div>
                </div>

                <button
                  onClick={cameraActive ? stopCameraStream : startCameraStream}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                    cameraActive
                      ? 'bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200'
                      : 'bg-blue-50 text-[#2563EB] hover:bg-blue-100 border border-blue-200'
                  }`}
                >
                  {cameraActive ? (
                    <>
                      <CameraOff className="w-3.5 h-3.5" />
                      <span>Stop Camera</span>
                    </>
                  ) : (
                    <>
                      <Camera className="w-3.5 h-3.5" />
                      <span>Start Camera</span>
                    </>
                  )}
                </button>
              </div>

              {/* Camera Viewfinder */}
              {cameraActive ? (
                <div className="relative aspect-video rounded-xl overflow-hidden bg-slate-900 border-2 border-[#2563EB]">
                  <video
                    ref={videoRef}
                    className="w-full h-full object-cover"
                    playsInline
                    autoPlay
                    muted
                  />
                  <div className="absolute inset-0 border-2 border-white/40 pointer-events-none m-6 rounded-lg flex flex-col items-center justify-center">
                    <div className="w-full h-0.5 bg-emerald-400 shadow-[0_0_8px_#34d399] animate-pulse"></div>
                    <span className="text-[10px] text-white/80 font-mono mt-2 bg-slate-900/60 px-2 py-0.5 rounded">
                      Align QR code inside box
                    </span>
                  </div>
                </div>
              ) : cameraError ? (
                <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 flex items-start gap-2.5">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold block mb-0.5">Hardware Notice:</span>
                    <span className="text-[11px] text-amber-800 leading-relaxed">{cameraError}</span>
                  </div>
                </div>
              ) : null}

              {/* Manual Token Input */}
              <div className="space-y-3 pt-2">
                <label className="block text-xs font-semibold text-[#1E293B]">
                  Clearance Token or QR Data
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={tokenInput}
                    onChange={(e) => setTokenInput(e.target.value)}
                    onKeyDown={(e) => { if (e.key === 'Enter') handleVerify(); }}
                    placeholder={scanMode === 'EXIT' ? "CAMPUSORA:GP-XXXX:... or clearance token" : "Enter Pass Token or Pass ID for Return"}
                    className="w-full pl-3.5 pr-20 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono text-[#1E293B] focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:bg-white transition-all"
                  />
                  {tokenInput && (
                    <button
                      onClick={() => setTokenInput('')}
                      className="absolute right-2.5 top-2.5 text-xs text-slate-400 hover:text-slate-600 font-semibold"
                    >
                      Clear
                    </button>
                  )}
                </div>

                <button
                  onClick={() => handleVerify()}
                  disabled={verifying || !tokenInput.trim()}
                  className={`w-full inline-flex items-center justify-center gap-2 py-2.5 px-4 text-white rounded-xl text-xs font-bold transition-colors disabled:opacity-50 shadow-subtle ${
                    scanMode === 'EXIT'
                      ? 'bg-emerald-600 hover:bg-emerald-700'
                      : 'bg-[#2563EB] hover:bg-[#1D4ED8]'
                  }`}
                >
                  {verifying ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Verifying Pass...</span>
                    </>
                  ) : (
                    <>
                      <ShieldCheck className="w-4 h-4" />
                      <span>{scanMode === 'EXIT' ? 'Verify Departure Clearance' : 'Verify Return Entry'}</span>
                    </>
                  )}
                </button>
              </div>

              {/* Checkpoint Security Advisory */}
              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-100 text-[11px] text-slate-500 space-y-1">
                <span className="font-semibold text-slate-700 flex items-center gap-1">
                  <Lock className="w-3 h-3 text-slate-500" />
                  Terminal Verification Rules:
                </span>
                <p>
                  Tokens are hashed with SHA-256 and matched in PostgreSQL.
                  Every departure exit and return entry is permanently recorded with checkpoint timestamps.
                </p>
              </div>

            </div>

          </div>

          {/* Right Column: Student Clearance Result & Actions (7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            
            {verifying ? (
              <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center shadow-card space-y-3">
                <RefreshCw className="w-8 h-8 text-[#2563EB] animate-spin mx-auto" />
                <h3 className="text-sm font-bold text-[#1E293B]">Querying Institutional Database...</h3>
                <p className="text-xs text-slate-400">
                  Verifying cryptographic record against {officerGate} clearance desk
                </p>
              </div>
            ) : verificationError ? (
              
              /* Verification Error Card */
              <div className="bg-white border border-rose-200 rounded-2xl p-6 shadow-card space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-rose-50 border border-rose-200 flex items-center justify-center text-rose-600 shrink-0">
                    <XCircle className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-rose-100 text-rose-700 tracking-wider">
                      Verification Denied: {verificationError.outcome}
                    </span>
                    <h3 className="text-base font-bold text-rose-900 mt-1">Clearance Check Failed</h3>
                    <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                      {verificationError.detail}
                    </p>
                  </div>
                </div>

                <div className="p-3.5 bg-rose-50/50 rounded-xl border border-rose-100 text-xs text-rose-900 space-y-1">
                  <strong>Protocol Guidance:</strong>
                  <ul className="list-disc list-inside text-[11px] text-rose-800 space-y-0.5">
                    {verificationError.outcome === 'NOT_EXITED' && (
                      <li>Student has not completed an authorized departure exit yet. Cannot record return entry.</li>
                    )}
                    {verificationError.outcome === 'ALREADY_RETURNED' && (
                      <li>This pass has already completed return entry. Duplicate entry recording is blocked.</li>
                    )}
                    {verificationError.outcome === 'ALREADY_USED' && (
                      <li>Pass was previously marked as USED for departure. Pass tokens are single-use.</li>
                    )}
                    {verificationError.outcome === 'WRONG_GATE' && (
                      <li>Pass is authorized for a different campus gate. Redirect student to their designated gate.</li>
                    )}
                    <li>All verification attempts are logged in the PostgreSQL audit trail.</li>
                  </ul>
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    onClick={() => {
                      setVerificationError(null);
                      setTokenInput('');
                    }}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl transition-colors"
                  >
                    Clear & Scan Next Student
                  </button>
                </div>
              </div>

            ) : verificationResult ? (

              /* Verified Pass Clearance Card */
              <div className={`bg-white border-2 rounded-2xl shadow-card overflow-hidden transition-all ${
                scanMode === 'ENTRY' ? 'border-blue-400' : 'border-emerald-400'
              }`}>
                
                {/* Header */}
                <div className={`p-5 text-white flex items-center justify-between ${
                  scanMode === 'ENTRY'
                    ? 'bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-700'
                    : 'bg-gradient-to-r from-emerald-600 to-teal-700'
                }`}>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm border border-white/30 flex items-center justify-center">
                      <CheckCircle2 className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-bold tracking-widest text-blue-100">
                        {scanMode === 'ENTRY' ? 'Return Entry Clearance Verified' : 'Institutional Exit Authorization Verified'}
                      </span>
                      <h2 className="text-base font-bold tracking-tight">
                        {scanMode === 'ENTRY' ? 'Student Return Inspection' : 'Gate Pass Active & Valid'}
                      </h2>
                    </div>
                  </div>

                  <span className="font-mono text-xs bg-white/20 px-2.5 py-1 rounded-lg font-bold">
                    {verificationResult.pass_id}
                  </span>
                </div>

                {/* Body Content */}
                <div className="p-6 space-y-5">
                  
                  {/* Curfew Overdue Alert Banner (in Return Mode) */}
                  {scanMode === 'ENTRY' && verificationResult.is_overdue && (
                    <div className="p-4 bg-rose-50 border-2 border-rose-400 rounded-xl flex items-start gap-3">
                      <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                      <div>
                        <h4 className="text-xs font-bold text-rose-900 uppercase tracking-wide">
                          Curfew Violation / Overdue Return Entry
                        </h4>
                        <p className="text-[11px] text-rose-800 mt-0.5 leading-relaxed">
                          Student exceeded authorized campus return curfew deadline ({new Date(verificationResult.expected_return_time).toLocaleString()}). Return entry will be logged in PostgreSQL with disciplinary curfew violation flag.
                        </p>
                      </div>
                    </div>
                  )}

                  {/* Student Identity Card Box */}
                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex items-center gap-3.5">
                      <div className="relative shrink-0">
                        <div className="w-14 h-14 rounded-xl overflow-hidden bg-slate-200 border-2 border-[#2563EB]/40 shadow-sm flex items-center justify-center">
                          <img
                            src="https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=256&h=256"
                            alt={verificationResult.student.name}
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              e.target.style.display = 'none';
                              e.target.parentElement.innerHTML = `<div class="w-full h-full bg-[#2563EB] text-white flex items-center justify-center font-bold text-lg">${verificationResult.student.name.charAt(0)}</div>`;
                            }}
                          />
                        </div>
                        <span className="absolute -bottom-1 -right-1 px-1 py-0.2 rounded text-[8px] font-bold uppercase bg-emerald-600 text-white shadow-xs border border-white">
                          Verified
                        </span>
                      </div>
                      <div>
                        <h3 className="text-base font-bold text-[#1E293B]">
                          {verificationResult.student.name}
                        </h3>
                        <p className="text-xs font-mono font-semibold text-[#2563EB]">
                          {verificationResult.student.registration_number}
                        </p>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          {verificationResult.student.department}
                        </p>
                      </div>
                    </div>

                    <div className="text-right sm:border-l sm:border-slate-200 sm:pl-4">
                      <span className="text-[10px] text-slate-400 uppercase font-mono block">Hostel Room</span>
                      <span className="text-xs font-bold text-slate-700 font-mono">
                        {verificationResult.student.room_number || 'Day Scholar'}
                      </span>
                      <span className="text-[10px] text-slate-400 uppercase font-mono block mt-1">Phone</span>
                      <span className="text-xs text-slate-600 font-mono">
                        {verificationResult.student.phone || '—'}
                      </span>
                    </div>
                  </div>

                  {/* Pass Details Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div className="p-3 bg-blue-50/50 rounded-xl border border-blue-100 space-y-0.5">
                      <span className="text-slate-400 text-[10px] uppercase font-semibold">Leave Category</span>
                      <p className="font-bold text-[#2563EB]">{verificationResult.leave_type}</p>
                    </div>

                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-0.5">
                      <span className="text-slate-400 text-[10px] uppercase font-semibold">Authorized Gate(s)</span>
                      <p className="font-bold text-emerald-700 flex items-center gap-1">
                        <Check className="w-3 h-3 text-emerald-600" />
                        {verificationResult.authorized_gate}
                      </p>
                    </div>

                    {scanMode === 'ENTRY' ? (
                      <>
                        <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-0.5">
                          <span className="text-slate-400 text-[10px] uppercase font-semibold">Departure Exit Time</span>
                          <p className="font-medium text-slate-800">
                            {verificationResult.exit_recorded_at 
                              ? new Date(verificationResult.exit_recorded_at).toLocaleString() 
                              : 'Earlier today'}
                          </p>
                        </div>

                        <div className={`p-3 rounded-xl border space-y-0.5 ${
                          verificationResult.is_overdue
                            ? 'bg-rose-50 border-rose-200 text-rose-900'
                            : 'bg-emerald-50 border-emerald-200 text-emerald-900'
                        }`}>
                          <span className="text-[10px] uppercase font-semibold block">Curfew Return Deadline</span>
                          <p className="font-bold">
                            {verificationResult.expected_return_time
                              ? new Date(verificationResult.expected_return_time).toLocaleString()
                              : 'Curfew 21:00'}
                            <span className="ml-2 text-[10px] px-1.5 py-0.5 rounded font-bold uppercase">
                              {verificationResult.is_overdue ? '• PAST DEADLINE' : '• ON SCHEDULE'}
                            </span>
                          </p>
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-0.5">
                          <span className="text-slate-400 text-[10px] uppercase font-semibold">Linked Leave Application</span>
                          <p className="font-mono font-semibold text-[#1E293B]">{verificationResult.application_id}</p>
                        </div>

                        <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-0.5">
                          <span className="text-slate-400 text-[10px] uppercase font-semibold">Validity Window</span>
                          <p className="font-medium text-slate-700">
                            {new Date(verificationResult.valid_from).toLocaleDateString()} — {new Date(verificationResult.valid_until).toLocaleDateString()}
                          </p>
                        </div>
                      </>
                    )}
                  </div>

                  {verificationResult.reason && (
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs">
                      <span className="font-semibold text-slate-700">Purpose / Reason:</span>
                      <p className="text-slate-600 mt-0.5 italic">"{verificationResult.reason}"</p>
                    </div>
                  )}

                  {/* Guard Remarks Input */}
                  <div className="space-y-1.5">
                    <label className="block text-xs font-semibold text-[#1E293B]">
                      Guard {scanMode === 'ENTRY' ? 'Return Entry' : 'Departure'} Remarks (Optional)
                    </label>
                    <input
                      type="text"
                      value={guardRemarks}
                      onChange={(e) => setGuardRemarks(e.target.value)}
                      placeholder={
                        scanMode === 'ENTRY'
                          ? "e.g. Identity photo confirmed; luggage re-inspected; returned on time"
                          : "e.g. Identity photo verified; baggage checked; exiting on 2-wheeler"
                      }
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-[#1E293B] focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:bg-white"
                    />
                  </div>

                  {/* Execution Action Buttons */}
                  {scanMode === 'ENTRY' ? (
                    <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
                      <button
                        onClick={handleConfirmReturn}
                        disabled={actionLoading}
                        className="w-full inline-flex items-center justify-center gap-2 py-3 px-4 bg-[#2563EB] hover:bg-[#1D4ED8] text-white rounded-xl text-xs font-bold transition-all shadow-md hover:shadow-lg disabled:opacity-50"
                      >
                        {actionLoading ? (
                          <>
                            <RefreshCw className="w-4 h-4 animate-spin" />
                            <span>Recording Return Entry...</span>
                          </>
                        ) : (
                          <>
                            <ArrowDownLeft className="w-4 h-4" />
                            <span>Confirm Return Entry & Close Pass</span>
                          </>
                        )}
                      </button>

                      <button
                        onClick={() => {
                          setVerificationResult(null);
                          setTokenInput('');
                        }}
                        className="w-full sm:w-auto px-4 py-3 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
                      >
                        Cancel
                      </button>
                    </div>
                  ) : (
                    <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
                      <button
                        onClick={handleConfirmExit}
                        disabled={actionLoading}
                        className="w-full sm:flex-1 inline-flex items-center justify-center gap-2 py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-md hover:shadow-lg disabled:opacity-50"
                      >
                        {actionLoading ? (
                          <>
                            <RefreshCw className="w-4 h-4 animate-spin" />
                            <span>Recording Exit in Ledger...</span>
                          </>
                        ) : (
                          <>
                            <DoorOpen className="w-4 h-4" />
                            <span>Confirm Exit & Record Departure</span>
                          </>
                        )}
                      </button>

                      <button
                        onClick={() => setShowDenialModal(true)}
                        disabled={actionLoading}
                        className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 py-3 px-4 bg-white border border-rose-300 text-rose-700 hover:bg-rose-50 rounded-xl text-xs font-semibold transition-colors disabled:opacity-50"
                      >
                        <XCircle className="w-4 h-4" />
                        <span>Deny Departure</span>
                      </button>
                    </div>
                  )}

                </div>

              </div>

            ) : (

              /* Awaiting Scan Placeholder */
              <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center shadow-card space-y-4">
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mx-auto ${
                  scanMode === 'ENTRY'
                    ? 'bg-blue-50 border border-blue-100 text-[#2563EB]'
                    : 'bg-emerald-50 border border-emerald-100 text-emerald-600'
                }`}>
                  <ScanLine className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-[#1E293B]">
                    Terminal Ready for {scanMode === 'ENTRY' ? 'Return Verification' : 'Departure Clearance'}
                  </h3>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1 leading-relaxed">
                    {scanMode === 'ENTRY'
                      ? 'Scan student outpass barcode or enter pass code upon campus return. System will verify departure history, curfew timeliness, and notify parent/warden.'
                      : 'Scan student outpass barcode using the camera terminal or enter the clearance token to verify authorized campus exit.'}
                  </p>
                </div>
                <div className="pt-2">
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                    Terminal {officerGate} Online
                  </span>
                </div>
              </div>

            )}

          </div>

        </div>
      )}

      {/* TAB 2: OFF-CAMPUS & OVERDUE REGISTRY */}
      {activeTab === 'outside' && (
        <div className="space-y-4">
          
          {/* Header Controls */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-card flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-base font-bold text-[#1E293B]">Off-Campus & Overdue Student Registry</h2>
              <p className="text-xs text-slate-500">Live monitoring of all students with confirmed campus departures</p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={outsideSearch}
                  onChange={(e) => setOutsideSearch(e.target.value)}
                  placeholder="Search name, roll no, room..."
                  className="pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-[#1E293B] focus:outline-none focus:ring-2 focus:ring-[#2563EB]"
                />
              </div>

              <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-medium">
                <button
                  onClick={() => setOutsideFilter('ALL')}
                  className={`px-3 py-1 rounded-lg transition-colors ${
                    outsideFilter === 'ALL'
                      ? 'bg-white shadow-subtle text-[#1E293B] font-bold'
                      : 'text-slate-500'
                  }`}
                >
                  All Outside ({outsideStudents.length})
                </button>
                <button
                  onClick={() => setOutsideFilter('OVERDUE')}
                  className={`px-3 py-1 rounded-lg transition-colors flex items-center gap-1 ${
                    outsideFilter === 'OVERDUE'
                      ? 'bg-white shadow-subtle text-rose-700 font-bold'
                      : 'text-slate-500'
                  }`}
                >
                  <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                  <span>Overdue ({overdueCount})</span>
                </button>
              </div>

              <button
                onClick={loadOutsideStudents}
                disabled={outsideLoading}
                className="p-2 border border-slate-200 rounded-xl hover:bg-slate-50 text-slate-600 transition-colors"
                title="Refresh Outside Registry"
              >
                <RefreshCw className={`w-4 h-4 ${outsideLoading ? 'animate-spin text-[#2563EB]' : ''}`} />
              </button>
            </div>
          </div>

          {/* Table of Outside Students */}
          <div className="bg-white border border-slate-200 rounded-2xl shadow-card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[10px]">
                  <tr>
                    <th className="py-3.5 px-4">Student</th>
                    <th className="py-3.5 px-4">Pass ID / Type</th>
                    <th className="py-3.5 px-4">Residence</th>
                    <th className="py-3.5 px-4">Departure Time</th>
                    <th className="py-3.5 px-4">Curfew Return Deadline</th>
                    <th className="py-3.5 px-4">Curfew Status</th>
                    <th className="py-3.5 px-4">Parent Phone</th>
                    <th className="py-3.5 px-4 text-right">Quick Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {outsideLoading ? (
                    <tr>
                      <td colSpan="8" className="py-12 text-center text-slate-400">
                        <RefreshCw className="w-6 h-6 text-[#2563EB] animate-spin mx-auto mb-2" />
                        <span>Querying active outside student records...</span>
                      </td>
                    </tr>
                  ) : filteredOutsideStudents.length === 0 ? (
                    <tr>
                      <td colSpan="8" className="py-12 text-center text-slate-400">
                        No students currently off-campus match your filter criteria.
                      </td>
                    </tr>
                  ) : (
                    filteredOutsideStudents.map((st) => (
                      <tr 
                        key={st.pass_id} 
                        className={`hover:bg-slate-50/80 transition-colors ${
                          st.is_overdue ? 'bg-rose-50/30' : ''
                        }`}
                      >
                        <td className="py-3.5 px-4">
                          <div className="flex items-center gap-2.5">
                            <div className="w-8 h-8 rounded-lg bg-slate-200 border border-slate-300 overflow-hidden flex items-center justify-center font-bold text-xs text-slate-700 shrink-0">
                              {st.student_name ? st.student_name.charAt(0) : 'S'}
                            </div>
                            <div>
                              <p className="font-bold text-[#1E293B]">{st.student_name}</p>
                              <p className="text-[10px] font-mono text-slate-500">{st.registration_number}</p>
                            </div>
                          </div>
                        </td>

                        <td className="py-3.5 px-4">
                          <p className="font-mono font-bold text-slate-800">{st.pass_id}</p>
                          <p className="text-[10px] text-slate-500">{st.leave_type}</p>
                        </td>

                        <td className="py-3.5 px-4">
                          <p className="font-semibold text-slate-700">{st.hostel_block || 'Hostel'}</p>
                          <p className="text-[10px] text-slate-500">{st.room_number ? `Room ${st.room_number}` : 'Day Scholar'}</p>
                        </td>

                        <td className="py-3.5 px-4 font-mono text-slate-600 text-[11px] whitespace-nowrap">
                          {st.exit_recorded_at ? new Date(st.exit_recorded_at).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' }) : '—'}
                        </td>

                        <td className="py-3.5 px-4 font-mono text-[11px] whitespace-nowrap">
                          <span className={st.is_overdue ? 'text-rose-700 font-bold' : 'text-slate-700 font-semibold'}>
                            {st.expected_return_time ? new Date(st.expected_return_time).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' }) : 'Curfew 21:00'}
                          </span>
                        </td>

                        <td className="py-3.5 px-4">
                          {st.is_overdue ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-700 border border-rose-300">
                              <AlertTriangle className="w-3 h-3" />
                              OVERDUE ({st.minutes_overdue ? `+${st.minutes_overdue}m` : 'CURFEW'})
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                              <CheckCircle2 className="w-3 h-3" />
                              ON TRACK
                            </span>
                          )}
                        </td>

                        <td className="py-3.5 px-4 font-mono text-slate-600 text-[11px]">
                          {st.parent_phone ? (
                            <span className="inline-flex items-center gap-1">
                              <Phone className="w-3 h-3 text-slate-400" />
                              {st.parent_phone}
                            </span>
                          ) : '—'}
                        </td>

                        <td className="py-3.5 px-4 text-right">
                          <button
                            onClick={() => handleQuickReturnVerify(st)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 bg-blue-50 text-[#2563EB] hover:bg-blue-100 border border-blue-200 rounded-lg text-xs font-semibold transition-colors shadow-xs"
                          >
                            <ArrowDownLeft className="w-3.5 h-3.5" />
                            <span>Verify Return</span>
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}

      {/* TAB 3: GATE MOVEMENT AUDIT LOGS */}
      {activeTab === 'logs' && (
        <div className="bg-white border border-slate-200 rounded-2xl shadow-card overflow-hidden">
          
          {/* Header & Controls */}
          <div className="p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-base font-bold text-[#1E293B]">Gate Movement Audit Ledger</h2>
              <p className="text-xs text-slate-500">Immutable chronological record of campus departures and return entries</p>
            </div>

            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-medium">
                <button
                  onClick={() => setEventFilter('ALL')}
                  className={`px-3 py-1 rounded-lg transition-colors ${eventFilter === 'ALL' ? 'bg-white shadow-subtle text-[#1E293B] font-bold' : 'text-slate-500'}`}
                >
                  All ({events.length})
                </button>
                <button
                  onClick={() => setEventFilter('EXITS')}
                  className={`px-3 py-1 rounded-lg transition-colors ${eventFilter === 'EXITS' ? 'bg-white shadow-subtle text-emerald-700 font-bold' : 'text-slate-500'}`}
                >
                  Departures ({todayDepartures})
                </button>
                <button
                  onClick={() => setEventFilter('RETURNS')}
                  className={`px-3 py-1 rounded-lg transition-colors ${eventFilter === 'RETURNS' ? 'bg-white shadow-subtle text-[#2563EB] font-bold' : 'text-slate-500'}`}
                >
                  Returns ({todayReturns})
                </button>
                <button
                  onClick={() => setEventFilter('FLAGGED')}
                  className={`px-3 py-1 rounded-lg transition-colors ${eventFilter === 'FLAGGED' ? 'bg-white shadow-subtle text-rose-700 font-bold' : 'text-slate-500'}`}
                >
                  Flagged
                </button>
              </div>

              <button
                onClick={loadEvents}
                disabled={eventsLoading}
                className="p-2 border border-slate-200 rounded-xl hover:bg-slate-50 text-slate-600 transition-colors"
                title="Refresh Events"
              >
                <RefreshCw className={`w-4 h-4 ${eventsLoading ? 'animate-spin text-[#2563EB]' : ''}`} />
              </button>
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="py-3.5 px-4">Timestamp</th>
                  <th className="py-3.5 px-4">Movement</th>
                  <th className="py-3.5 px-4">Pass ID</th>
                  <th className="py-3.5 px-4">Student Details</th>
                  <th className="py-3.5 px-4">Checkpoint</th>
                  <th className="py-3.5 px-4">Verification Outcome</th>
                  <th className="py-3.5 px-4">Officer</th>
                  <th className="py-3.5 px-4">Remarks</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredEvents.length === 0 ? (
                  <tr>
                    <td colSpan="8" className="py-10 text-center text-slate-400">
                      No security gate movement events found for this filter.
                    </td>
                  </tr>
                ) : (
                  filteredEvents.map((evt) => {
                    const isSuccess = evt.verification_outcome === 'SUCCESS' || evt.verification_outcome === 'RETURN_SUCCESS';
                    const isEntry = evt.event_type === 'ENTRY';
                    return (
                      <tr key={evt.id} className="hover:bg-slate-50/60 transition-colors">
                        <td className="py-3.5 px-4 font-mono text-slate-500 text-[11px] whitespace-nowrap">
                          {new Date(evt.timestamp).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                        </td>
                        <td className="py-3.5 px-4">
                          {isEntry ? (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-blue-100 text-[#2563EB]">
                              <ArrowDownLeft className="w-3 h-3" />
                              RETURN ENTRY
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                              <DoorOpen className="w-3 h-3" />
                              CAMPUS EXIT
                            </span>
                          )}
                        </td>
                        <td className="py-3.5 px-4 font-mono font-bold text-[#1E293B]">
                          {evt.pass_id || '—'}
                        </td>
                        <td className="py-3.5 px-4">
                          <p className="font-semibold text-[#1E293B]">{evt.student_name || 'Unregistered'}</p>
                          <p className="text-[10px] font-mono text-slate-400">{evt.student_registration || '—'}</p>
                        </td>
                        <td className="py-3.5 px-4 text-slate-600">
                          {evt.gate_type}
                        </td>
                        <td className="py-3.5 px-4">
                          {isSuccess ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                              <CheckCircle2 className="w-3 h-3" />
                              {isEntry ? 'RETURN CLEARED' : 'EXIT CONFIRMED'}
                            </span>
                          ) : evt.verification_outcome === 'ALREADY_RETURNED' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-200">
                              <XCircle className="w-3 h-3" />
                              ALREADY RETURNED
                            </span>
                          ) : evt.verification_outcome === 'NOT_EXITED' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-700 border border-amber-200">
                              <AlertTriangle className="w-3 h-3" />
                              NOT EXITED
                            </span>
                          ) : evt.verification_outcome === 'ALREADY_USED' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-200">
                              <XCircle className="w-3 h-3" />
                              REPLAY BLOCKED
                            </span>
                          ) : evt.verification_outcome === 'WRONG_GATE' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-700 border border-amber-200">
                              <AlertTriangle className="w-3 h-3" />
                              WRONG GATE
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-red-50 text-red-700 border border-red-200">
                              <XCircle className="w-3 h-3" />
                              {evt.verification_outcome}
                            </span>
                          )}
                        </td>
                        <td className="py-3.5 px-4 text-slate-600 text-[11px]">
                          {evt.security_officer_name || 'Terminal Guard'}
                        </td>
                        <td className="py-3.5 px-4 text-slate-500 max-w-xs truncate text-[11px]">
                          {evt.remarks || '—'}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

        </div>
      )}

      {/* TAB 4: GATE ANALYTICS */}
      {activeTab === 'analytics' && (
        <AnalyticsView 
          title="Campus Security Checkpoint & Curfew Analytics"
          subtitle="Real-time institutional campus occupancy, curfew breach tracking, and daily gate traffic."
        />
      )}

      {/* TAB 5: CHECKPOINT & OFFICER PROFILE */}
      {activeTab === 'profile' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-card space-y-6 max-w-2xl">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-[#2563EB] text-white flex items-center justify-center font-bold text-xl shadow-md">
              {officerName.charAt(0)}
            </div>
            <div>
              <h2 className="text-lg font-bold text-[#1E293B]">{officerName}</h2>
              <p className="text-xs text-slate-500">Security Clearance Officer • CAMPUSORA System</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-100">
              <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider block">Assigned Gate</span>
              <p className="text-sm font-bold text-[#1E293B] mt-0.5">{officerGate}</p>
            </div>

            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-100">
              <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider block">Institutional ID</span>
              <p className="text-sm font-bold font-mono text-[#1E293B] mt-0.5">{employeeId}</p>
            </div>

            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-100">
              <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider block">Access Permissions</span>
              <p className="text-xs font-semibold text-emerald-700 mt-0.5">Departure Clearance & Return Verification</p>
            </div>

            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-100">
              <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider block">Shift Terminal</span>
              <p className="text-xs font-semibold text-slate-700 mt-0.5">Terminal #01 (Active)</p>
            </div>
          </div>

          <div className="p-4 bg-blue-50/70 border border-blue-100 rounded-xl text-xs text-slate-700 space-y-1">
            <span className="font-semibold text-blue-950">Security Checkpoint Integrity:</span>
            <p className="text-[11px] text-slate-600 leading-relaxed">
              Your guard account is bound to <strong>{officerGate}</strong>. Pass tokens are verified against backend clearance policies. Any attempt to verify passes authorized for another gate will be rejected with an audit log record.
            </p>
          </div>
        </div>
      )}

      {/* Denial Reason Modal */}
      {showDenialModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 shadow-xl border border-slate-200">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-50 border border-rose-200 text-rose-600 flex items-center justify-center">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-[#1E293B]">Deny Departure Clearance</h3>
                <p className="text-xs text-slate-500">Record officer reason for preventing student exit</p>
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-xs font-semibold text-slate-700">Mandatory Denial Reason</label>
              <textarea
                rows="3"
                value={denialReason}
                onChange={(e) => setDenialReason(e.target.value)}
                placeholder="e.g. Student failed visual identification; luggage check discrepancy; curfew violation..."
                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-[#1E293B] focus:outline-none focus:ring-2 focus:ring-rose-500 focus:bg-white"
              ></textarea>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => {
                  setShowDenialModal(false);
                  setDenialReason('');
                }}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={handleDenyExit}
                disabled={actionLoading || !denialReason.trim()}
                className="px-4 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl disabled:opacity-50"
              >
                {actionLoading ? 'Recording...' : 'Confirm Denial & Log Event'}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
