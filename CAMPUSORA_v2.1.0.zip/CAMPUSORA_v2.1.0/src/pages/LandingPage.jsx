import React from 'react';
import { Link } from 'react-router-dom';
import { 
  GraduationCap, 
  UserCheck, 
  Building2, 
  Shield, 
  ArrowRight
} from 'lucide-react';
import { BRAND } from '../config/branding';

const roleIcons = {
  student: GraduationCap,
  faculty: UserCheck,
  hod: Building2,
  security: Shield,
};

export default function LandingPage() {
  return (
    <div className="bg-[#F8FAFC] text-[#1E293B]">
      
      {/* Hero Section */}
      <section className="py-20 lg:py-28 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto text-center">
        
        {/* Subtle Brand Tag */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white border border-slate-200 text-xs font-medium text-slate-600 mb-6 shadow-subtle">
          <span className="w-2 h-2 rounded-full bg-[#2563EB]"></span>
          <span>{BRAND.tagline}</span>
        </div>

        {/* Heading */}
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-[#1E293B] leading-tight">
          {BRAND.headline}
        </h1>

        {/* Description */}
        <p className="mt-5 text-lg sm:text-xl text-slate-600 max-w-2xl mx-auto leading-relaxed">
          {BRAND.description}
        </p>

        {/* Action Buttons */}
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
          <Link
            to="/student"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 rounded-lg text-base font-semibold text-white bg-[#2563EB] hover:bg-[#1D4ED8] transition-all shadow-subtle"
          >
            <span>Explore Student Dashboard</span>
            <ArrowRight className="w-4 h-4" />
          </Link>

          <Link
            to="/faculty"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 rounded-lg text-base font-semibold text-blue-700 bg-white border border-blue-200 hover:bg-blue-50 transition-all shadow-subtle"
          >
            <span>Faculty Portal</span>
          </Link>

          <Link
            to="/hod"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 rounded-lg text-base font-semibold text-purple-700 bg-white border border-purple-200 hover:bg-purple-50 transition-all shadow-subtle"
          >
            <span>HOD Desk</span>
          </Link>
        </div>

      </section>

      {/* Four Clean Role Cards */}
      <section id="roles" className="pb-24 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
        
        <div className="text-center mb-10">
          <h2 className="text-xl font-bold text-[#1E293B]">Choose Your Portal</h2>
          <p className="text-sm text-slate-500 mt-1">Access your personalized workspace with role-based permissions.</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {BRAND.roles.map((role) => {
            const Icon = roleIcons[role.id] || GraduationCap;
            const targetUrl = 
              role.id === 'student' ? '/student' :
              role.id === 'faculty' ? '/faculty' :
              role.id === 'hod' ? '/hod' :
              `/login?role=${role.id}`;

            const actionText = 
              role.id === 'student' || role.id === 'faculty' || role.id === 'hod'
                ? 'Open Dashboard'
                : 'Sign In';

            return (
              <div
                key={role.id}
                className="bg-white border border-slate-200 rounded-xl p-6 shadow-subtle hover:border-slate-300 hover:shadow-card transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="w-10 h-10 rounded-lg bg-slate-50 border border-slate-100 flex items-center justify-center text-[#2563EB] mb-4">
                    <Icon className="w-5 h-5" />
                  </div>

                  <h3 className="text-base font-semibold text-[#1E293B]">
                    {role.title}
                  </h3>

                  <p className="text-xs text-slate-500 mt-2 leading-relaxed">
                    {role.description}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-100">
                  <Link
                    to={targetUrl}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#2563EB] hover:text-[#1D4ED8] transition-colors"
                  >
                    <span>{actionText}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Link>
                </div>
              </div>
            );
          })}
        </div>

      </section>

    </div>
  );
}
