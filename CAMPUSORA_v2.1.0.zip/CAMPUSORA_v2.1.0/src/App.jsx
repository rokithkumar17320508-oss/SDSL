import React, { Suspense, lazy } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import LandingPage from './pages/LandingPage';
import LoginPage from './pages/LoginPage';
import ProtectedRoute from './components/ProtectedRoute';

// Layouts (Static for instant structural rendering)
import StudentLayout from './components/StudentLayout';
import FacultyLayout from './components/faculty/FacultyLayout';
import HodLayout from './components/hod/HodLayout';
import SecurityLayout from './components/security/SecurityLayout';

// Student Portal (Lazy Loaded)
const StudentDashboard = lazy(() => import('./pages/student/StudentDashboard'));
const ApplyLeavePage = lazy(() => import('./pages/student/ApplyLeavePage'));
const MyApplicationsPage = lazy(() => import('./pages/student/MyApplicationsPage'));
const GatePassPage = lazy(() => import('./pages/student/GatePassPage'));
const StudentProfilePage = lazy(() => import('./pages/student/StudentProfilePage'));

// Faculty Portal (Lazy Loaded)
const FacultyDashboard = lazy(() => import('./pages/faculty/FacultyDashboard'));
const FacultyRequestsPage = lazy(() => import('./pages/faculty/FacultyRequestsPage'));
const FacultyHistoryPage = lazy(() => import('./pages/faculty/FacultyHistoryPage'));
const FacultyProfilePage = lazy(() => import('./pages/faculty/FacultyProfilePage'));

// HOD Portal (Lazy Loaded)
const HodDashboard = lazy(() => import('./pages/hod/HodDashboard'));
const HodApprovalsPage = lazy(() => import('./pages/hod/HodApprovalsPage'));
const HodHistoryPage = lazy(() => import('./pages/hod/HodHistoryPage'));
const HodOverviewPage = lazy(() => import('./pages/hod/HodOverviewPage'));
const HodProfilePage = lazy(() => import('./pages/hod/HodProfilePage'));
const HodSectionDirectoryPage = lazy(() => import('./pages/hod/HodSectionDirectoryPage'));

// Security Portal (Lazy Loaded)
const SecurityDashboard = lazy(() => import('./pages/security/SecurityDashboard'));

function PageLoadingFallback() {
  return (
    <div className="min-h-[50vh] flex flex-col items-center justify-center p-8 space-y-3">
      <div className="w-8 h-8 border-3 border-blue-200 border-t-[#2563EB] rounded-full animate-spin"></div>
      <p className="text-xs font-semibold text-slate-500">Loading CAMPUSORA portal...</p>
    </div>
  );
}

function PublicLayout({ children }) {
  return (
    <div className="min-h-screen flex flex-col bg-[#F8FAFC] text-[#1E293B] font-sans antialiased selection:bg-blue-100 selection:text-blue-900">
      <Navbar />
      <main className="flex-1">{children}</main>
      <Footer />
    </div>
  );
}

export default function App() {
  return (
    <Suspense fallback={<PageLoadingFallback />}>
      <Routes>
        {/* Public Pages */}
        <Route
          path="/"
          element={
            <PublicLayout>
              <LandingPage />
            </PublicLayout>
          }
        />
        <Route
          path="/login"
          element={
            <PublicLayout>
              <LoginPage />
            </PublicLayout>
          }
        />

        {/* Protected Student Portal Routes */}
        <Route element={<ProtectedRoute allowedRoles={['student']} />}>
          <Route path="/student" element={<StudentLayout />}>
            <Route index element={<StudentDashboard />} />
            <Route path="dashboard" element={<StudentDashboard />} />
            <Route path="apply" element={<ApplyLeavePage />} />
            <Route path="applications" element={<MyApplicationsPage />} />
            <Route path="gate-pass" element={<GatePassPage />} />
            <Route path="profile" element={<StudentProfilePage />} />
          </Route>
        </Route>

        {/* Protected Faculty Portal Routes */}
        <Route element={<ProtectedRoute allowedRoles={['faculty']} />}>
          <Route path="/faculty" element={<FacultyLayout />}>
            <Route index element={<FacultyDashboard />} />
            <Route path="dashboard" element={<FacultyDashboard />} />
            <Route path="requests" element={<FacultyRequestsPage />} />
            <Route path="history" element={<FacultyHistoryPage />} />
            <Route path="profile" element={<FacultyProfilePage />} />
          </Route>
        </Route>

        {/* Protected HOD Portal Routes */}
        <Route element={<ProtectedRoute allowedRoles={['hod']} />}>
          <Route path="/hod" element={<HodLayout />}>
            <Route index element={<HodDashboard />} />
            <Route path="dashboard" element={<HodDashboard />} />
            <Route path="approvals" element={<HodApprovalsPage />} />
            <Route path="history" element={<HodHistoryPage />} />
            <Route path="overview" element={<HodOverviewPage />} />
            <Route path="sections" element={<HodSectionDirectoryPage />} />
            <Route path="sections/:sectionName" element={<HodSectionDirectoryPage />} />
            <Route path="profile" element={<HodProfilePage />} />
          </Route>
        </Route>

        {/* Protected Security Portal Routes */}
        <Route element={<ProtectedRoute allowedRoles={['security']} />}>
          <Route path="/security" element={<SecurityLayout />}>
            <Route index element={<SecurityDashboard />} />
            <Route path="dashboard" element={<SecurityDashboard />} />
            <Route path="scanner" element={<SecurityDashboard />} />
            <Route path="outside" element={<SecurityDashboard />} />
            <Route path="analytics" element={<SecurityDashboard />} />
            <Route path="logs" element={<SecurityDashboard />} />
            <Route path="profile" element={<SecurityDashboard />} />
          </Route>
        </Route>

        {/* Fallback */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Suspense>
  );
}
