/**
 * Shared demonstration data store for CAMPUSORA
 * Connects Student, Faculty, and HOD workflows via localStorage.
 */

export const SAMPLE_STUDENT = {
  name: 'Aarav Sharma',
  regNo: '717621104084',
  department: 'Computer Science & Engineering',
  degree: 'B.E. Computer Science',
  year: 'IV Year',
  semester: 'Semester 7',
  section: 'Section B',
  email: 'aarav.sharma@campusora.edu',
  phone: '+91 98765 43210',
  attendance: 87.5,
  facultyAdvisor: 'Dr. S. K. Verma',
  hostelBlock: 'Ganga Hostel — Room 304',
};

export const SAMPLE_FACULTY = {
  name: 'Dr. S. K. Verma',
  employeeId: 'FAC-CSE-402',
  department: 'Computer Science & Engineering',
  designation: 'Associate Professor & Class Advisor',
  email: 'sk.verma@campusora.edu',
  phone: '+91 98451 23456',
  assignedClass: 'IV Year CSE - Section B (64 Students)',
  officeRoom: 'Tech Block 2 — Room 314',
};

export const SAMPLE_HOD = {
  name: 'Prof. R. Mehra',
  employeeId: 'HOD-CSE-01',
  department: 'Computer Science & Engineering',
  designation: 'Head of Department & Professor',
  email: 'hod.cse@campusora.edu',
  phone: '+91 94220 88990',
  officeRoom: 'Department Executive Office — Hall 101',
  totalFaculty: 24,
  totalStudents: 480,
};

export const INITIAL_APPLICATIONS = [
  {
    id: 'APP-1048',
    studentName: 'Aarav Sharma',
    regNo: '717621104084',
    department: 'Computer Science & Engineering',
    year: 'IV Year (Sec B)',
    attendance: 87.5,
    type: 'Day Pass',
    startDate: '2026-11-20',
    endDate: '2026-11-20',
    reason: 'Medical consultation at Apollo Hospital',
    status: 'Pending Faculty Review',
    submittedAt: '2026-11-16',
    facultyRemarks: '',
    hodRemarks: '',
  },
  {
    id: 'APP-1042',
    studentName: 'Priya Patel',
    regNo: '717621104062',
    department: 'Computer Science & Engineering',
    year: 'IV Year (Sec B)',
    attendance: 91.0,
    type: 'On-Duty',
    startDate: '2026-11-22',
    endDate: '2026-11-24',
    reason: 'Paper presentation at IEEE International Student Conference',
    status: 'Pending HOD Review',
    submittedAt: '2026-11-15',
    facultyRemarks: 'Verified research paper acceptance letter. Attendance exceeds 90%. Recommended.',
    hodRemarks: '',
  },
  {
    id: 'APP-1035',
    studentName: 'Aarav Sharma',
    regNo: '717621104084',
    department: 'Computer Science & Engineering',
    year: 'IV Year (Sec B)',
    attendance: 87.5,
    type: 'On-Duty',
    startDate: '2026-11-12',
    endDate: '2026-11-14',
    reason: 'National Hackathon Championship at IIT Madras',
    status: 'HOD Approved',
    submittedAt: '2026-11-10',
    facultyRemarks: 'Hackathon team lead. OD recommended.',
    hodRemarks: 'Approved for national competition. OD credited to attendance.',
  },
  {
    id: 'APP-1029',
    studentName: 'Rohan Das',
    regNo: '717621104071',
    department: 'Computer Science & Engineering',
    year: 'IV Year (Sec B)',
    attendance: 84.0,
    type: 'Hostel Outpass',
    startDate: '2026-11-26',
    endDate: '2026-11-28',
    reason: 'Attending cousin wedding ceremony',
    status: 'Pending HOD Review',
    submittedAt: '2026-11-14',
    facultyRemarks: 'Parent telephonic consent verified. Recommended.',
    hodRemarks: '',
  },
  {
    id: 'APP-1021',
    studentName: 'Aarav Sharma',
    regNo: '717621104084',
    department: 'Computer Science & Engineering',
    year: 'IV Year (Sec B)',
    attendance: 87.5,
    type: 'Hostel Outpass',
    startDate: '2026-11-05',
    endDate: '2026-11-07',
    reason: "Attending sister's wedding at native place",
    status: 'HOD Approved',
    submittedAt: '2026-11-03',
    facultyRemarks: 'Family event outpass endorsed.',
    hodRemarks: 'Cleared for travel.',
  },
  {
    id: 'APP-1008',
    studentName: 'Aarav Sharma',
    regNo: '717621104084',
    department: 'Computer Science & Engineering',
    year: 'IV Year (Sec B)',
    attendance: 87.5,
    type: 'Regular Leave',
    startDate: '2026-10-22',
    endDate: '2026-10-22',
    reason: 'Personal family emergency',
    status: 'Rejected',
    submittedAt: '2026-10-21',
    facultyRemarks: 'Clashes with internal laboratory examination. Request denied.',
    hodRemarks: '',
  },
];

const STORAGE_KEY = 'campusora_student_applications';

export function getStoredApplications() {
  if (typeof window === 'undefined') return INITIAL_APPLICATIONS;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_APPLICATIONS));
      return INITIAL_APPLICATIONS;
    }
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed) || parsed.length === 0) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_APPLICATIONS));
      return INITIAL_APPLICATIONS;
    }

    // Normalize any legacy statuses from earlier prototypes if present
    const normalized = parsed.map((app) => {
      let status = app.status;
      if (status === 'Pending') status = 'Pending Faculty Review';
      if (status === 'Faculty Approved') status = 'Pending HOD Review';
      return {
        studentName: app.studentName || SAMPLE_STUDENT.name,
        regNo: app.regNo || SAMPLE_STUDENT.regNo,
        department: app.department || SAMPLE_STUDENT.department,
        year: app.year || `${SAMPLE_STUDENT.year} (${SAMPLE_STUDENT.section})`,
        attendance: app.attendance || SAMPLE_STUDENT.attendance,
        facultyRemarks: app.facultyRemarks || '',
        hodRemarks: app.hodRemarks || '',
        ...app,
        status,
      };
    });

    return normalized;
  } catch (e) {
    console.error('Failed to load applications from localStorage', e);
    return INITIAL_APPLICATIONS;
  }
}

export function saveNewApplication(application) {
  if (typeof window === 'undefined') return application;
  try {
    const current = getStoredApplications();
    const newEntry = {
      id: `APP-${Math.floor(1000 + Math.random() * 9000)}`,
      studentName: SAMPLE_STUDENT.name,
      regNo: SAMPLE_STUDENT.regNo,
      department: SAMPLE_STUDENT.department,
      year: `${SAMPLE_STUDENT.year} (${SAMPLE_STUDENT.section})`,
      attendance: SAMPLE_STUDENT.attendance,
      status: 'Pending Faculty Review', // Strict Day 3 initial status
      submittedAt: new Date().toISOString().split('T')[0],
      facultyRemarks: '',
      hodRemarks: '',
      ...application,
    };
    const updated = [newEntry, ...current];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    return newEntry;
  } catch (e) {
    console.error('Failed to save application to localStorage', e);
    return null;
  }
}

export function updateApplicationStatus(id, newStatus, remarks = '', role = 'faculty') {
  if (typeof window === 'undefined') return null;
  try {
    const current = getStoredApplications();
    const updated = current.map((app) => {
      if (app.id !== id) return app;
      const updatedApp = { ...app, status: newStatus };
      if (role === 'faculty') {
        updatedApp.facultyRemarks = remarks || updatedApp.facultyRemarks;
        updatedApp.facultyReviewedAt = new Date().toISOString().split('T')[0];
      } else if (role === 'hod') {
        updatedApp.hodRemarks = remarks || updatedApp.hodRemarks;
        updatedApp.hodReviewedAt = new Date().toISOString().split('T')[0];
      }
      return updatedApp;
    });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    return updated.find((a) => a.id === id);
  } catch (e) {
    console.error('Failed to update application status in localStorage', e);
    return null;
  }
}
