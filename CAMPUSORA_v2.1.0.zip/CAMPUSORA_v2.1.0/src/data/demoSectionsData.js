/**
 * High-fidelity Fallback Data for First-Year CSE Sections (240 Students).
 * Used when running in Demo Simulation mode or when the PostgreSQL backend
 * is accessed offline/unauthenticated.
 */

const FIRST_NAMES = [
  "Aarav", "Rohan", "Priya", "Ananya", "Aditya", "Sneha", "Rahul", "Neha",
  "Varun", "Pooja", "Vikram", "Divya", "Siddharth", "Kavya", "Arjun", "Tanvi",
  "Karthik", "Riya", "Sanjay", "Meera", "Nikhil", "Ishaan", "Shreya", "Amit",
  "Deepa", "Harish", "Swati", "Manish", "Bhavna", "Alok", "Tara", "Yash",
  "Rashi", "Pranav", "Nidhi", "Gaurav", "Isha", "Vishal", "Simran", "Akash",
  "Kriti", "Tarun", "Payal", "Kunal", "Radhika", "Mayank", "Ayesha", "Chetan",
  "Diya", "Sameer", "Rekha", "Vivek", "Komal", "Mohit", "Preeti", "Deepak",
  "Rupal", "Harsh", "Sunita", "Dev"
];

const LAST_NAMES = [
  "Sharma", "Verma", "Mehra", "Iyer", "Nair", "Patel", "Joshi", "Reddy",
  "Singh", "Gupta", "Rao", "Kulkarni", "Sen", "Roy", "Das", "Chatterjee",
  "Banerjee", "Pillai", "Menon", "Bhatt", "Desai", "Choudhury", "Agarwal", "Tiwari",
  "Pandey", "Mishra", "Saxena", "Kapoor", "Malhotra", "Bhatia"
];

// Generate all 240 students in memory
function generateAllDemoStudents() {
  const sections = ['A', 'B', 'C', 'D'];
  const allStudents = [];

  sections.forEach((secLetter, sIdx) => {
    const secLabel = `CSE-${secLetter}`;
    for (let i = 1; i <= 60; i++) {
      const globalIdx = sIdx * 60 + i;
      const regNo = `2026CSE${String(globalIdx).padStart(3, '0')}`;
      const firstName = FIRST_NAMES[(i - 1) % FIRST_NAMES.length];
      const lastName = LAST_NAMES[(globalIdx - 1) % LAST_NAMES.length];
      const name = `${firstName} ${lastName}`;
      const username = `cses_${secLetter.toLowerCase()}_${String(i).padStart(2, '0')}`;

      const isHosteler = (i % 5 !== 0) && (i % 5 !== 2);
      const hostelBlock = isHosteler ? (i % 2 === 0 ? 'GH-1' : (i % 4 === 1 ? 'BH-1' : 'BH-2')) : '';
      const roomNo = isHosteler ? `${hostelBlock}, Room ${100 + (i % 40) + 1}` : 'Day Scholar';
      const studentType = isHosteler ? `Hosteler (${hostelBlock})` : 'Day Scholar';

      // Realistic leave distributions
      const hasLeaves = (i % 2 === 1) || (i % 3 === 0);
      const totalApps = hasLeaves ? (i % 7 === 0 ? 3 : (i % 4 === 0 ? 2 : 1)) : 0;
      const approvedApps = totalApps > 0 ? (i % 5 === 0 ? totalApps - 1 : totalApps) : 0;
      const pendingApps = totalApps > approvedApps ? 1 : 0;
      const rejectedApps = Math.max(0, totalApps - approvedApps - pendingApps);
      const approvedDays = approvedApps * (i % 3 === 0 ? 3 : 2);

      allStudents.push({
        id: 1000 + globalIdx,
        global_idx: globalIdx,
        student_idx: i,
        name,
        username,
        registration_number: regNo,
        department: 'Computer Science & Engineering',
        year: 1,
        section: secLabel,
        section_code: secLetter,
        year_and_section: `Year 1 • ${secLabel}`,
        student_type: studentType,
        is_hosteler: isHosteler,
        hostel_block: hostelBlock,
        room_number: roomNo,
        phone_number: `+91 98000 ${String(globalIdx).padStart(5, '0')}`,
        email: `${firstName.toLowerCase()}.${lastName.toLowerCase()}${globalIdx}@campusora.edu`,
        parent_name: `${firstName}'s Parent`,
        parent_phone: `+91 98111 ${String(globalIdx).padStart(5, '0')}`,
        emergency_contact: `+91 98222 ${String(globalIdx).padStart(5, '0')}`,
        total_applications: totalApps,
        approved_applications: approvedApps,
        approved_leave_days: approvedDays,
        pending_applications: pendingApps,
        rejected_applications: rejectedApps,
      });
    }
  });

  return allStudents;
}

export const ALL_DEMO_STUDENTS = generateAllDemoStudents();

export function getFallbackDepartmentSections() {
  const sections = ['CSE-A', 'CSE-B', 'CSE-C', 'CSE-D'];
  const summary = sections.map((sec) => {
    const list = ALL_DEMO_STUDENTS.filter((s) => s.section === sec);
    const totalApps = list.reduce((acc, s) => acc + s.total_applications, 0);
    const pendingApps = list.reduce((acc, s) => acc + s.pending_applications, 0);
    const approvedApps = list.reduce((acc, s) => acc + s.approved_applications, 0);
    const rejectedApps = list.reduce((acc, s) => acc + s.rejected_applications, 0);
    return {
      section: sec,
      section_code: sec.replace('CSE-', ''),
      year: 1,
      total_students: list.length, // exactly 60
      total_applications: totalApps,
      pending_applications: pendingApps,
      approved_applications: approvedApps,
      rejected_applications: rejectedApps,
    };
  });

  return {
    department: 'Computer Science & Engineering',
    year: 1,
    total_students: ALL_DEMO_STUDENTS.length, // 240
    total_applications: summary.reduce((acc, s) => acc + s.total_applications, 0),
    total_pending: summary.reduce((acc, s) => acc + s.pending_applications, 0),
    total_approved: summary.reduce((acc, s) => acc + s.approved_applications, 0),
    total_rejected: summary.reduce((acc, s) => acc + s.rejected_applications, 0),
    sections: summary,
  };
}

export function getFallbackSectionStudents({
  section = 'CSE-C',
  search = '',
  ordering = 'reg_no',
  page = 1,
  pageSize = 60,
}) {
  let list = [...ALL_DEMO_STUDENTS];

  // Section filter
  const cleanSec = (section || 'CSE-C').toUpperCase().replace('CSE-', '');
  if (cleanSec !== 'ALL') {
    list = list.filter((s) => s.section_code === cleanSec || s.section === `CSE-${cleanSec}`);
  }

  // Search filter
  if (search && search.trim()) {
    const q = search.trim().toLowerCase();
    list = list.filter((s) =>
      s.name.toLowerCase().includes(q) ||
      s.registration_number.toLowerCase().includes(q) ||
      s.username.toLowerCase().includes(q)
    );
  }

  // Sorting
  const order = ordering.toLowerCase();
  if (order === 'name') list.sort((a, b) => a.name.localeCompare(b.name));
  else if (order === '-name') list.sort((a, b) => b.name.localeCompare(a.name));
  else if (order === 'reg_no') list.sort((a, b) => a.registration_number.localeCompare(b.registration_number));
  else if (order === '-reg_no') list.sort((a, b) => b.registration_number.localeCompare(a.registration_number));
  else if (order.includes('total_leaves')) list.sort((a, b) => order.startsWith('-') ? b.total_applications - a.total_applications : a.total_applications - b.total_applications);
  else if (order.includes('approved_days')) list.sort((a, b) => order.startsWith('-') ? b.approved_leave_days - a.approved_leave_days : a.approved_leave_days - b.approved_leave_days);
  else if (order.includes('pending')) list.sort((a, b) => order.startsWith('-') ? b.pending_applications - a.pending_applications : a.pending_applications - b.pending_applications);

  // Pagination
  const totalCount = list.length;
  const totalPages = Math.max(1, Math.ceil(totalCount / pageSize));
  const currentPage = Math.max(1, Math.min(page, totalPages));
  const start = (currentPage - 1) * pageSize;
  const pagedResults = list.slice(start, start + pageSize);

  return {
    count: totalCount,
    total_pages: totalPages,
    current_page: currentPage,
    page_size: pageSize,
    results: pagedResults,
  };
}

export function getFallbackStudentProfile(studentId) {
  const student = ALL_DEMO_STUDENTS.find((s) => s.id === Number(studentId) || s.registration_number === String(studentId)) || ALL_DEMO_STUDENTS[0];

  const hasLeaves = student.total_applications > 0;
  const sampleHistories = hasLeaves
    ? [
        {
          id: student.id * 10 + 1,
          application_id: `APP-26${student.section_code}-${String(student.student_idx).padStart(3, '0')}`,
          submission_date: '2026-11-18',
          leave_type: student.student_idx % 2 === 0 ? 'Regular Leave' : 'On-Duty',
          start_date: '2026-11-20',
          end_date: '2026-11-22',
          requested_duration: 3,
          duration_days: 3,
          reason: student.student_idx % 2 === 0 ? 'Fever and viral infection; physician prescribed rest.' : 'Inter-college Hackathon competition presentation.',
          status: student.approved_applications > 0 ? 'HOD Approved' : 'Pending HOD Review',
          rejection_reason: '',
          faculty_recommendation: {
            decision: 'forwarded_to_hod',
            decision_display: 'Recommended to HOD',
            remarks: 'Attendance above departmental minimum. Recommended.',
            reviewer_name: 'Dr. Anita Verma (Class Advisor)',
            timestamp: '2026-11-18T10:30:00Z',
          },
          hod_decision: student.approved_applications > 0 ? {
            decision: 'hod_approved',
            decision_display: 'HOD Approved',
            remarks: 'Sanctioned. Automated Gate Pass generated.',
            reviewer_name: 'Prof. Rajesh Mehra (HOD)',
            timestamp: '2026-11-18T14:15:00Z',
          } : null,
        }
      ]
    : [];

  return {
    student_information: {
      id: student.id,
      name: student.name,
      username: student.username,
      register_number: student.registration_number,
      department: student.department,
      year: student.year,
      section: student.section,
      student_type: student.student_type,
      is_hosteler: student.is_hosteler,
      hostel_block: student.hostel_block,
      room_number: student.room_number,
      email: student.email,
      phone_number: student.phone_number,
      emergency_contact: student.emergency_contact,
      parent_name: student.parent_name,
      parent_phone: student.parent_phone,
      parent_email: `parent.${student.username}@example.com`,
      advisor_name: 'Dr. Anita Verma (Class Advisor)',
      photo_url: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=256&h=256',
    },
    leave_statistics: {
      total_applications: student.total_applications,
      approved_applications: student.approved_applications,
      rejected_applications: student.rejected_applications,
      pending_applications: student.pending_applications,
      total_approved_leave_days: student.approved_leave_days,
      all_inclusive_approved_days: student.approved_leave_days,
      medical_leave_count: student.student_idx % 2 === 0 ? 1 : 0,
      personal_leave_count: 0,
      regular_leave_count: student.student_idx % 2 === 0 ? 1 : 0,
      regular_leave_days: student.student_idx % 2 === 0 ? student.approved_leave_days : 0,
      od_count: student.student_idx % 2 === 1 ? 1 : 0,
      od_days: student.student_idx % 2 === 1 ? student.approved_leave_days : 0,
      hostel_leave_count: 0,
      hostel_leave_days: 0,
      day_pass_count: 0,
    },
    leave_history: sampleHistories,
  };
}
