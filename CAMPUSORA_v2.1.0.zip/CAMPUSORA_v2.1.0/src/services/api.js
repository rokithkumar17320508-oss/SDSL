/**
 * CAMPUSORA Backend API Service.
 * Handles communication with Django REST Framework endpoints.
 * Uses both HttpOnly cookies and in-memory Authorization headers for robust session handling.
 */

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || '/api/v1';

class ApiService {
  constructor() {
    this.baseUrl = API_BASE_URL;
    this.accessToken = null;
  }

  setAccessToken(token) {
    this.accessToken = token;
  }

  getAccessToken() {
    return this.accessToken;
  }

  async request(endpoint, options = {}) {
    const url = `${this.baseUrl}${endpoint}`;
    const headers = {
      'Content-Type': 'application/json',
      ...options.headers,
    };

    if (this.accessToken && !headers['Authorization']) {
      headers['Authorization'] = `Bearer ${this.accessToken}`;
    }

    const config = {
      ...options,
      headers,
      credentials: 'include', // Transmits HttpOnly cookies seamlessly
    };

    try {
      const response = await fetch(url, config);

      // Handle session expiration
      if (response.status === 401 && !endpoint.includes('/auth/login/') && !endpoint.includes('/auth/refresh/')) {
        const refreshed = await this.refreshToken();
        if (refreshed) {
          // Retry with newly acquired access token
          headers['Authorization'] = `Bearer ${this.accessToken}`;
          return this.request(endpoint, { ...options, headers });
        }
      }

      const data = await response.json().catch(() => ({}));
      return {
        ok: response.ok,
        status: response.status,
        data,
      };
    } catch (error) {
      return {
        ok: false,
        status: 0,
        error: error.message || 'Network connection error',
      };
    }
  }

  // Authentication endpoints
  async login(username, password) {
    const res = await this.request('/auth/login/', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    });

    if (res.ok && res.data?.access) {
      this.setAccessToken(res.data.access);
    }
    return res;
  }

  async logout() {
    const res = await this.request('/auth/logout/', {
      method: 'POST',
    });
    this.setAccessToken(null);
    return res;
  }

  async getMe() {
    const res = await this.request('/auth/me/', {
      method: 'GET',
    });
    return res;
  }

  async refreshToken() {
    try {
      const res = await fetch(`${this.baseUrl}/auth/refresh/`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
      });
      if (res.ok) {
        const data = await res.json().catch(() => ({}));
        if (data.access) {
          this.setAccessToken(data.access);
          return true;
        }
      }
      this.setAccessToken(null);
      return false;
    } catch {
      this.setAccessToken(null);
      return false;
    }
  }

  // System & Leave endpoints
  async getHealth() {
    return this.request('/health/', { method: 'GET' });
  }

  async getLeaveTypes() {
    return this.request('/leave-types/', { method: 'GET' });
  }

  async getApplications() {
    return this.request('/applications/', { method: 'GET' });
  }

  async getApplication(id) {
    return this.request(`/applications/${id}/`, { method: 'GET' });
  }

  async createApplication(payload) {
    return this.request('/applications/', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  }

  async forwardApplication(id, remarks = '') {
    return this.request(`/applications/${id}/forward/`, {
      method: 'POST',
      body: JSON.stringify({ remarks }),
    });
  }

  async approveApplication(id, remarks = '') {
    return this.request(`/applications/${id}/approve/`, {
      method: 'POST',
      body: JSON.stringify({ remarks }),
    });
  }

  async rejectApplication(id, remarks = '') {
    return this.request(`/applications/${id}/reject/`, {
      method: 'POST',
      body: JSON.stringify({ remarks }),
    });
  }

  // Gate Pass & Security Endpoints
  async getActiveGatePass() {
    return this.request('/gate-passes/active/', { method: 'GET' });
  }

  async generateGatePass(application_id) {
    return this.request('/gate-passes/generate/', {
      method: 'POST',
      body: JSON.stringify({ application_id }),
    });
  }

  async getGatePasses() {
    return this.request('/gate-passes/', { method: 'GET' });
  }

  async verifyGatePass(tokenOrQrData) {
    return this.request('/gate-passes/verify/', {
      method: 'POST',
      body: JSON.stringify({ token: tokenOrQrData }),
    });
  }

  async confirmGateExit(token, remarks = '') {
    return this.request('/gate-passes/confirm-exit/', {
      method: 'POST',
      body: JSON.stringify({ token, remarks }),
    });
  }

  async denyGateExit(token, reason) {
    return this.request('/gate-passes/deny-exit/', {
      method: 'POST',
      body: JSON.stringify({ token, reason }),
    });
  }

  async getGateEvents() {
    return this.request('/gate-events/', { method: 'GET' });
  }

  // Day 9: Return Entry & Overdue Endpoints
  async verifyGatePassReturn(tokenOrQrData) {
    return this.request('/gate-passes/verify-return/', {
      method: 'POST',
      body: JSON.stringify({ token: tokenOrQrData }),
    });
  }

  async confirmGateReturn(token, remarks = '') {
    return this.request('/gate-passes/confirm-return/', {
      method: 'POST',
      body: JSON.stringify({ token, remarks }),
    });
  }

  async getActiveOutsideStudents(params = {}) {
    const searchParams = new URLSearchParams(params).toString();
    const endpoint = `/gate-passes/outside/${searchParams ? `?${searchParams}` : ''}`;
    return this.request(endpoint, { method: 'GET' });
  }

  // Day 9: Analytics Endpoints
  async getAnalyticsOverview() {
    return this.request('/analytics/overview/', { method: 'GET' });
  }

  // Notifications Endpoints
  async getNotifications(params = {}) {
    const searchParams = new URLSearchParams(params).toString();
    const endpoint = `/notifications/${searchParams ? `?${searchParams}` : ''}`;
    return this.request(endpoint, { method: 'GET' });
  }

  async getNotificationSummary() {
    return this.request('/notifications/summary/', { method: 'GET' });
  }

  // Day 11 / v2.1.0: HOD Department Sections & Student Directory
  async getDepartmentSections(params = {}) {
    const searchParams = new URLSearchParams(params).toString();
    const endpoint = `/analytics/sections/${searchParams ? `?${searchParams}` : ''}`;
    return this.request(endpoint, { method: 'GET' });
  }

  async getDepartmentStudents(params = {}) {
    const searchParams = new URLSearchParams(params).toString();
    const endpoint = `/analytics/students/${searchParams ? `?${searchParams}` : ''}`;
    return this.request(endpoint, { method: 'GET' });
  }

  async getStudentLeaveProfile(studentId) {
    return this.request(`/analytics/students/${studentId}/`, { method: 'GET' });
  }
}

export const api = new ApiService();
export default api;
