/**
 * Central Branding & Application Configuration for CAMPUSORA
 * Edit here to update brand names, taglines, color tokens, and role definitions across the app.
 */

export const BRAND = {
  name: 'CAMPUSORA',
  tagline: 'Smarter Campus. Simpler Life.',
  headline: 'Your Campus. Simplified.',
  description: 'Manage leave requests, approvals, and digital gate passes in one place.',
  version: '2.0.0',
  colors: {
    white: '#FFFFFF',
    softGray: '#F8FAFC',
    royalBlue: '#2563EB',
    darkText: '#1E293B',
    mutedGold: '#EAB308',
  },
  roles: [
    {
      id: 'student',
      title: 'Student',
      description: 'Apply for leaves, view live approval status, and access digital gate passes.',
      badge: 'Student Portal',
      fieldLabel: 'Roll Number / Registration Number',
      fieldPlaceholder: 'e.g. 21CS084 or 717621104084',
      demoUser: '21CS084',
      demoPass: 'Student@123',
    },
    {
      id: 'faculty',
      title: 'Faculty',
      description: 'Review student attendance, verify parent consent, and endorse leave applications.',
      badge: 'Faculty Portal',
      fieldLabel: 'Staff ID / Employee Code',
      fieldPlaceholder: 'e.g. FAC-CSE-402',
      demoUser: 'FAC-CSE-402',
      demoPass: 'Mentor@2026',
    },
    {
      id: 'hod',
      title: 'HOD',
      description: 'Final department approval, outpass authorization, and academic oversight.',
      badge: 'HOD Portal',
      fieldLabel: 'Department Head ID',
      fieldPlaceholder: 'e.g. HOD-CSE-01',
      demoUser: 'HOD-CSE-01',
      demoPass: 'HodExecutive#9',
    },
    {
      id: 'security',
      title: 'Security',
      description: 'Scan and verify digital gate passes with real-time exit and entry logging.',
      badge: 'Security Gate',
      fieldLabel: 'Officer Badge ID / Post Code',
      fieldPlaceholder: 'e.g. SEC-GATE-01',
      demoUser: 'SEC-GATE-01',
      demoPass: 'SecurityPass#2026',
    },
  ],
};
