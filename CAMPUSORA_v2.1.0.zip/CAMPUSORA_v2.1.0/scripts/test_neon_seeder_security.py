#!/usr/bin/env python3
"""
Comprehensive Security and Reliability Test Suite for:
  - scripts/validate_neon_url.py
  - scripts/seed_remote_neon.sh

Tests cover:
  1. Bash syntax validation (bash -n)
  2. URL parsing with special characters in passwords
  3. Invalid and spoofed Neon hostnames
  4. Localhost, loopback, and private IP rejection
  5. Local database (campusora_db) and non-neondb rejection
  6. TLS / sslmode requirement and validation
  7. End-to-end execution of scripts/seed_remote_neon.sh ensuring migration commands are unreachable for invalid targets
  8. Confirmation prompt reliability
"""

import os
import sys
import subprocess
from pathlib import Path

# Add scripts directory to path to import validator
PROJECT_ROOT = Path(__file__).resolve().parent.parent
SCRIPTS_DIR = PROJECT_ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS_DIR))

from validate_neon_url import validate_and_normalize_neon_url


def test_bash_syntax():
    print("--- [Test 1] Bash Syntax Verification (bash -n) ---")
    script_path = SCRIPTS_DIR / "seed_remote_neon.sh"
    res = subprocess.run(["bash", "-n", str(script_path)], capture_output=True, text=True)
    assert res.returncode == 0, f"Bash syntax check failed: {res.stderr}"
    print("PASS: scripts/seed_remote_neon.sh syntax is valid.")


def test_special_characters_in_passwords():
    print("\n--- [Test 2] Passwords with Special Characters ---")
    special_passwords = [
        "P@ssw0rd!#$%",
        "p'\"$$\\test`quoted",
        "p%40ssw%24rd",
        "complex&p=1?foo#bar",
        "pass with spaces",
        "pa$$w0rd;rm -rf %2F",
    ]
    for pwd in special_passwords:
        url = f"postgresql://neon_user:{pwd}@ep-cool-fog-123.us-east-2.aws.neon.tech/neondb?sslmode=require"
        # Test directly via validator
        res = validate_and_normalize_neon_url(url)
        assert res["hostname"] == "ep-cool-fog-123.us-east-2.aws.neon.tech"
        assert res["database"] == "neondb"
        assert res["username"] == "neon_user"
        assert res["has_password"] is True
        print(f"PASS: Parsed password safely: '{pwd[:12]}...' without script error.")


def test_spoofed_and_invalid_hostnames():
    print("\n--- [Test 3] Spoofed and Invalid Hostnames ---")
    invalid_hosts = [
        ("postgresql://u:p@ep-cool.neon.tech.attacker.com/neondb?sslmode=require", "Spoofed domain suffix attacker.com"),
        ("postgresql://u:p@fake-neon.tech/neondb?sslmode=require", "Fake domain fake-neon.tech"),
        ("postgresql://u:p@attacker-neon.tech/neondb?sslmode=require", "Attacker prefix attacker-neon.tech"),
        ("postgresql://u:p@neon.tech/neondb?sslmode=require", "Bare domain neon.tech without compute subdomain"),
        ("postgresql://u:p@.neon.tech/neondb?sslmode=require", "Leading dot invalid subdomain"),
        ("postgresql://u:p@ep-cool_123.neon.tech/neondb?sslmode=require", "Invalid character in subdomain"),
        ("postgresql://u:p@aws.neon.tech.org/neondb?sslmode=require", "Different TLD .org"),
        ("postgresql://u:p@attacker.com/neondb?sslmode=require&fake=neon.tech", "neon.tech in query parameter only"),
    ]
    for url, label in invalid_hosts:
        try:
            validate_and_normalize_neon_url(url)
            assert False, f"Expected failure for {label}, but validation succeeded!"
        except ValueError as err:
            assert "SECURITY REJECTION" in str(err) or "Invalid" in str(err)
            print(f"PASS: Rejected '{label}': {err}")


def test_localhost_and_ip_rejection():
    print("\n--- [Test 4] Localhost, Loopback, and IP Addresses ---")
    forbidden_endpoints = [
        ("postgresql://u:p@localhost:5433/neondb?sslmode=require", "localhost"),
        ("postgresql://u:p@127.0.0.1:5433/neondb?sslmode=require", "127.0.0.1"),
        ("postgresql://u:p@0.0.0.0:5432/neondb?sslmode=require", "0.0.0.0"),
        ("postgresql://u:p@[::1]:5432/neondb?sslmode=require", "IPv6 ::1"),
        ("postgresql://u:p@10.103.246.178:5432/neondb?sslmode=require", "LAN Private IP 10.x"),
        ("postgresql://u:p@192.168.1.100:5432/neondb?sslmode=require", "Private IP 192.168.x"),
        ("postgresql://u:p@172.16.0.50:5432/neondb?sslmode=require", "Private IP 172.16.x"),
        ("postgresql://u:p@93.184.216.34:5432/neondb?sslmode=require", "Raw Public IP"),
    ]
    for url, label in forbidden_endpoints:
        try:
            validate_and_normalize_neon_url(url)
            assert False, f"Expected failure for {label}, but validation succeeded!"
        except ValueError as err:
            assert "SECURITY REJECTION" in str(err)
            print(f"PASS: Properly rejected {label}: {err}")


def test_database_name_guards():
    print("\n--- [Test 5] Local Database & Database Name Safeguards ---")
    invalid_dbs = [
        ("postgresql://u:p@ep-cool-123.neon.tech/campusora_db?sslmode=require", "Original local DB campusora_db in path"),
        ("postgresql://campusora_db:p@ep-cool-123.neon.tech/neondb?sslmode=require", "campusora_db in username"),
        ("postgresql://u:p@ep-cool-123.neon.tech/production_db?sslmode=require", "Unexpected database production_db"),
        ("postgresql://u:p@ep-cool-123.neon.tech/?sslmode=require", "Missing database name"),
    ]
    for url, label in invalid_dbs:
        try:
            validate_and_normalize_neon_url(url)
            assert False, f"Expected failure for {label}, but validation succeeded!"
        except ValueError as err:
            print(f"PASS: Rejected '{label}': {err}")


def test_tls_and_sslmode_enforcement():
    print("\n--- [Test 6] TLS / SSL Enforcement ---")
    # Insecure modes must be rejected
    insecure_modes = ["disable", "allow", "prefer"]
    for mode in insecure_modes:
        url = f"postgresql://u:p@ep-cool-123.neon.tech/neondb?sslmode={mode}"
        try:
            validate_and_normalize_neon_url(url)
            assert False, f"Expected failure for insecure sslmode={mode}, but validation succeeded!"
        except ValueError as err:
            print(f"PASS: Rejected insecure sslmode='{mode}': {err}")

    # Valid modes must succeed
    valid_modes = ["require", "verify-ca", "verify-full"]
    for mode in valid_modes:
        url = f"postgresql://u:p@ep-cool-123.neon.tech/neondb?sslmode={mode}"
        res = validate_and_normalize_neon_url(url)
        assert res["sslmode"] == mode
        print(f"PASS: Accepted TLS sslmode='{mode}'.")

    # Missing sslmode must auto-append require
    url_no_ssl = "postgresql://u:p@ep-cool-123.neon.tech/neondb"
    res = validate_and_normalize_neon_url(url_no_ssl)
    assert res["sslmode"] == "require"
    assert "sslmode=require" in res["normalized_url"]
    print("PASS: Missing sslmode automatically normalized to 'sslmode=require'.")


def test_shell_script_unreachable_migrations_on_invalid_target():
    print("\n--- [Test 7] Verify Invalid Targets Cannot Reach Migrations in seed_remote_neon.sh ---")
    script_path = SCRIPTS_DIR / "seed_remote_neon.sh"

    # Test cases where script MUST exit with non-zero before migrations
    failing_cases = [
        ("postgresql://u:p@localhost:5433/campusora_db", "Local database target"),
        ("postgresql://u:p@attacker.com/neondb?sslmode=require", "Non-neon hostname"),
        ("postgresql://u:p@ep-cool.neon.tech.attacker.com/neondb?sslmode=require", "Spoofed neon hostname"),
        ("postgresql://u:p@ep-cool-123.neon.tech/other_database?sslmode=require", "Non-neondb database"),
        ("postgresql://u:p@ep-cool-123.neon.tech/neondb?sslmode=disable", "Insecure sslmode"),
    ]

    for test_url, label in failing_cases:
        env = os.environ.copy()
        env["TARGET_DATABASE_URL"] = test_url
        res = subprocess.run(
            ["bash", str(script_path)],
            env=env,
            capture_output=True,
            text=True
        )
        assert res.returncode != 0, f"Script unexpectedly succeeded for {label}!"
        # Verify migration commands were NEVER executed
        assert "Applying Django database migrations" not in res.stdout
        assert "Applying Django database migrations" not in res.stderr
        assert "[SECURITY CHECK FAILED]" in res.stderr or "SECURITY REJECTION" in res.stderr
        print(f"PASS: seed_remote_neon.sh halted early for '{label}'. Migrations unreachable.")


def test_shell_script_confirmation_abort():
    print("\n--- [Test 8] Confirmation Prompt Reliability ---")
    script_path = SCRIPTS_DIR / "seed_remote_neon.sh"
    valid_dummy_url = "postgresql://dummy_user:dummy_pass@ep-cool-fog-123456.us-east-2.aws.neon.tech/neondb?sslmode=require"

    abort_inputs = ["no", "yes", "CONFIRM_NOT", "abort", "", "  abort  "]
    for abort_input in abort_inputs:
        env = os.environ.copy()
        env["TARGET_DATABASE_URL"] = valid_dummy_url
        res = subprocess.run(
            ["bash", str(script_path)],
            input=f"{abort_input}\n",
            env=env,
            capture_output=True,
            text=True
        )
        assert res.returncode == 0
        assert "Provisioning aborted. No changes were made to any database." in res.stdout
        assert "Applying Django database migrations" not in res.stdout
        print(f"PASS: Input '{abort_input}' safely aborted without executing migrations.")


if __name__ == "__main__":
    test_bash_syntax()
    test_special_characters_in_passwords()
    test_spoofed_and_invalid_hostnames()
    test_localhost_and_ip_rejection()
    test_database_name_guards()
    test_tls_and_sslmode_enforcement()
    test_shell_script_unreachable_migrations_on_invalid_target()
    test_shell_script_confirmation_abort()
    print("\n==================================================================")
    print("  ALL SECURITY AND RELIABILITY TESTS PASSED SUCCESSFULLY (8/8)!")
    print("==================================================================")
