#!/usr/bin/env python3
"""
CAMPUSORA — Neon Database URL Validator & Normalizer
Safely parses and validates remote Neon PostgreSQL connection strings.
Ensures strict host verification, TLS enforcement, and protection against
accidental targeting of local or production databases.
"""

import sys
import os
import ipaddress
from urllib.parse import parse_qs, urlencode


def parse_pg_url(raw_url: str) -> dict:
    """
    Safely parses a PostgreSQL URL without shell interpolation.
    Handles special characters in passwords (including quotes, $, &, #, etc.)
    and correctly splits userinfo from hostport using the last '@' delimiter.
    """
    if "://" not in raw_url:
        raise ValueError("Invalid connection string: missing '://' scheme delimiter.")

    scheme, rest = raw_url.split("://", 1)
    scheme = scheme.lower().strip()
    if scheme not in ("postgres", "postgresql"):
        raise ValueError(
            f"Invalid connection scheme '{scheme}'. Must be 'postgres' or 'postgresql'."
        )

    # Separate authority from path and query
    if "/" in rest:
        authority, path_query = rest.split("/", 1)
        path_query = "/" + path_query
    elif "?" in rest:
        authority, query = rest.split("?", 1)
        path_query = "/?" + query
    else:
        authority = rest
        path_query = "/"

    # Split authority into userinfo and hostport via LAST '@' delimiter
    if "@" in authority:
        userinfo, hostport = authority.rsplit("@", 1)
        if ":" in userinfo:
            username, password = userinfo.split(":", 1)
        else:
            username, password = userinfo, None
    else:
        userinfo = None
        username, password = None, None
        hostport = authority

    # Split host from port
    # Handle IPv6 brackets if present
    if hostport.startswith("[") and "]" in hostport:
        bracket_end = hostport.find("]")
        hostname = hostport[1:bracket_end]
        after_bracket = hostport[bracket_end + 1:]
        if after_bracket.startswith(":"):
            port_str = after_bracket[1:]
            port = int(port_str) if port_str.isdigit() else 5432
        else:
            port = 5432
    elif ":" in hostport:
        hostname, port_str = hostport.split(":", 1)
        port = int(port_str) if port_str.isdigit() else 5432
    else:
        hostname = hostport
        port = 5432

    # Split path from query
    if "?" in path_query:
        path, query = path_query.split("?", 1)
    else:
        path = path_query
        query = ""

    database = path.lstrip("/").strip()

    return {
        "scheme": scheme,
        "username": username,
        "password": password,
        "hostname": hostname.strip().lower(),
        "port": port,
        "database": database,
        "query": query.strip(),
        "userinfo": userinfo,
        "hostport": hostport,
    }


def validate_and_normalize_neon_url(raw_url: str) -> dict:
    """
    Validates a database URL for remote Neon provisioning.
    
    Enforces:
      - Valid postgres / postgresql scheme
      - Rejection of 'campusora_db' anywhere in connection string
      - Rejection of localhost, loopback, private IPs, or raw IP addresses
      - Strict hostname validation: must end with '.neon.tech' with a valid subdomain
      - Rejection of spoofed hostnames (e.g. attacker-neon.tech, neon.tech.attacker.com)
      - Database name must strictly equal 'neondb'
      - TLS required: sslmode must be 'require', 'verify-ca', or 'verify-full'
        (automatically appends sslmode=require if missing)
      - Safe extraction of credentials without exposure
    """
    cleaned_url = (raw_url or "").strip()
    if not cleaned_url:
        raise ValueError("DATABASE_URL is empty. A valid Neon connection string is required.")

    # 1. Critical Local DB Guard
    if "campusora_db" in cleaned_url.lower():
        raise ValueError(
            "CRITICAL SECURITY REJECTION: Connection string references 'campusora_db'. "
            "Provisioning is strictly prohibited against the local primary database."
        )

    # 2. Safe URL Parsing
    parsed = parse_pg_url(cleaned_url)

    # 3. Hostname Extraction & Safety Checks
    hostname = parsed["hostname"]
    if not hostname:
        raise ValueError("Database connection string is missing a hostname.")

    # Reject localhost / loopback aliases
    if hostname in ("localhost", "127.0.0.1", "0.0.0.0", "::1", "::"):
        raise ValueError(
            f"SECURITY REJECTION: Target host '{hostname}' is a local loopback address. "
            "Remote provisioning must target a remote Neon database."
        )

    # Check if hostname is an IP address (reject loopback, private, and raw IPs)
    try:
        ip = ipaddress.ip_address(hostname)
        if ip.is_loopback or ip.is_private or ip.is_link_local or ip.is_reserved or ip.is_unspecified:
            raise ValueError(
                f"SECURITY REJECTION: Host '{hostname}' is a private or loopback IP address."
            )
        else:
            raise ValueError(
                f"SECURITY REJECTION: Host '{hostname}' is a raw IP address. "
                "Neon endpoints must be accessed via their official *.neon.tech domain name."
            )
    except ValueError as ve:
        if "SECURITY REJECTION" in str(ve):
            raise
        # Expected: hostname is a domain name, not an IP address

    # 4. Strict Neon Domain Verification (anti-spoofing)
    parts = hostname.split(".")
    # Must have at least 3 parts: <subdomain>...neon.tech, ending strictly in ['neon', 'tech']
    if len(parts) < 3 or parts[-2:] != ["neon", "tech"]:
        raise ValueError(
            f"SECURITY REJECTION: Host '{hostname}' does not match official Neon domain (*.neon.tech). "
            "Only authenticated Neon serverless databases are permitted for demonstration provisioning."
        )

    # Validate each domain label
    for part in parts:
        if not part or not part.replace("-", "").isalnum():
            raise ValueError(
                f"SECURITY REJECTION: Host '{hostname}' contains invalid domain segment '{part}'."
            )

    # 5. Database Name Verification
    db_name = parsed["database"]
    if not db_name:
        raise ValueError("Database name is missing from the connection string.")
    if db_name.lower() != "neondb":
        raise ValueError(
            f"SECURITY REJECTION: Intended demonstration database must be 'neondb', but got '{db_name}'. "
            "Refusing to target an unexpected database."
        )

    # 6. TLS / SSL Mode Enforcement & Normalization
    query_params = parse_qs(parsed["query"], keep_blank_values=True)
    sslmode_vals = query_params.get("sslmode", [])

    if sslmode_vals:
        sslmode = sslmode_vals[0].lower().strip()
        if sslmode in ("disable", "allow", "prefer"):
            raise ValueError(
                f"SECURITY REJECTION: Insecure sslmode='{sslmode}' is forbidden. "
                "Remote Neon provisioning requires TLS ('require', 'verify-ca', or 'verify-full')."
            )
        if sslmode not in ("require", "verify-ca", "verify-full"):
            raise ValueError(
                f"SECURITY REJECTION: Unsupported sslmode='{sslmode}'. "
                "Must be 'require', 'verify-ca', or 'verify-full'."
            )
    else:
        # Auto-append sslmode=require for strict transport security
        query_params["sslmode"] = ["require"]

    final_sslmode = query_params.get("sslmode", ["require"])[0]
    new_query = urlencode(query_params, doseq=True)

    # Reconstruct normalized URL safely
    userinfo_str = f"{parsed['userinfo']}@" if parsed["userinfo"] else ""
    port_str = f":{parsed['port']}" if parsed["port"] != 5432 else ""
    normalized_url = f"{parsed['scheme']}://{userinfo_str}{hostname}{port_str}/{db_name}?{new_query}"

    return {
        "hostname": hostname,
        "port": parsed["port"],
        "database": db_name,
        "username": parsed["username"] or "(none)",
        "sslmode": final_sslmode,
        "has_password": bool(parsed["password"]),
        "normalized_url": normalized_url,
    }


def main():
    # Retrieve raw connection string safely from environment
    raw_url = os.environ.get("TARGET_DATABASE_URL", "").strip()

    # Allow reading from stdin if requested with --stdin
    if "--stdin" in sys.argv:
        raw_url = sys.stdin.read().strip()

    try:
        result = validate_and_normalize_neon_url(raw_url)
    except ValueError as err:
        sys.stderr.write(f"\n[SECURITY CHECK FAILED]\n{err}\n\n")
        sys.exit(1)

    if "--normalize" in sys.argv:
        # Output only the normalized URL on stdout for variable capture
        sys.stdout.write(result["normalized_url"])
        return

    # Print user-facing security summary table (passwords are strictly protected)
    summary = (
        "\n"
        "==================================================================\n"
        "  Neon Endpoint Security Check: PASSED\n"
        "==================================================================\n"
        f"  Target Host:     {result['hostname']}\n"
        f"  Target Port:     {result['port']}\n"
        f"  Target Database: {result['database']}\n"
        f"  Database User:   {result['username']}\n"
        f"  SSL / TLS Mode:  {result['sslmode']} (Encrypted)\n"
        f"  Password:        [PROTECTED / HIDDEN]\n"
        "==================================================================\n"
    )
    sys.stderr.write(summary)


if __name__ == "__main__":
    main()
