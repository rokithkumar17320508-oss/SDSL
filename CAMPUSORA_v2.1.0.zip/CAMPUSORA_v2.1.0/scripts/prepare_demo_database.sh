#!/usr/bin/env bash
# ==============================================================================
# CAMPUSORA — Demonstration Database Provisioning & Seeding Script
# Prepares a clean, isolated demonstration database populated with synthetic data.
# NEVER touches or exposes records from the primary production database.
# ==============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
BACKEND_DIR="$PROJECT_ROOT/backend"

# Load environment configuration
ENV_FILE="$BACKEND_DIR/.env"
if [[ -f "$ENV_FILE" ]]; then
    # shellcheck disable=SC1090
    export $(grep -v '^#' "$ENV_FILE" | xargs)
fi

DB_USER="${DB_USER:-campusora_user}"
DB_PASSWORD="${DB_PASSWORD:-}"
DB_HOST="${DB_HOST:-127.0.0.1}"
DB_PORT="${DB_PORT:-5433}"
DEMO_DB_NAME="${DEMO_DB_NAME:-campusora_demo_db}"

export PGPASSWORD="$DB_PASSWORD"

echo "=== CAMPUSORA Demonstration Database Provisioner ==="
echo "Target Demo Database: $DEMO_DB_NAME on $DB_HOST:$DB_PORT"

# Check PostgreSQL connectivity
if ! pg_isready -h "$DB_HOST" -p "$DB_PORT" -q; then
    echo "ERROR: PostgreSQL is not reachable at $DB_HOST:$DB_PORT."
    exit 1
fi

# Create demo database if it does not exist
DB_EXISTS=$(psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d postgres -tAc "SELECT 1 FROM pg_database WHERE datname='$DEMO_DB_NAME';")
if [[ "$DB_EXISTS" != "1" ]]; then
    echo "Creating isolated database '$DEMO_DB_NAME'..."
    psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d postgres -c "CREATE DATABASE $DEMO_DB_NAME OWNER $DB_USER;"
else
    echo "Database '$DEMO_DB_NAME' already exists."
fi

# Run migrations and seed synthetic records
echo "Applying migrations to '$DEMO_DB_NAME'..."
cd "$BACKEND_DIR"
source .venv/bin/activate

DB_NAME="$DEMO_DB_NAME" python manage.py migrate --no-input

echo "Seeding synthetic demonstration personas and applications..."
DB_NAME="$DEMO_DB_NAME" python manage.py seed_public_demo

echo "=== Demo Database Provisioning Successfully Completed ==="
