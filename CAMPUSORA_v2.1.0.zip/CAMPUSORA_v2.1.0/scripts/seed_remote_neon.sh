#!/usr/bin/env bash
# ==============================================================================
# CAMPUSORA — Secure Remote Neon Database Provisioning & Seeder Script (v2.1.0)
# Runs migrations and synthetic demo seeding against remote Neon PostgreSQL
# directly from your secure local terminal. Eliminates need for Render Shell.
# Enforces TLS/SSL, host verification, safe credential handling, and confirmation.
# ==============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
BACKEND_DIR="$PROJECT_ROOT/backend"
CREDS_FILE="$PROJECT_ROOT/.demo_credentials.txt"
VALIDATOR_SCRIPT="$SCRIPT_DIR/validate_neon_url.py"

echo "=================================================================="
echo "  CAMPUSORA — Remote Neon Database Provisioner & Seeder (v2.1.0)"
echo "=================================================================="
echo ""

# 1. Acquire target Neon connection string securely
if [[ -z "${TARGET_DATABASE_URL:-}" ]]; then
    echo "Please provide your Neon PostgreSQL connection string."
    echo "(Input will be hidden for security - paste and press Enter)"
    read -r -s -p "Neon DATABASE_URL: " TARGET_DATABASE_URL || true
    echo ""
fi

# Sanitize any carriage returns or stray whitespace from input
TARGET_DATABASE_URL="$(printf '%s' "$TARGET_DATABASE_URL" | tr -d '\r\n' | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"

if [[ -z "$TARGET_DATABASE_URL" ]]; then
    echo "ERROR: DATABASE_URL cannot be empty." >&2
    exit 1
fi

# Export securely for validator child processes (never embedded in code strings)
export TARGET_DATABASE_URL

# 2. Strict Security Validation via Python (Safe environment variable parsing)
# Hostname must end with .neon.tech with valid subdomain; neondb database only; TLS required.
if [[ ! -f "$VALIDATOR_SCRIPT" ]]; then
    echo "ERROR: Validator script not found at $VALIDATOR_SCRIPT" >&2
    exit 1
fi

python3 "$VALIDATOR_SCRIPT"

# 3. Retrieve normalized URL (auto-appends sslmode=require if omitted)
TARGET_DATABASE_URL="$(python3 "$VALIDATOR_SCRIPT" --normalize)"
export TARGET_DATABASE_URL

# 4. Display Planned Operations
echo "PLANNED OPERATIONS:"
echo "  1. Run Django database migrations against remote Neon database"
echo "  2. Provision core demo personas (Student, Faculty, HOD, Security, Warden)"
echo "  3. Provision 240 First-Year CSE students across 4 sections (CSE-A, B, C, D)"
echo "  4. Seed realistic leave histories, approval records, and gate passes"
echo "  5. Generate cryptographically random passwords and save to .demo_credentials.txt (mode 0600)"
echo ""
echo "NOTICE: Seeding operations are idempotent and will not delete existing records."
echo ""

# 5. Reliable Final Confirmation Prompt
read -r -p "Type 'CONFIRM' to proceed with remote provisioning: " USER_CONFIRM || true

# Clean input of carriage returns and whitespace
USER_CONFIRM="$(printf '%s' "$USER_CONFIRM" | tr -d '\r\n' | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"

if [[ "$USER_CONFIRM" != "CONFIRM" ]]; then
    echo ""
    echo "Provisioning aborted. No changes were made to any database."
    exit 0
fi

# 6. Activate Python Virtual Environment
cd "$BACKEND_DIR"
if [[ -f ".venv/bin/activate" ]]; then
    # shellcheck disable=SC1091
    source .venv/bin/activate
elif [[ -f "../.venv/bin/activate" ]]; then
    # shellcheck disable=SC1091
    source ../.venv/bin/activate
else
    echo "ERROR: Python virtual environment not found in backend/.venv" >&2
    exit 1
fi

# 7. Execute Remote Migrations and Demonstration Seeding
echo ""
echo "[1/3] Applying Django database migrations to remote database..."
DATABASE_URL="$TARGET_DATABASE_URL" python manage.py migrate --no-input

echo "[2/3] Seeding demo personas and 240 First-Year CSE students (idempotent)..."
DATABASE_URL="$TARGET_DATABASE_URL" python manage.py seed_public_demo \
    --generate-passwords \
    --credentials-file="$CREDS_FILE"

echo "[3/3] Verifying database provisioning and securing credentials..."
if [[ -f "$CREDS_FILE" ]]; then
    chmod 0600 "$CREDS_FILE"
fi

DATABASE_URL="$TARGET_DATABASE_URL" python manage.py shell -c "
from accounts.models import User, StudentProfile
from leaves.models import LeaveApplication
users_cnt = User.objects.count()
students_cnt = StudentProfile.objects.filter(year=1, department='Computer Science & Engineering').count()
apps_cnt = LeaveApplication.objects.count()
print(f'Provisioning Verification:')
print(f'  - Total Registered Users: {users_cnt}')
print(f'  - First-Year CSE Students: {students_cnt} (Expected: 240)')
print(f'  - Total Leave Applications: {apps_cnt}')
"

echo "------------------------------------------------------------------"
echo "SUCCESS: Remote Neon database successfully provisioned and verified!"
echo ""
echo "Demonstration account credentials have been securely saved to:"
echo "  $CREDS_FILE (Permissions: 0600 - Owner Read Only)"
echo ""
echo "NOTE: Credentials are NEVER printed in logs or committed to Git."
echo "View credentials on your workstation with: cat .demo_credentials.txt"
echo "------------------------------------------------------------------"
