#!/usr/bin/env bash
# ==============================================================================
# CAMPUSORA — PostgreSQL Database Restore Script
# Safely restores a compressed database dump into target PostgreSQL instance.
# ==============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

if [ $# -lt 1 ]; then
    echo "Usage: $0 <path-to-backup.sql.gz>"
    echo "Example: $0 $PROJECT_ROOT/backups/campusora_db_backup_20261119_133038.sql.gz"
    exit 1
fi

BACKUP_FILE="$1"

if [ ! -f "$BACKUP_FILE" ]; then
    echo "ERROR: Backup file '$BACKUP_FILE' does not exist."
    exit 1
fi

# Source backend/.env if available
if [ -f "$PROJECT_ROOT/backend/.env" ]; then
    export DB_NAME="$(grep -E '^DB_NAME=' "$PROJECT_ROOT/backend/.env" | cut -d '=' -f2- | tr -d '\r')"
    export DB_USER="$(grep -E '^DB_USER=' "$PROJECT_ROOT/backend/.env" | cut -d '=' -f2- | tr -d '\r')"
    export DB_PASSWORD="$(grep -E '^DB_PASSWORD=' "$PROJECT_ROOT/backend/.env" | cut -d '=' -f2- | tr -d '\r')"
    export DB_HOST="$(grep -E '^DB_HOST=' "$PROJECT_ROOT/backend/.env" | cut -d '=' -f2- | tr -d '\r')"
    export DB_PORT="$(grep -E '^DB_PORT=' "$PROJECT_ROOT/backend/.env" | cut -d '=' -f2- | tr -d '\r')"
fi

DB_HOST="${DB_HOST:-127.0.0.1}"
DB_PORT="${DB_PORT:-5433}"
DB_NAME="${DB_NAME:-campusora_db}"
DB_USER="${DB_USER:-campusora_user}"
export PGPASSWORD="${DB_PASSWORD:-}"

echo "=================================================="
echo "CAMPUSORA Database Restore Procedure"
echo "Target DB: ${DB_NAME} on ${DB_HOST}:${DB_PORT}"
echo "Source: ${BACKUP_FILE}"
echo "=================================================="

# Check connectivity
if ! pg_isready -h "$DB_HOST" -p "$DB_PORT" -d "$DB_NAME" -U "$DB_USER" >/dev/null 2>&1; then
    echo "ERROR: PostgreSQL service is not reachable on ${DB_HOST}:${DB_PORT}."
    exit 1
fi

echo "Restoring database schema and data..."
gunzip -c "$BACKUP_FILE" | psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" --quiet

echo "Restore operation successfully completed."
