#!/usr/bin/env bash
# ==============================================================================
# CAMPUSORA — PostgreSQL Database Backup Script
# Creates timestamped compressed backups with schema and data integrity checks.
# ==============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

# Source backend/.env if available
if [ -f "$PROJECT_ROOT/backend/.env" ]; then
    # Export only DB variables to avoid overriding existing environment
    export DB_NAME="$(grep -E '^DB_NAME=' "$PROJECT_ROOT/backend/.env" | cut -d '=' -f2- | tr -d '\r')"
    export DB_USER="$(grep -E '^DB_USER=' "$PROJECT_ROOT/backend/.env" | cut -d '=' -f2- | tr -d '\r')"
    export DB_PASSWORD="$(grep -E '^DB_PASSWORD=' "$PROJECT_ROOT/backend/.env" | cut -d '=' -f2- | tr -d '\r')"
    export DB_HOST="$(grep -E '^DB_HOST=' "$PROJECT_ROOT/backend/.env" | cut -d '=' -f2- | tr -d '\r')"
    export DB_PORT="$(grep -E '^DB_PORT=' "$PROJECT_ROOT/backend/.env" | cut -d '=' -f2- | tr -d '\r')"
fi

BACKUP_DIR="${BACKUP_DIR:-$PROJECT_ROOT/backups}"
mkdir -p "$BACKUP_DIR"

DB_HOST="${DB_HOST:-127.0.0.1}"
DB_PORT="${DB_PORT:-5433}"
DB_NAME="${DB_NAME:-campusora_db}"
DB_USER="${DB_USER:-campusora_user}"
export PGPASSWORD="${DB_PASSWORD:-}"

TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_FILE="${BACKUP_DIR}/${DB_NAME}_backup_${TIMESTAMP}.sql.gz"

echo "=================================================="
echo "CAMPUSORA Database Backup Procedure"
echo "Target DB: ${DB_NAME} on ${DB_HOST}:${DB_PORT}"
echo "Destination: ${BACKUP_FILE}"
echo "=================================================="

# Check PostgreSQL connectivity
if ! pg_isready -h "$DB_HOST" -p "$DB_PORT" -d "$DB_NAME" -U "$DB_USER" >/dev/null 2>&1; then
    echo "ERROR: PostgreSQL service is not reachable on ${DB_HOST}:${DB_PORT}."
    exit 1
fi

# Execute pg_dump and gzip
pg_dump -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" \
    --no-owner \
    --no-privileges \
    --clean \
    --if-exists \
    | gzip -9 > "$BACKUP_FILE"

FILESIZE=$(ls -lh "$BACKUP_FILE" | awk '{print $5}')
echo "Backup successfully created: ${BACKUP_FILE} (${FILESIZE})"
echo "Retention policy: Retaining backups for 30 days."

# Rotate older backups (keep last 30 days)
find "$BACKUP_DIR" -name "${DB_NAME}_backup_*.sql.gz" -mtime +30 -delete || true
echo "Backup rotation completed."
