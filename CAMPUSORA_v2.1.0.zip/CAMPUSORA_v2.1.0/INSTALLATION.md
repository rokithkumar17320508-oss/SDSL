# CAMPUSORA — Local Installation & Setup Guide

This guide describes how to install, configure, and run the CAMPUSORA full-stack application on a local development workstation.

---

## 1. Prerequisites

Ensure your development environment meets the following requirements:
- **Operating System:** Linux (Ubuntu 22.04+ / Debian 12+), macOS (13+), or Windows with WSL2.
- **Python:** Version 3.12, 3.13, or 3.14.
- **Node.js:** Version 18.x, 20.x, or 22.x LTS with `npm` (v9+).
- **PostgreSQL:** Version 16, 17, or 18 (default port `5432` or `5433`).
- **Git:** Version 2.34+.

---

## 2. PostgreSQL Database Setup

Connect to PostgreSQL via `psql` as a superuser (e.g. `postgres`) and execute:

```sql
-- Create database user
CREATE USER campusora_user WITH PASSWORD 'your_secure_db_password_here';

-- Create database
CREATE DATABASE campusora_db OWNER campusora_user;

-- Grant schema privileges
GRANT ALL PRIVILEGES ON DATABASE campusora_db TO campusora_user;
```

---

## 3. Backend Setup

### A. Clone and Environment Setup
```bash
cd backend

# Create Python virtual environment
python3 -m venv .venv
source .venv/bin/activate

# Upgrade pip
pip install --upgrade pip

# Install dependencies
pip install django djangorestframework djangorestframework-simplejwt \
    psycopg pillow argon2-cffi django-cors-headers python-dotenv qrcode
```

### B. Configure Environment Variables
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Ensure `.env` contains:
```ini
SECRET_KEY=your_generated_secret_key_here
DEBUG=True
ALLOWED_HOSTS=localhost,127.0.0.1,0.0.0.0,testserver
CORS_ALLOWED_ORIGINS=http://localhost:5173,http://127.0.0.1:5173

DB_ENGINE=postgresql
DB_NAME=campusora_db
DB_USER=campusora_user
DB_PASSWORD=your_secure_db_password_here
DB_HOST=127.0.0.1
DB_PORT=5433

EMAIL_BACKEND=django.core.mail.backends.console.EmailBackend
SMS_PROVIDER=console
HOSTEL_CURFEW_TIME=21:00
```

### C. Apply Database Migrations
```bash
python manage.py migrate
```

### D. Verify Database and Run Tests
```bash
python manage.py test accounts leaves approvals passes notifications analytics
```
All 75 automated test cases should pass.

### E. Start Backend Development Server
```bash
python manage.py runserver 127.0.0.1:8000
```

---

## 4. Frontend Setup

Open a separate terminal in the project root:

```bash
cd ~/Downloads/PROJECT_IQ

# Install Node dependencies
npm install

# Start Vite development server
npm run dev
```

The frontend will start at: `http://localhost:5173`.

---

## 5. Seed Accounts & Credentials

For development and QA demonstration, the following institutional accounts are provisioned:

| Role | Username | Password | Notes |
|---|---|---|---|
| **Student** | `arjun` | `StudentPassword123!` | Roll No: `2024CSE1084`, Hostel: `BH-2` |
| **Faculty Advisor** | `skverma` | `FacultyPassword123!` | Dept: Computer Science & Engineering |
| **Head of Dept (HOD)** | `rmehra` | `HodPassword123!` | Dept: Computer Science & Engineering |
| **Security Officer** | `security_gate1` | `SecurityPassword123!` | Station: College Main Gate |
| **Security Officer** | `security_hostel1` | `SecurityPassword123!` | Station: Hostel Gate |
| **Hostel Warden** | `warden_bh2` | `WardenPassword123!` | Assigned Block: `BH-2` |
| **Hostel Warden** | `warden_gh1` | `WardenPassword123!` | Assigned Block: `GH-1` |
| **Administrator** | `admin` | `AdminPassword123!` | Superuser / Institutional Oversight |

---

## 6. Verifying the Full Workflow

1. Navigate to `http://localhost:5173/login`.
2. Sign in as **Student** (`arjun`) and submit a leave application at `/student/apply`.
3. Sign in as **Faculty** (`skverma`) at `/faculty/requests` and forward the request to HOD.
4. Sign in as **HOD** (`rmehra`) at `/hod/approvals` and approve the application.
5. Sign in as **Student** (`arjun`) at `/student/gate-pass` to view the cryptographic QR pass.
6. Sign in as **Security** (`security_gate1`) at `/security/scanner` to verify departure exit.
7. Switch security scanner mode to **Return Entry**, verify student likeness, and confirm return.
