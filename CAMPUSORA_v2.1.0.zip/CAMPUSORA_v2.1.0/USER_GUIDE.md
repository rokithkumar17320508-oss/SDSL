# CAMPUSORA — User Guide & Operational Manual
**Smarter Campus. Simpler Life.**

This operational manual provides step-by-step instructions for each institutional user persona in CAMPUSORA.

---

## 1. Student Portal (`/student`)

### 1.1 Applying for Leave / Outpass
1. Sign in to your CAMPUSORA account (`/login`).
2. Navigate to **Apply for Leave** from the sidebar or dashboard.
3. Select the appropriate **Leave Category**:
   - **Regular Leave**: Multi-day personal/family leave.
   - **On-Duty**: Academic competitions, conferences, or sports tournaments.
   - **Day Pass**: Single-day excursion with return required by curfew.
   - **Hostel Outpass**: Residential permission to stay overnight away from campus.
4. Pick start and end dates.
5. Provide a detailed, authentic justification for the leave request.
6. Click **Submit Application**. Your application enters `Pending Faculty Review` status.

### 1.2 Tracking Applications
- Open **My Applications** (`/student/applications`) to view review history, endorsements, remarks, and approval timelines.

### 1.3 Accessing Digital QR Gate Pass
- Once your leave application has received final **HOD Approval**, open **Gate Pass** (`/student/gate-pass`).
- Your pass displays:
  - Official student photograph likeness and enrollment badge.
  - Unique Gate Pass Reference (`GP-XXXX`).
  - Authorized gate location (College Main Gate, Hostel Gate, or Both).
  - Cryptographic QR clearance barcode.
  - Departure window and purpose.
- Present this screen to Security at the designated checkpoint gate.
- Once exit is cleared, your pass status transitions to `Departure Confirmed (Used)`.
- Upon returning to campus, present your pass to Security for Return Entry verification.

---

## 2. Faculty Advisor Portal (`/faculty`)

### 2.1 Reviewing Student Applications
1. Sign in as a Faculty member (`/login`).
2. Open **Pending Requests** (`/faculty/requests`).
3. You will see requests submitted by your designated advisees and department cohort.
4. Click on an application to inspect the student's registration details, leave dates, reason, and prior leave velocity.

### 2.2 Endorsing or Rejecting Requests
- **Forward to HOD**: If the academic standing and justification are satisfactory, enter optional review remarks and click **Forward to HOD**. The request transitions to `Pending HOD Review`.
- **Reject Request**: If the justification is invalid or attendance criteria are not met, enter a mandatory rejection rationale and click **Reject Application**. The student is immediately notified.

---

## 3. Head of Department (HOD) Portal (`/hod`)

### 3.1 Final Approval & Gate Pass Authorization
1. Sign in as HOD (`/login`).
2. Navigate to **Approvals** (`/hod/approvals`).
3. Review applications that have been vetted and endorsed by Faculty advisors.
4. **Approve**: Click **Approve**. This final approval automatically provisions the cryptographic QR gate pass for the student and notifies the student and parents.
5. **Reject**: Click **Reject** and provide a formal institutional reason.

### 3.2 Department Mobility Intelligence
- Navigate to **Department Overview** (`/hod/overview`).
- Review live metrics scoped specifically to your department:
  - Total department applications, approval velocity, and rejection rates.
  - Department students currently off-campus (`USED` status).
  - Department students safely returned (`RETURNED` status).
  - Curfew compliance and overdue alerts.
  - 7-day movement trend graph and leave category breakdown.

---

## 4. Security Checkpoint Portal (`/security`)

### 4.1 Checkpoint Terminal Overview
1. Sign in with your assigned security officer account (`/security`).
2. The terminal displays your assigned station (e.g. *College Main Gate*) and live KPI counters:
   - **Today's Departures**: Total cleared exits.
   - **Today's Return Entries**: Total cleared return arrivals.
   - **Currently Outside**: Total active off-campus students.
   - **Overdue Curfew Alerts**: Active students past return curfew.

### 4.2 Verifying Departure Exits (Outgoing)
1. In the **Scanner & Verification Terminal**, ensure **Departure Exit** mode is selected.
2. Scan the student's QR code using the camera terminal or enter the 43-character token code manually.
3. Click **Verify & Inspect Pass**.
4. The system validates token cryptographic integrity in PostgreSQL.
5. Inspect the verified card:
   - Match the student's physical likeness against the high-resolution photo ID on screen.
   - Confirm authorized gate matches your current station.
   - Confirm departure window validity.
6. Enter optional guard remarks (e.g. luggage checked, vehicle registration).
7. Click **Confirm Exit & Record Departure**.
   - Pass transitions to `USED`.
   - Single-use clearance token is retired.
   - Automated safety alert is dispatched to parents.

### 4.3 Verifying Return Entries (Incoming)
1. Switch the terminal toggle button to **Return Entry** mode.
2. Scan the student's QR code or enter their pass code.
3. Click **Verify Return Entry**.
4. The terminal inspects:
   - Student's prior departure record (`USED` status).
   - Time elapsed since departure.
   - Timeliness against the authorized return curfew (`HOSTEL_CURFEW_TIME`).
   - If the student is overdue, a prominent **red Curfew Violation banner** appears showing exact minutes overdue.
5. Verify the student's physical likeness against the photo likeness.
6. Enter guard return notes.
7. Click **Confirm Return Entry & Close Pass**.
   - Pass transitions to `RETURNED`.
   - Return timestamp is recorded in the permanent audit ledger.
   - Automated return notifications are sent to parents and hostel wardens.
   - Duplicate return attempts are blocked.

### 4.4 Off-Campus & Overdue Registry
- Open **Off-Campus & Overdue** (`/security/outside`).
- View all students currently outside campus in real-time.
- Filter by **Overdue Only** to immediately identify curfew violations.
- View parent emergency phone numbers and room details.
- Use the quick action **Verify Return** button to load a student directly into the return terminal.

### 4.5 Movement History Ledger
- Open **Movement History** (`/security/logs`).
- Chronological, searchable audit trail of all `CAMPUS EXIT` and `RETURN ENTRY` checkpoint operations with officer names and timestamps.

---

## 5. Hostel Warden Persona

- Wardens receive automated, real-time safety dispatches via email whenever a resident of their assigned residential block (e.g. `BH-2`) completes an authorized campus departure or return entry.
- Unrelated wardens (e.g. `GH-1`) never receive alerts for other residential blocks.
