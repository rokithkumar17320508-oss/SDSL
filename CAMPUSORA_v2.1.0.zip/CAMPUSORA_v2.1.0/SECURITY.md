# CAMPUSORA — Security Architecture & Hardening Policy

This document details the security architecture, threat model, cryptographic mechanisms, access control policies, and operational safeguards engineered into the CAMPUSORA campus mobility platform.

---

## 1. Security Principles

CAMPUSORA adheres to four core security design tenets:
1. **Zero-Trust Checkpoint Verification**: Possession of a QR code or student card does not imply access. Every gate clearance requires real-time cryptographic validation against PostgreSQL ledger state and physical likeness matching.
2. **Defense in Depth**: Security controls are applied at multiple tiers: network (TLS 1.3, Nginx), application (DRF throttling, RBAC decorators), session (HttpOnly cookies, JWT rotation), and database (row locking, SHA-256 hashing).
3. **Least Privilege**: Users are granted only the minimum permissions necessary for their academic or operational duties.
4. **Audit Immutability**: All departure exits, return entries, approvals, rejections, and denied movements are permanently stored in append-only tables (`GateEvent`, `ApprovalRecord`).

---

## 2. Authentication & Credential Storage

### Argon2id Password Hashing
All user passwords are encrypted using the Argon2id algorithm—winner of the Password Hashing Competition (PHC)—prior to persistence in PostgreSQL:
```python
PASSWORD_HASHERS = [
    'django.contrib.auth.hashers.Argon2PasswordHasher',
    'django.contrib.auth.hashers.PBKDF2PasswordHasher',
]
```
Argon2 provides resistance against GPU-accelerated and ASIC-based brute force and rainbow table attacks.

### JWT Dual-Token Architecture
- **Access Tokens**: Short-lived (15-minute expiration), signed using HMAC-SHA256.
- **Refresh Tokens**: Long-lived (7-day expiration), securely rotated upon each use.
- **Blacklisting**: Rotated or logged-out refresh tokens are blacklisted in PostgreSQL (`OutstandingToken`, `BlacklistedToken`), rendering compromised tokens unusable immediately.

### HttpOnly Cookie Transmission
Tokens are transmitted using secure cookies:
- `HttpOnly = True`: Prevents client-side JavaScript access, neutralizing Cross-Site Scripting (XSS) token exfiltration.
- `SameSite = Lax`: Prevents Cross-Site Request Forgery (CSRF) on cross-origin requests.
- `Secure = True`: In production, cookies are transmitted strictly over encrypted HTTPS connections.
- `Path = /`: Scoped explicitly to institutional origin.

---

## 3. Cryptographic QR Gate Pass Security

### Unpredictable Secret Tokens
- QR codes do not embed raw student registration numbers, passwords, or JWTs.
- Pass tokens are generated using Python's cryptographically secure `secrets.token_urlsafe(32)` source of randomness:
  $$\text{Entropy} \ge 256 \text{ bits}$$
- The token payload follows the structured format:
  `CAMPUSORA:{pass_id}:{unpredictable_secret}`

### Server-Side Hash Storage
- Raw tokens are never persisted in plaintext within PostgreSQL.
- Only the cryptographic SHA-256 hash of the token is saved:
  $$\text{Stored Hash} = \text{SHA-256}(\text{Raw Token})$$
- Even in the event of an unauthorized database dump, pass tokens cannot be reversed or used to forge clearances.

### Single-Use & Replay Attack Mitigation
- Every gate pass progresses through an irreversible finite state machine:
  $$\text{ACTIVE} \xrightarrow[\text{Exit Confirmed}]{\text{Step 1}} \text{USED} \xrightarrow[\text{Return Confirmed}]{\text{Step 2}} \text{RETURNED}$$
- **Replay Protection**:
  - Scanning an `ACTIVE` pass for return entry is rejected (`NOT_EXITED`).
  - Scanning a `USED` pass for a second departure is rejected (`ALREADY_USED`).
  - Scanning a `RETURNED` pass for return entry is rejected (`ALREADY_RETURNED`).
  - Scanning a `RETURNED` pass for exit is rejected (`Bad Request`).
- All status transitions utilize PostgreSQL row-level locks:
  ```python
  GatePass.objects.select_for_update().filter(token_hash=token_h)
  ```
  This guarantees that concurrent duplicate scans (e.g. attempting to scan a screenshot at two gates simultaneously) are serialized and safely rejected.

---

## 4. Role-Based Access Control (RBAC) Matrix

| Endpoint / Operation | Student | Faculty | HOD | Security | Warden |
|---|:---:|:---:|:---:|:---:|:---:|
| **Submit Leave Application** | Allowed | Denied | Denied | Denied | Denied |
| **View Own Leave History** | Own Only | Own Only | Own Only | Denied | Denied |
| **Forward Application to HOD** | Denied | Advisees/Dept | Denied | Denied | Denied |
| **Faculty Reject Application** | Denied | Advisees/Dept | Denied | Denied | Denied |
| **HOD Approve Application** | Denied | Denied | Dept Only | Denied | Denied |
| **HOD Reject Application** | Denied | Denied | Dept Only | Denied | Denied |
| **View Active QR Gate Pass** | Own Pass | Denied | Denied | Denied | Denied |
| **Verify QR at Checkpoint** | Denied | Denied | Denied | Assigned Gate | Denied |
| **Confirm Exit / Return** | Denied | Denied | Denied | Allowed | Denied |
| **Access Gate Audit Ledger** | Denied | Denied | Denied | Full | Denied |
| **Access Department Analytics**| Denied | Advisees/Dept | Dept Only | Gate Data | Block Only |

---

## 5. Rate Limiting & Throttling (Anti-Brute Force)

To protect institutional endpoints against distributed denial of service (DDoS) and brute force credential attacks, Django REST Framework throttles are enforced:

| Tier / Scope | Target Endpoints | Limit | Purpose |
|---|---|:---:|---|
| **Anonymous (`anon`)** | Unauthenticated public endpoints | 100/min | Prevents resource exhaustion |
| **User (`user`)** | Authenticated standard API requests | 1000/min | Standard institutional API pacing |
| **Auth (`auth`)** | `/api/v1/auth/login/`, `/auth/refresh/` | 15/min | Prevents password brute forcing |
| **Verify (`verify`)** | `/api/v1/gate-passes/verify/`, `verify-return/` | 120/min | Prevents automated QR fuzzing |

---

## 6. Input Validation & Data Sanitization

- **Django ORM Parameterization**: All SQL queries use Django's ORM parameter binding, preventing SQL injection (SQLi).
- **Date Chronology Validation**: `LeaveApplication.clean()` enforces $start\_date \le end\_date$.
- **Token Format Verification**: `parse_qr_token` validates token length, characters, and prefix format before computing SHA-256 hashes.
- **Fail-Safe Notification Handling**: Notification exceptions are isolated inside try-except blocks with `transaction.on_commit()`, ensuring communication failures never rollback or corrupt database transaction state.

---

## 7. Vulnerability Disclosure Policy

To report security vulnerabilities or configuration defects in CAMPUSORA, please contact the campus security engineering team at `security@campusora.edu`.
