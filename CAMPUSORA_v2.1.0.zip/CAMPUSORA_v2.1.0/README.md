# CAMPUSORA
**Tagline:** *Smarter Campus. Simpler Life.*  
**Version:** 2.1.0 (Production Hardened)  
**Status:** Complete (Days 1–10 Milestone Delivered)  

CAMPUSORA is an enterprise campus mobility and safety lifecycle platform. It digitizes student leave management, multi-tiered academic approval workflows, single-use cryptographic QR gate pass clearance, real-time curfew tracking, automated parent and warden notifications, and role-scoped institutional mobility intelligence.

---

## Key System Capabilities

- **Role-Based Identity & RBAC**: Strict separation of duties across **Student**, **Faculty**, **Head of Department (HOD)**, **Security Officer**, and **Hostel Warden** personas.
- **Argon2 Password Hashing & Secure JWT**: Dual-layer session handling utilizing HttpOnly, SameSite cookies with Argon2 password hashing and token rotation/blacklisting.
- **Multi-Tier Leave Workflow**: Configurable approval pipeline (Student Submission → Faculty Review & Endorsement → HOD Final Authorization) with atomic state transitions and immutable decision logs.
- **Cryptographic QR Gate Passes**: SHA-256 hashed unpredictable pass tokens generated only upon HOD approval, preventing token theft, forgery, and replay attacks.
- **Dual-Mode Security Checkpoint Terminal**: Single interface for security officers to verify both **Departure Exits** and **Return Entries**, with student photo likeness inspection and luggage clearance notes.
- **Overdue & Curfew Tracking**: Real-time evaluation against configurable campus curfews (`HOSTEL_CURFEW_TIME`), visual overdue warning banners, and off-campus monitoring registry.
- **Automated Alerts (Email & SMS)**: Automated safety dispatch to parents and hostel wardens upon campus departure and return entry, with strict block-level isolation (e.g. BH-2 residents notify BH-2 wardens only).
- **Consolidated Analytics Engine**: Role-scoped metrics dashboard presenting leave approval velocity, campus occupancy, 7-day movement graphs, and gate volume.

---

## Architectural Stack

| Layer | Technology | Specifications |
|---|---|---|
| **Frontend** | React 18 / Vite 6 | TailwindCSS, Lucide Icons, Code-Split Lazy Loaded Router |
| **Backend API** | Django 5.2 / Django REST Framework | Python 3.14, SimpleJWT, WhiteNoise-ready |
| **Database** | PostgreSQL 18.6 | Relational schema, composite indexing, row-level locking (`select_for_update`) |
| **Authentication** | Argon2 + JWT HttpOnly | RFC 7519, access/refresh cookie rotation |
| **Notifications** | Django Mail + Twilio/Mock SMS | HTML/plaintext templates with `transaction.on_commit()` dispatch |
| **Rate Limiting** | DRF Throttling | Tiered rate limits for anonymous, authenticated, and sensitive endpoints |

---

## System Architecture

```
                  +----------------------------------------------+
                  |         CAMPUSORA React 18 SPA (Vite)        |
                  | Student | Faculty | HOD | Security | Warden  |
                  +----------------------+-----------------------+
                                         |
                                         | REST API (HTTPS / HttpOnly JWT)
                                         v
                  +----------------------------------------------+
                  |           Django 5.2 REST Framework          |
                  | Rate Limiter | Auth Middleware | RBAC Guard  |
                  +----------------------+-----------------------+
                                         |
            +----------------------------+----------------------------+
            |                            |                            |
            v                            v                            v
  +--------------------+       +--------------------+       +--------------------+
  |   PostgreSQL 18    |       |   Email Dispatch   |       |    SMS Gateway     |
  |  Relational DB     |       | Console / SendGrid |       | Console / Twilio   |
  | Immutable Ledgers  |       |  Parent & Warden   |       |  Parent Safe Alert |
  +--------------------+       +--------------------+       +--------------------+
```

---

## Directory Structure

```text
CAMPUSORA/
├── backend/
│   ├── accounts/             # Custom User model, Argon2 hashing, JWT auth, RBAC permissions
│   ├── leaves/               # Leave applications, workflow transitions, validation rules
│   ├── approvals/            # Multi-tier approval records and decision timestamps
│   ├── passes/               # QR gate pass generation, hashing, verification, movement logs
│   ├── notifications/        # Email and SMS alert dispatchers and HTML templates
│   ├── analytics/            # Consolidated analytics and mobility metrics engine
│   ├── config/               # Settings, API URLs, throttling, and WSGI/ASGI handlers
│   ├── staticfiles/          # Collected static production assets
│   ├── .env.example          # Local development environment template
│   └── .env.production.example # Hardened production environment template
├── src/
│   ├── components/           # Reusable UI cards, tables, sidebars, AnalyticsView
│   ├── pages/
│   │   ├── student/          # Student dashboard, leave submission, gate pass display
│   │   ├── faculty/          # Faculty dashboard, review request terminal, history
│   │   ├── hod/              # HOD dashboard, approvals, departmental analytics
│   │   └── security/         # Security checkpoint terminal, scanner, overdue registry
│   ├── context/              # AuthContext, role state, demo mode fallback
│   ├── services/             # Axios/fetch API client wrapper
│   └── config/               # Institutional branding and theme configurations
├── scripts/
│   ├── backup_db.sh          # PostgreSQL automated backup and retention script
│   └── restore_db.sh         # Safe database recovery and restore script
├── backups/                  # Database backups directory
├── README.md                 # Primary system documentation
├── INSTALLATION.md           # Local installation and development setup
├── DEPLOYMENT.md             # Production deployment, Nginx, Gunicorn, SSL guide
├── SECURITY.md               # Security architecture and vulnerability mitigation
├── API_DOCUMENTATION.md      # Full REST API endpoints and schema reference
├── USER_GUIDE.md             # End-user guide for Students, Faculty, HODs, and Guards
└── TESTING_REPORT.md         # Comprehensive test suite and browser QA audit report
```

---

## Quick Start (Development)

### 1. Backend Setup
```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver 127.0.0.1:8000
```

### 2. Frontend Setup
```bash
# In project root
npm install
npm run dev
```

Visit `http://localhost:5173` to access the portal.

---

## License

Institutional Enterprise License © 2026 CAMPUSORA. All campus rights reserved.
