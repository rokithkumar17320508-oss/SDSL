# CAMPUSORA — Enterprise Production Deployment Guide

This guide details the deployment architecture, server provisioning, reverse proxy configuration, and database operational protocols for hosting CAMPUSORA in a hardened production environment.

---

## 1. Production Deployment Topology

```text
                           Internet Clients (HTTPS)
                                     │
                                     ▼
                    ┌─────────────────────────────────┐
                    │     Nginx 1.24+ Reverse Proxy   │
                    │   SSL / TLS 1.3 Termination     │
                    │   Security Headers & Rate Limit │
                    └────────────────┬────────────────┘
                                     │
                 ┌───────────────────┴───────────────────┐
                 │                                       │
                 ▼ /                                     ▼ /api/ & /admin/
    ┌─────────────────────────┐             ┌─────────────────────────┐
    │ React Production Build  │             │ Gunicorn WSGI Cluster   │
    │  Static HTML/JS/CSS     │             │ 4x Python 3.14 Workers  │
    │  (/var/www/campusora)   │             │ unix:/run/gunicorn.sock │
    └─────────────────────────┘             └────────────┬────────────┘
                                                         │
                                                         ▼
                                            ┌─────────────────────────┐
                                            │    PostgreSQL 18.6      │
                                            │  CAMPUSORA Database     │
                                            │  Port 5432 (Localhost)  │
                                            └─────────────────────────┘
```

---

## 2. Server Pre-requisites

- **Server OS:** Ubuntu 22.04 LTS or Debian 12
- **Hardware Specs:** Minimum 2 vCPU, 4 GB RAM, 40 GB NVMe Storage
- **Required Packages:**
  ```bash
  sudo apt update && sudo apt install -y \
      nginx \
      postgresql postgresql-contrib \
      python3 python3-venv python3-pip \
      certbot python3-certbot-nginx \
      curl git ufw
  ```

---

## 3. Database Hardening & Configuration

Create dedicated production database and user:
```bash
sudo -u postgres psql << EOF
CREATE USER campusora_prod_user WITH PASSWORD 'SECURE_PRODUCTION_RANDOM_PASSWORD';
CREATE DATABASE campusora_prod_db OWNER campusora_prod_user;
ALTER USER campusora_prod_user SET client_encoding TO 'utf8';
ALTER USER campusora_prod_user SET default_transaction_isolation TO 'read committed';
ALTER USER campusora_prod_user SET timezone TO 'UTC';
GRANT ALL PRIVILEGES ON DATABASE campusora_prod_db TO campusora_prod_user;
EOF
```

---

## 4. Backend Production Setup

### A. Code Deployment
```bash
sudo mkdir -p /var/www/campusora
sudo chown -R $USER:$USER /var/www/campusora
cd /var/www/campusora
# Clone repository or copy project files
```

### B. Python Virtual Environment
```bash
cd /var/www/campusora/backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt gunicorn
```

### C. Environment Configuration (`backend/.env`)
```ini
SECRET_KEY=GENERATE_RANDOM_SECRET_KEY_USING_PYTHON_SECRETS
DEBUG=False
ALLOWED_HOSTS=campusora.edu,api.campusora.edu

SECURE_SSL_REDIRECT=True
SECURE_HSTS_SECONDS=31536000
CORS_ALLOWED_ORIGINS=https://campusora.edu

DB_ENGINE=postgresql
DB_NAME=campusora_prod_db
DB_USER=campusora_prod_user
DB_PASSWORD=SECURE_PRODUCTION_RANDOM_PASSWORD
DB_HOST=127.0.0.1
DB_PORT=5432

EMAIL_BACKEND=django.core.mail.backends.smtp.EmailBackend
EMAIL_HOST=smtp.sendgrid.net
EMAIL_PORT=587
EMAIL_USE_TLS=True
EMAIL_HOST_USER=apikey
EMAIL_HOST_PASSWORD=SENDGRID_API_KEY
DEFAULT_FROM_EMAIL=CAMPUSORA Alerts <notifications@campusora.edu>

SMS_PROVIDER=twilio
TWILIO_ACCOUNT_SID=ACXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
TWILIO_AUTH_TOKEN=YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY
TWILIO_FROM_NUMBER=+1234567890

HOSTEL_CURFEW_TIME=21:00
DEMO_MODE=False
```

### D. Run Migrations & Collect Static Files
```bash
python manage.py migrate
python manage.py collectstatic --no-input
python manage.py check --deploy
```

---

## 5. Gunicorn Systemd Service

Create `/etc/systemd/system/campusora.service`:
```ini
[Unit]
Description=CAMPUSORA Gunicorn WSGI Application Server
After=network.target postgresql.service

[Service]
User=www-data
Group=www-data
WorkingDirectory=/var/www/campusora/backend
ExecStart=/var/www/campusora/backend/.venv/bin/gunicorn \
    --access-logfile /var/log/campusora/gunicorn_access.log \
    --error-logfile /var/log/campusora/gunicorn_error.log \
    --workers 4 \
    --worker-class gthread \
    --threads 2 \
    --worker-connections 1000 \
    --bind unix:/run/campusora.sock \
    config.wsgi:application
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
```

Enable and start Gunicorn:
```bash
sudo mkdir -p /var/log/campusora
sudo chown -R www-data:www-data /var/log/campusora
sudo systemctl daemon-reload
sudo systemctl enable --now campusora.service
```

---

## 6. Frontend Production Build

Compile React single-page application:
```bash
cd /var/www/campusora
npm install
npm run build
```
The compiled output is located in `/var/www/campusora/dist`.

---

## 7. Nginx Web Server Configuration

Create `/etc/nginx/sites-available/campusora`:
```nginx
server {
    listen 80;
    server_name campusora.edu www.campusora.edu;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name campusora.edu www.campusora.edu;

    ssl_certificate /etc/letsencrypt/live/campusora.edu/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/campusora.edu/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers on;
    ssl_ciphers HIGH:!aNULL:!MD5;

    # Security Headers
    add_header X-Content-Type-Options nosniff always;
    add_header X-Frame-Options DENY always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains; preload" always;

    # Frontend Single Page Application
    root /var/www/campusora/dist;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    # Django Collected Static Files
    location /static/ {
        alias /var/www/campusora/backend/staticfiles/;
        expires 30d;
        add_header Cache-Control "public, max-age=2592000, immutable";
    }

    # Backend API & Admin Proxy
    location ~ ^/(api|admin)/ {
        proxy_pass http://unix:/run/campusora.sock;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 90;
        proxy_connect_timeout 90;
    }

    client_max_body_size 10M;
}
```

Enable site and reload Nginx:
```bash
sudo ln -s /etc/nginx/sites-available/campusora /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

---

## 8. Automated Database Backup & Retention

Set up daily automated backups via cron using the bundled `scripts/backup_db.sh`:

```bash
# Add cron job for daily midnight backup
sudo crontab -u postgres -e
```
Add line:
```cron
0 0 * * * /var/www/campusora/scripts/backup_db.sh >> /var/log/campusora/backup.log 2>&1
```

To restore a backup if needed:
```bash
/var/www/campusora/scripts/restore_db.sh /var/www/campusora/backups/campusora_db_backup_TIMESTAMP.sql.gz
```
