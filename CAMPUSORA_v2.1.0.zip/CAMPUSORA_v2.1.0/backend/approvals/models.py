"""
CAMPUSORA Approval Record Model.
Provides an immutable audit log of faculty and HOD review actions.
"""

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models


class ReviewerRole(models.TextChoices):
    FACULTY = 'FACULTY', 'Faculty Advisor'
    HOD = 'HOD', 'Head of Department'


class Decision(models.TextChoices):
    FORWARDED_TO_HOD = 'FORWARDED_TO_HOD', 'Approved & Forwarded to HOD'
    HOD_APPROVED = 'HOD_APPROVED', 'Final Approval Granted'
    REJECTED = 'REJECTED', 'Rejected'


class ApprovalRecord(models.Model):
    """
    Immutable audit trail for every endorsement or rejection decision.
    Once created, records cannot be edited or overwritten.
    """
    leave_application = models.ForeignKey(
        'leaves.LeaveApplication',
        on_delete=models.CASCADE,
        related_name='approval_records',
        help_text="Target leave application"
    )
    reviewer = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name='approval_decisions',
        help_text="Faculty or HOD official who recorded the decision"
    )
    reviewer_role = models.CharField(
        max_length=20,
        choices=ReviewerRole.choices,
        help_text="Role capacity during this decision"
    )
    decision = models.CharField(
        max_length=30,
        choices=Decision.choices,
        help_text="Decision outcome"
    )
    remarks = models.TextField(
        blank=True,
        help_text="Optional comments or mandatory rejection rationale"
    )
    timestamp = models.DateTimeField(
        auto_now_add=True,
        db_index=True,
        help_text="Immutable decision timestamp"
    )

    class Meta:
        verbose_name = "Approval Record"
        verbose_name_plural = "Approval Records"
        ordering = ['timestamp']

    def clean(self):
        super().clean()
        if self.decision == Decision.REJECTED and not (self.remarks and self.remarks.strip()):
            raise ValidationError({
                'remarks': 'Rejection remarks are mandatory when rejecting a leave application.'
            })

    def save(self, *args, **kwargs):
        # Strict immutability: prevent updating existing records
        if self.pk is not None:
            raise ValidationError("Approval records are immutable audit logs and cannot be modified.")
        self.full_clean()
        super().save(*args, **kwargs)

    def __str__(self):
        reviewer_name = self.reviewer.get_full_name() or self.reviewer.username
        return f"{self.leave_application.application_id} - {self.get_decision_display()} by {reviewer_name}"
