from django.contrib import admin
from .models import ApprovalRecord


@admin.register(ApprovalRecord)
class ApprovalRecordAdmin(admin.ModelAdmin):
    list_display = (
        'leave_application',
        'reviewer',
        'reviewer_role',
        'decision',
        'timestamp',
    )
    list_filter = ('decision', 'reviewer_role', 'timestamp')
    search_fields = (
        'leave_application__application_id',
        'reviewer__username',
        'reviewer__first_name',
        'reviewer__last_name',
        'remarks',
    )
    readonly_fields = (
        'leave_application',
        'reviewer',
        'reviewer_role',
        'decision',
        'remarks',
        'timestamp',
    )

    def has_change_permission(self, request, obj=None):
        # Enforce append-only audit trail in Django Admin
        return False
