from datetime import date, timedelta
from django.test import TestCase
from django.core.exceptions import ValidationError
from django.contrib.auth import get_user_model
from leaves.models import LeaveApplication, LeaveType, LeaveStatus
from accounts.models import Role
from .models import ApprovalRecord, ReviewerRole, Decision

User = get_user_model()


class ApprovalRecordModelTest(TestCase):
    def setUp(self):
        self.student = User.objects.create_user(
            username='rahul_student',
            password='Password123!',
            role=Role.STUDENT,
            department='Computer Science & Engineering'
        )
        self.faculty = User.objects.create_user(
            username='prof_sharma',
            password='Password123!',
            role=Role.FACULTY,
            department='Computer Science & Engineering'
        )
        today = date.today()
        self.leave = LeaveApplication.objects.create(
            student=self.student,
            leave_type=LeaveType.REGULAR_LEAVE,
            start_date=today,
            end_date=today + timedelta(days=2),
            reason='Attending conference'
        )

    def test_create_approval_record_forwarded(self):
        record = ApprovalRecord.objects.create(
            leave_application=self.leave,
            reviewer=self.faculty,
            reviewer_role=ReviewerRole.FACULTY,
            decision=Decision.FORWARDED_TO_HOD,
            remarks='Recommended for approval'
        )
        self.assertEqual(record.decision, Decision.FORWARDED_TO_HOD)
        self.assertEqual(record.reviewer, self.faculty)

    def test_rejection_requires_mandatory_remarks(self):
        record = ApprovalRecord(
            leave_application=self.leave,
            reviewer=self.faculty,
            reviewer_role=ReviewerRole.FACULTY,
            decision=Decision.REJECTED,
            remarks=''  # Empty remarks on rejection should be invalid
        )
        with self.assertRaises(ValidationError):
            record.full_clean()

    def test_audit_record_immutability(self):
        record = ApprovalRecord.objects.create(
            leave_application=self.leave,
            reviewer=self.faculty,
            reviewer_role=ReviewerRole.FACULTY,
            decision=Decision.FORWARDED_TO_HOD,
            remarks='Initial recommendation'
        )
        # Attempt to modify the record
        record.remarks = 'Tampered remark'
        with self.assertRaises(ValidationError):
            record.save()
