from django.contrib import admin
from .models import GatePass, GateEvent


@admin.register(GatePass)
class GatePassAdmin(admin.ModelAdmin):
    list_display = (
        'pass_id',
        'leave_application',
        'gate_type',
        'status',
        'valid_from',
        'valid_until',
        'exit_recorded_at',
        'entry_recorded_at',
    )
    list_filter = ('status', 'gate_type', 'valid_from')
    search_fields = (
        'pass_id',
        'leave_application__application_id',
        'leave_application__student__username',
        'leave_application__student__first_name',
        'leave_application__student__last_name',
    )
    readonly_fields = ('pass_id', 'token_hash', 'created_at')


@admin.register(GateEvent)
class GateEventAdmin(admin.ModelAdmin):
    list_display = (
        'id',
        'gate_pass',
        'student',
        'security_officer',
        'gate_type',
        'event_type',
        'verification_outcome',
        'timestamp',
    )
    list_filter = ('event_type', 'verification_outcome', 'gate_type', 'timestamp')
    search_fields = (
        'gate_pass__pass_id',
        'student__username',
        'security_officer__username',
        'remarks',
    )
    readonly_fields = ('timestamp',)
