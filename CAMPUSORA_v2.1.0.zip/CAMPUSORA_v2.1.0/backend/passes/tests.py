"""
Automated Test Suite for CAMPUSORA Day 7:
Secure QR Gate-Pass Generation, Cryptographic Token Verification,
Atomic Single-Use Checkpoint Clearance, and Gate Event Logging.
"""

from datetime import date, timedelta
from django.test import TestCase
from django.utils import timezone
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient
from rest_framework import status
from accounts.models import Role, StudentProfile
from leaves.models import LeaveApplication, LeaveType, LeaveStatus
from approvals.models import ApprovalRecord, ReviewerRole, Decision
from passes.models import (
    GatePass,
    GateEvent,
    GateType,
    PassStatus,
    EventType,
    VerificationOutcome,
)
from passes.utils import generate_secure_token, hash_token, build_qr_payload

User = get_user_model()


class GatePassWorkflowTest(TestCase):
    def setUp(self):
        self.client = APIClient()

        # Faculty & HOD (CSE)
        self.faculty = User.objects.create_user(
            username='prof_skverma',
            password='Password123!',
            role=Role.FACULTY,
            department='Computer Science & Engineering'
        )
        self.hod = User.objects.create_user(
            username='prof_rmehra',
            password='Password123!',
            role=Role.HOD,
            department='Computer Science & Engineering'
        )

        # Security Officers (Main Gate vs Hostel Gate)
        self.sec_main = User.objects.create_user(
            username='sec_officer_main',
            password='Password123!',
            role=Role.SECURITY,
            department='Campus Safety & Security',
            assigned_gate='College Main Gate'
        )
        self.sec_hostel = User.objects.create_user(
            username='sec_officer_hostel',
            password='Password123!',
            role=Role.SECURITY,
            department='Campus Safety & Security',
            assigned_gate='Hostel Gate'
        )

        # Student 1 (Arjun)
        self.student1 = User.objects.create_user(
            username='student_arjun',
            password='Password123!',
            role=Role.STUDENT,
            department='Computer Science & Engineering'
        )
        self.student1_profile = StudentProfile.objects.create(
            user=self.student1,
            registration_number='2024CSE1084',
            department='Computer Science & Engineering',
            year=3,
            semester=6,
            room_number='BH-2, Room 405',
            advisor=self.faculty
        )

        # Student 2 (Kavya)
        self.student2 = User.objects.create_user(
            username='student_kavya',
            password='Password123!',
            role=Role.STUDENT,
            department='Computer Science & Engineering'
        )
        self.student2_profile = StudentProfile.objects.create(
            user=self.student2,
            registration_number='2024CSE1085',
            department='Computer Science & Engineering',
            year=3,
            semester=6,
            room_number='GH-1, Room 202',
            advisor=self.faculty
        )

        # HOD-approved leave application for Student 1
        today = date.today()
        self.approved_app = LeaveApplication.objects.create(
            application_id='APP-7001',
            student=self.student1,
            leave_type=LeaveType.DAY_PASS,
            start_date=today,
            end_date=today,
            reason='Hospital appointment',
            status=LeaveStatus.HOD_APPROVED,
            faculty_reviewer=self.faculty,
            hod_reviewer=self.hod
        )

        # Pending leave application for Student 1
        self.pending_app = LeaveApplication.objects.create(
            application_id='APP-7002',
            student=self.student1,
            leave_type=LeaveType.REGULAR_LEAVE,
            start_date=today + timedelta(days=2),
            end_date=today + timedelta(days=3),
            reason='Family gathering',
            status=LeaveStatus.PENDING_FACULTY
        )

        # Rejected leave application for Student 1
        self.rejected_app = LeaveApplication.objects.create(
            application_id='APP-7003',
            student=self.student1,
            leave_type=LeaveType.HOSTEL_OUTPASS,
            start_date=today + timedelta(days=5),
            end_date=today + timedelta(days=6),
            reason='Vacation trip',
            status=LeaveStatus.REJECTED,
            faculty_reviewer=self.faculty,
            rejection_reason='Exam scheduled'
        )

    # 1. Approved leave generates a valid QR pass
    def test_01_approved_leave_generates_valid_qr_pass(self):
        self.client.force_authenticate(user=self.student1)
        response = self.client.post('/api/v1/gate-passes/generate/', {
            'application_id': self.approved_app.application_id
        })
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        data = response.data
        self.assertTrue(data['pass_id'].startswith('GP-'))
        self.assertEqual(data['status'], 'ACTIVE')
        self.assertIsNotNone(data['qr_code_image'])
        self.assertTrue(data['qr_code_image'].startswith('data:image/png;base64,'))
        self.assertIsNotNone(data['raw_token'])

        # Verify token hash stored in PostgreSQL (not plaintext token)
        pass_record = GatePass.objects.get(pass_id=data['pass_id'])
        self.assertEqual(pass_record.token_hash, hash_token(data['raw_token']))
        self.assertNotEqual(pass_record.token_hash, data['raw_token'])

    # 2. Pending leave cannot generate a pass
    def test_02_pending_leave_cannot_generate_pass(self):
        self.client.force_authenticate(user=self.student1)
        response = self.client.post('/api/v1/gate-passes/generate/', {
            'application_id': self.pending_app.application_id
        })
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('HOD-approved', response.data['detail'])

    # 3. Rejected leave cannot generate a pass
    def test_03_rejected_leave_cannot_generate_pass(self):
        self.client.force_authenticate(user=self.student1)
        response = self.client.post('/api/v1/gate-passes/generate/', {
            'application_id': self.rejected_app.application_id
        })
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    # 4. Students cannot access other students' passes
    def test_04_students_cannot_access_other_student_passes(self):
        # Generate pass for student 1
        raw_token = generate_secure_token()
        pass1 = GatePass.objects.create(
            leave_application=self.approved_app,
            gate_type=GateType.COLLEGE_MAIN_GATE,
            token_hash=hash_token(raw_token),
            valid_from=timezone.now(),
            valid_until=timezone.now() + timedelta(days=1),
            status=PassStatus.ACTIVE
        )

        # Student 2 tries to generate pass using Student 1's application ID
        self.client.force_authenticate(user=self.student2)
        res_gen = self.client.post('/api/v1/gate-passes/generate/', {
            'application_id': self.approved_app.application_id
        })
        self.assertEqual(res_gen.status_code, status.HTTP_403_FORBIDDEN)

        # Student 2 lists gate passes (should not see Student 1's pass)
        res_list = self.client.get('/api/v1/gate-passes/')
        self.assertEqual(res_list.status_code, status.HTTP_200_OK)
        results = res_list.data.get('results', res_list.data)
        self.assertFalse(any(p['pass_id'] == pass1.pass_id for p in results))

    # 5. Invalid QR tokens are rejected
    def test_05_invalid_qr_token_rejected(self):
        self.client.force_authenticate(user=self.sec_main)
        response = self.client.post('/api/v1/gate-passes/verify/', {
            'token': 'non_existent_fake_token_12345'
        })
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(response.data['outcome'], 'INVALID_TOKEN')

        # Verify GateEvent audit was created
        event = GateEvent.objects.filter(verification_outcome='INVALID_TOKEN').first()
        self.assertIsNotNone(event)
        self.assertEqual(event.security_officer, self.sec_main)

    # 6. Expired passes are rejected
    def test_06_expired_pass_rejected(self):
        raw_token = generate_secure_token()
        # Created in the past and expired yesterday
        pass_expired = GatePass.objects.create(
            leave_application=self.approved_app,
            gate_type=GateType.COLLEGE_MAIN_GATE,
            token_hash=hash_token(raw_token),
            valid_from=timezone.now() - timedelta(days=3),
            valid_until=timezone.now() - timedelta(days=1),
            status=PassStatus.ACTIVE
        )
        self.client.force_authenticate(user=self.sec_main)
        response = self.client.post('/api/v1/gate-passes/verify/', {'token': raw_token})
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(response.data['outcome'], 'EXPIRED')

        # Attempt to confirm exit must also fail
        res_exit = self.client.post('/api/v1/gate-passes/confirm-exit/', {'token': raw_token})
        self.assertEqual(res_exit.status_code, status.HTTP_400_BAD_REQUEST)

    # 7. Revoked passes are rejected
    def test_07_revoked_pass_rejected(self):
        raw_token = generate_secure_token()
        pass_revoked = GatePass.objects.create(
            leave_application=self.approved_app,
            gate_type=GateType.COLLEGE_MAIN_GATE,
            token_hash=hash_token(raw_token),
            valid_from=timezone.now(),
            valid_until=timezone.now() + timedelta(days=1),
            status=PassStatus.REVOKED
        )
        self.client.force_authenticate(user=self.sec_main)
        response = self.client.post('/api/v1/gate-passes/verify/', {'token': raw_token})
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(response.data['outcome'], 'REVOKED')

    # 8. Used passes are rejected (cannot be reused)
    def test_08_used_pass_rejected(self):
        raw_token = generate_secure_token()
        pass_used = GatePass.objects.create(
            leave_application=self.approved_app,
            gate_type=GateType.COLLEGE_MAIN_GATE,
            token_hash=hash_token(raw_token),
            valid_from=timezone.now(),
            valid_until=timezone.now() + timedelta(days=1),
            status=PassStatus.USED,
            exit_recorded_at=timezone.now() - timedelta(hours=2)
        )
        self.client.force_authenticate(user=self.sec_main)
        response = self.client.post('/api/v1/gate-passes/verify/', {'token': raw_token})
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(response.data['outcome'], 'ALREADY_USED')

        # Exit confirmation fails
        res_exit = self.client.post('/api/v1/gate-passes/confirm-exit/', {'token': raw_token})
        self.assertEqual(res_exit.status_code, status.HTTP_400_BAD_REQUEST)

    # 9. Wrong-gate verification is rejected
    def test_09_wrong_gate_verification_rejected(self):
        raw_token = generate_secure_token()
        # Pass authorized for College Main Gate only
        pass_main_only = GatePass.objects.create(
            leave_application=self.approved_app,
            gate_type=GateType.COLLEGE_MAIN_GATE,
            token_hash=hash_token(raw_token),
            valid_from=timezone.now(),
            valid_until=timezone.now() + timedelta(days=1),
            status=PassStatus.ACTIVE
        )
        # Hostel security officer attempts to verify College Main Gate pass
        self.client.force_authenticate(user=self.sec_hostel)
        response = self.client.post('/api/v1/gate-passes/verify/', {'token': raw_token})
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(response.data['outcome'], 'WRONG_GATE')
        self.assertIn('Wrong gate', response.data['detail'])

    # 10. Non-security users cannot verify or confirm gate passes
    def test_10_unauthorized_roles_cannot_call_security_endpoints(self):
        self.client.force_authenticate(user=self.student1)
        res_v = self.client.post('/api/v1/gate-passes/verify/', {'token': 'dummy'})
        self.assertEqual(res_v.status_code, status.HTTP_403_FORBIDDEN)

        res_c = self.client.post('/api/v1/gate-passes/confirm-exit/', {'token': 'dummy'})
        self.assertEqual(res_c.status_code, status.HTTP_403_FORBIDDEN)

    # 11. First confirmed exit succeeds
    def test_11_first_confirmed_exit_succeeds(self):
        raw_token = generate_secure_token()
        gate_pass = GatePass.objects.create(
            leave_application=self.approved_app,
            gate_type=GateType.COLLEGE_MAIN_GATE,
            token_hash=hash_token(raw_token),
            valid_from=timezone.now(),
            valid_until=timezone.now() + timedelta(days=1),
            status=PassStatus.ACTIVE
        )
        self.client.force_authenticate(user=self.sec_main)

        # 1. Verify pass
        res_verify = self.client.post('/api/v1/gate-passes/verify/', {'token': raw_token})
        self.assertEqual(res_verify.status_code, status.HTTP_200_OK)
        self.assertTrue(res_verify.data['valid'])
        self.assertEqual(res_verify.data['student']['name'], 'student_arjun')

        # 2. Confirm exit
        res_confirm = self.client.post('/api/v1/gate-passes/confirm-exit/', {
            'token': raw_token,
            'remarks': 'Identity verified. Gate exit cleared.'
        })
        self.assertEqual(res_confirm.status_code, status.HTTP_200_OK)
        self.assertEqual(res_confirm.data['status'], 'USED')

        # Check DB state
        gate_pass.refresh_from_db()
        self.assertEqual(gate_pass.status, PassStatus.USED)
        self.assertIsNotNone(gate_pass.exit_recorded_at)

    # 12. Duplicate exit confirmation fails
    def test_12_duplicate_exit_confirmation_fails(self):
        raw_token = generate_secure_token()
        gate_pass = GatePass.objects.create(
            leave_application=self.approved_app,
            gate_type=GateType.COLLEGE_MAIN_GATE,
            token_hash=hash_token(raw_token),
            valid_from=timezone.now(),
            valid_until=timezone.now() + timedelta(days=1),
            status=PassStatus.ACTIVE
        )
        self.client.force_authenticate(user=self.sec_main)

        # First exit confirmation succeeds
        res1 = self.client.post('/api/v1/gate-passes/confirm-exit/', {'token': raw_token})
        self.assertEqual(res1.status_code, status.HTTP_200_OK)

        # Second attempt with same token fails immediately
        res2 = self.client.post('/api/v1/gate-passes/confirm-exit/', {'token': raw_token})
        self.assertEqual(res2.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('already been used', res2.data['detail'])

    # 13. Pass supporting Both Gates clears both College and Hostel checkpoints
    def test_13_both_gates_clearance_supported(self):
        raw_token = generate_secure_token()
        # Hostel Outpass authorizes Both Gates
        pass_both = GatePass.objects.create(
            leave_application=self.approved_app,
            gate_type=GateType.BOTH,
            token_hash=hash_token(raw_token),
            valid_from=timezone.now(),
            valid_until=timezone.now() + timedelta(days=1),
            status=PassStatus.ACTIVE
        )
        # Hostel officer verifies
        self.client.force_authenticate(user=self.sec_hostel)
        res_hostel = self.client.post('/api/v1/gate-passes/verify/', {'token': raw_token})
        self.assertEqual(res_hostel.status_code, status.HTTP_200_OK)
        self.assertTrue(res_hostel.data['valid'])

        # Main gate officer also verifies
        self.client.force_authenticate(user=self.sec_main)
        res_main = self.client.post('/api/v1/gate-passes/verify/', {'token': raw_token})
        self.assertEqual(res_main.status_code, status.HTTP_200_OK)
        self.assertTrue(res_main.data['valid'])

    # 14. Gate events are stored correctly and viewable by security
    def test_14_gate_events_stored_and_retrievable(self):
        raw_token = generate_secure_token()
        gate_pass = GatePass.objects.create(
            leave_application=self.approved_app,
            gate_type=GateType.COLLEGE_MAIN_GATE,
            token_hash=hash_token(raw_token),
            valid_from=timezone.now(),
            valid_until=timezone.now() + timedelta(days=1),
            status=PassStatus.ACTIVE
        )
        self.client.force_authenticate(user=self.sec_main)
        self.client.post('/api/v1/gate-passes/confirm-exit/', {
            'token': raw_token,
            'remarks': 'Student departed via Gate 1'
        })

        # Fetch gate events log
        res_events = self.client.get('/api/v1/gate-events/')
        self.assertEqual(res_events.status_code, status.HTTP_200_OK)
        events = res_events.data.get('results', res_events.data)
        self.assertTrue(len(events) >= 1)
        first_event = events[0]
        self.assertEqual(first_event['event_type'], 'EXIT')
        self.assertEqual(first_event['verification_outcome'], 'SUCCESS')
        self.assertEqual(first_event['security_officer_name'], 'sec_officer_main')

    # 15. Student active pass endpoint returns dynamic status
    def test_15_student_active_pass_endpoint(self):
        self.client.force_authenticate(user=self.student1)
        res = self.client.get('/api/v1/gate-passes/active/')
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertEqual(res.data['status'], 'ACTIVE')
        self.assertIsNotNone(res.data['qr_code_image'])

    # 16. Security officer can record denial with mandatory reason
    def test_16_security_denial_recorded(self):
        raw_token = generate_secure_token()
        gate_pass = GatePass.objects.create(
            leave_application=self.approved_app,
            gate_type=GateType.COLLEGE_MAIN_GATE,
            token_hash=hash_token(raw_token),
            valid_from=timezone.now(),
            valid_until=timezone.now() + timedelta(days=1),
            status=PassStatus.ACTIVE
        )
        self.client.force_authenticate(user=self.sec_main)
        res_deny = self.client.post('/api/v1/gate-passes/deny-exit/', {
            'token': raw_token,
            'reason': 'Student failed to produce institutional ID card.'
        })
        self.assertEqual(res_deny.status_code, status.HTTP_200_OK)
        event = GateEvent.objects.filter(verification_outcome='DENIED').first()
        self.assertIsNotNone(event)
        self.assertIn('failed to produce institutional ID card', event.remarks)
