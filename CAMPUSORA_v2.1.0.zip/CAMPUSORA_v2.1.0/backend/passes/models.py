"""
CAMPUSORA Gate Pass & Gate Event Models.
Cryptographically verified single-use gate passes and immutable security checkpoint logs.
"""

import random
from django.conf import settings
from django.db import models
from django.utils import timezone


class GateType(models.TextChoices):
    COLLEGE_MAIN_GATE = 'College Main Gate', 'College Main Gate'
    HOSTEL_GATE = 'Hostel Gate', 'Hostel Gate'
    BOTH = 'Both Gates', 'Both Gates (College & Hostel)'


class PassStatus(models.TextChoices):
    ACTIVE = 'ACTIVE', 'Active & Valid'
    USED = 'USED', 'Used / Exited'
    RETURNED = 'RETURNED', 'Returned'
    EXPIRED = 'EXPIRED', 'Expired'
    REVOKED = 'REVOKED', 'Revoked'


class EventType(models.TextChoices):
    EXIT = 'EXIT', 'Campus Exit'
    ENTRY = 'ENTRY', 'Campus Entry'


class VerificationOutcome(models.TextChoices):
    SUCCESS = 'SUCCESS', 'Exit Verified & Cleared'
    RETURN_SUCCESS = 'RETURN_SUCCESS', 'Return Entry Verified & Cleared'
    DENIED = 'DENIED', 'Denied by Security'
    INVALID_TOKEN = 'INVALID_TOKEN', 'Invalid Token'
    EXPIRED = 'EXPIRED', 'Pass Expired'
    WRONG_GATE = 'WRONG_GATE', 'Wrong Gate Checkpoint'
    ALREADY_USED = 'ALREADY_USED', 'Pass Already Used for Exit'
    ALREADY_RETURNED = 'ALREADY_RETURNED', 'Return Entry Already Completed'
    NOT_EXITED = 'NOT_EXITED', 'Student Has Not Exited Campus'
    REVOKED = 'REVOKED', 'Pass Revoked'


def generate_pass_id():
    """Generates unique 4-digit gate pass identifier matching frontend conventions (e.g. GP-4819)."""
    return f"GP-{random.randint(1000, 9999)}"


class GatePass(models.Model):
    """
    Cryptographically tied single-use gate pass generated from HOD-approved leave applications.
    Stores SHA-256 token hash to prevent plaintext token exposure in PostgreSQL.
    """
    pass_id = models.CharField(
        max_length=20,
        unique=True,
        db_index=True,
        default=generate_pass_id,
        help_text="Unique Gate Pass Tracking ID"
    )
    leave_application = models.OneToOneField(
        'leaves.LeaveApplication',
        on_delete=models.CASCADE,
        related_name='gate_pass',
        help_text="Underlying approved leave application"
    )
    gate_type = models.CharField(
        max_length=30,
        choices=GateType.choices,
        default=GateType.COLLEGE_MAIN_GATE,
        help_text="Authorized checkpoint gate"
    )
    token_hash = models.CharField(
        max_length=64,
        unique=True,
        db_index=True,
        help_text="SHA-256 hash of unpredictable secret QR token"
    )
    valid_from = models.DateTimeField(
        help_text="Commencement of gate clearance window"
    )
    valid_until = models.DateTimeField(
        help_text="Expiration timestamp of clearance window"
    )
    status = models.CharField(
        max_length=20,
        choices=PassStatus.choices,
        default=PassStatus.ACTIVE,
        db_index=True,
        help_text="Current pass status"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        db_index=True,
        help_text="Pass generation timestamp"
    )
    exit_recorded_at = models.DateTimeField(
        null=True,
        blank=True,
        help_text="Timestamp when security confirmed departure"
    )
    entry_recorded_at = models.DateTimeField(
        null=True,
        blank=True,
        help_text="Timestamp when security confirmed return entry"
    )

    class Meta:
        verbose_name = "Gate Pass"
        verbose_name_plural = "Gate Passes"
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['status', 'valid_until'], name='idx_gatepass_status_valid'),
        ]

    @property
    def is_expired(self):
        return timezone.now() > self.valid_until

    @property
    def expected_return_time(self):
        """
        Timezone-aware deadline by which student is expected to return.
        Uses configured hostel curfew time (default 21:00 / 9:00 PM).
        """
        from datetime import datetime, time
        curfew_hour, curfew_min = 21, 0
        curfew_str = getattr(settings, 'HOSTEL_CURFEW_TIME', '21:00')
        try:
            parts = str(curfew_str).split(':')
            curfew_hour, curfew_min = int(parts[0]), int(parts[1])
        except Exception:
            pass

        end_d = self.leave_application.end_date
        dt = datetime.combine(end_d, time(curfew_hour, curfew_min))
        current_tz = timezone.get_current_timezone()
        if timezone.is_naive(dt):
            return timezone.make_aware(dt, current_tz)
        return dt

    @property
    def is_overdue(self):
        """
        True if the student has exited (USED), has not yet RETURNED,
        and current time is past expected return deadline.
        """
        if self.status != PassStatus.USED:
            return False
        deadline = self.expected_return_time
        if not deadline:
            return False
        return timezone.now() > deadline

    @property
    def returned_overdue(self):
        """
        True if the student has returned, but their actual return timestamp was past curfew.
        """
        if self.status != PassStatus.RETURNED or not self.entry_recorded_at:
            return False
        deadline = self.expected_return_time
        return self.entry_recorded_at > deadline

    @property
    def is_returned(self):
        return self.status == PassStatus.RETURNED

    def is_valid_for_gate(self, officer_gate):
        """
        Validates whether this pass permits departure through the security officer's gate.
        """
        if not officer_gate:
            return True
        if self.gate_type == GateType.BOTH:
            return True
        
        # Normalize strings for comparison
        pass_gate_norm = self.gate_type.lower()
        officer_gate_norm = officer_gate.lower()

        if 'college' in pass_gate_norm or 'main' in pass_gate_norm:
            return 'college' in officer_gate_norm or 'main' in officer_gate_norm
        elif 'hostel' in pass_gate_norm:
            return 'hostel' in officer_gate_norm

        return pass_gate_norm == officer_gate_norm

    def __str__(self):
        return f"{self.pass_id} ({self.status}) - {self.leave_application.application_id}"


class GateEvent(models.Model):
    """
    Audit log of all checkpoint verifications, successful departures, and denied attempts.
    Designed for full future compatibility with return-entry logging.
    """
    gate_pass = models.ForeignKey(
        GatePass,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='events',
        help_text="Associated gate pass if token was resolved"
    )
    student = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.CASCADE,
        related_name='gate_events',
        help_text="Student attempting movement"
    )
    security_officer = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name='recorded_gate_events',
        help_text="Officer stationed at checkpoint during event"
    )
    gate_type = models.CharField(
        max_length=50,
        help_text="Checkpoint gate location (e.g. 'College Main Gate', 'Hostel Gate #1')"
    )
    event_type = models.CharField(
        max_length=20,
        choices=EventType.choices,
        default=EventType.EXIT,
        help_text="Movement type: EXIT or ENTRY"
    )
    verification_outcome = models.CharField(
        max_length=30,
        choices=VerificationOutcome.choices,
        help_text="Security clearance decision"
    )
    remarks = models.TextField(
        blank=True,
        help_text="Officer notes or rejection reasoning"
    )
    timestamp = models.DateTimeField(
        auto_now_add=True,
        db_index=True,
        help_text="Immutable log timestamp"
    )

    class Meta:
        verbose_name = "Gate Event"
        verbose_name_plural = "Gate Events"
        ordering = ['-timestamp']
        indexes = [
            models.Index(fields=['event_type', 'timestamp'], name='idx_gateevent_type_ts'),
            models.Index(fields=['gate_pass', 'timestamp'], name='idx_gateevent_pass_ts'),
        ]

    def __str__(self):
        officer = self.security_officer.get_full_name() or self.security_officer.username
        pass_tag = self.gate_pass.pass_id if self.gate_pass else "Unknown Pass"
        return f"{self.timestamp.strftime('%Y-%m-%d %H:%M')} | {pass_tag} | {self.event_type} - {self.verification_outcome} by {officer}"
