"""
Comprehensive Automated Test Suite for CAMPUSORA Day 9:
Return Entry Verification, Overdue/Curfew Tracking, and PostgreSQL Audit History.
"""

from datetime import date, timedelta
from django.test import TestCase, override_settings
from django.utils import timezone
from django.core import mail
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient
from rest_framework import status

from accounts.models import Role, StudentProfile, WardenProfile
from leaves.models import LeaveApplication, LeaveType, LeaveStatus
from passes.models import (
    GatePass,
    GateEvent,
    GateType,
    PassStatus,
    EventType,
    VerificationOutcome,
)
from passes.utils import derive_pass_token, hash_token
from notifications.models import NotificationLog, NotificationType, DeliveryStatus
from notifications.sms import MockSMSProvider

User = get_user_model()


@override_settings(
    EMAIL_BACKEND='django.core.mail.backends.locmem.EmailBackend',
    SMS_PROVIDER='mock',
    HOSTEL_CURFEW_TIME='21:00'
)
class ReturnEntryAndOverdueTests(TestCase):
    def setUp(self):
        MockSMSProvider.reset()
        mail.outbox = []
        self.client = APIClient()

        # Student (Arjun - BH-2)
        self.student = User.objects.create_user(
            username='arjun_day9',
            password='StudentPassword123!',
            email='arjun.day9@campusora.edu',
            first_name='Arjun',
            last_name='Sharma',
            role=Role.STUDENT,
            department='Computer Science & Engineering'
        )
        self.student_profile = StudentProfile.objects.create(
            user=self.student,
            registration_number='2024CSE1084',
            department='Computer Science & Engineering',
            year=3,
            semester=6,
            section='A',
            room_number='BH-2, Room 405',
            hostel_block='BH-2',
            parent_name='Sunil Sharma',
            parent_email='parent.sharma@example.com',
            parent_phone='+919876500001'
        )

        # Security Officer
        self.security = User.objects.create_user(
            username='sec_vikram',
            password='SecurityPassword123!',
            role=Role.SECURITY,
            assigned_gate='College Main Gate'
        )

        # Wardens (BH-2 and GH-1)
        self.warden_bh2_user = User.objects.create_user(
            username='warden_bh2_day9',
            email='warden.bh2@campusora.edu',
            password='Password123!',
            role=Role.WARDEN
        )
        self.warden_bh2_profile = WardenProfile.objects.create(
            user=self.warden_bh2_user,
            employee_id='EMP-WRD-001',
            assigned_hostel='BH-2'
        )

        self.warden_gh1_user = User.objects.create_user(
            username='warden_gh1_day9',
            email='warden.gh1@campusora.edu',
            password='Password123!',
            role=Role.WARDEN
        )
        self.warden_gh1_profile = WardenProfile.objects.create(
            user=self.warden_gh1_user,
            employee_id='EMP-WRD-002',
            assigned_hostel='GH-1'
        )

    def _create_and_exit_pass(self, start_d=None, end_d=None, leave_type=LeaveType.HOSTEL_OUTPASS):
        """Helper to create an HOD-approved leave, active pass, and complete authorized departure."""
        today = timezone.localdate()
        s_date = start_d or today
        e_date = end_d or (today + timedelta(days=2))

        app = LeaveApplication.objects.create(
            student=self.student,
            leave_type=leave_type,
            start_date=s_date,
            end_date=e_date,
            reason='Family visit',
            status=LeaveStatus.HOD_APPROVED
        )

        now = timezone.now()
        gate_pass = GatePass.objects.create(
            leave_application=app,
            gate_type=GateType.BOTH,
            valid_from=now - timedelta(hours=2),
            valid_until=now + timedelta(days=2),
            status=PassStatus.ACTIVE
        )
        raw_token = derive_pass_token(gate_pass.pass_id, str(app.application_id))
        gate_pass.token_hash = hash_token(raw_token)
        gate_pass.save()

        # Confirm EXIT as security
        self.client.force_authenticate(user=self.security)
        with self.captureOnCommitCallbacks(execute=True):
            res_exit = self.client.post('/api/v1/gate-passes/confirm-exit/', {
                'token': raw_token,
                'remarks': 'Departure cleared at College Main Gate.'
            })
        self.assertEqual(res_exit.status_code, status.HTTP_200_OK)
        gate_pass.refresh_from_db()
        self.assertEqual(gate_pass.status, PassStatus.USED)
        self.assertIsNotNone(gate_pass.exit_recorded_at)

        # Clear outbox so return tests start fresh
        mail.outbox = []
        MockSMSProvider.reset()

        return gate_pass, raw_token

    def test_return_entry_verification_ready(self):
        """
        Scanning a USED pass for return entry verifies previous exit, shows photo and expected return time.
        """
        gate_pass, raw_token = self._create_and_exit_pass()

        self.client.force_authenticate(user=self.security)
        response = self.client.post('/api/v1/gate-passes/verify-return/', {
            'token': raw_token
        })
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue(response.data['valid'])
        self.assertEqual(response.data['mode'], 'ENTRY')
        self.assertEqual(response.data['status'], PassStatus.USED)
        self.assertEqual(response.data['student']['name'], 'Arjun Sharma')
        self.assertEqual(response.data['student']['registration_number'], '2024CSE1084')
        self.assertIn('photo_url', response.data)
        self.assertIn('exit_recorded_at', response.data)
        self.assertIn('expected_return_time', response.data)

    def test_return_entry_rejected_if_not_exited(self):
        """
        Scanning an ACTIVE pass (student never exited) rejects return entry with NOT_EXITED.
        """
        today = timezone.localdate()
        app = LeaveApplication.objects.create(
            student=self.student,
            leave_type=LeaveType.DAY_PASS,
            start_date=today,
            end_date=today,
            reason='Hospital visit',
            status=LeaveStatus.HOD_APPROVED
        )
        gate_pass = GatePass.objects.create(
            leave_application=app,
            gate_type=GateType.COLLEGE_MAIN_GATE,
            valid_from=timezone.now(),
            valid_until=timezone.now() + timedelta(hours=6),
            status=PassStatus.ACTIVE
        )
        raw_token = derive_pass_token(gate_pass.pass_id, str(app.application_id))
        gate_pass.token_hash = hash_token(raw_token)
        gate_pass.save()

        self.client.force_authenticate(user=self.security)
        response = self.client.post('/api/v1/gate-passes/verify-return/', {
            'token': raw_token
        })
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertFalse(response.data['valid'])
        self.assertEqual(response.data['outcome'], VerificationOutcome.NOT_EXITED)

    def test_confirm_return_entry_workflow_and_postgres_audit(self):
        """
        Confirming return entry:
        1. Transitions pass to RETURNED
        2. Sets entry_recorded_at
        3. Creates immutable GateEvent log with event_type = ENTRY
        4. Preserves previous EXIT GateEvent
        5. Dispatches parent return email & SMS and hostel warden return email
        """
        gate_pass, raw_token = self._create_and_exit_pass()

        self.client.force_authenticate(user=self.security)
        with self.captureOnCommitCallbacks(execute=True):
            response = self.client.post('/api/v1/gate-passes/confirm-return/', {
                'token': raw_token,
                'remarks': 'Face verified against terminal photo likeness. Bag checked.'
            })
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        gate_pass.refresh_from_db()
        self.assertEqual(gate_pass.status, PassStatus.RETURNED)
        self.assertIsNotNone(gate_pass.entry_recorded_at)

        # Verify GateEvent audit records in PostgreSQL
        events = GateEvent.objects.filter(gate_pass=gate_pass).order_by('timestamp')
        self.assertEqual(events.count(), 2)
        exit_event = events[0]
        entry_event = events[1]

        self.assertEqual(exit_event.event_type, EventType.EXIT)
        self.assertEqual(exit_event.verification_outcome, VerificationOutcome.SUCCESS)

        self.assertEqual(entry_event.event_type, EventType.ENTRY)
        self.assertEqual(entry_event.verification_outcome, VerificationOutcome.SUCCESS)
        self.assertEqual(entry_event.security_officer, self.security)
        self.assertIn("Face verified", entry_event.remarks)

        # Verify notifications dispatched
        # Expect 2 emails: 1 parent return email + 1 BH-2 warden return email
        self.assertEqual(len(mail.outbox), 2)
        recipients = [m.to[0] for m in mail.outbox]
        self.assertIn(self.student_profile.parent_email, recipients)
        self.assertIn(self.warden_bh2_user.email, recipients)
        self.assertNotIn(self.warden_gh1_user.email, recipients)

        # Expect 1 SMS dispatched to parent
        self.assertEqual(len(MockSMSProvider.sent_messages), 1)
        sms = MockSMSProvider.sent_messages[0]
        self.assertEqual(sms['to'], self.student_profile.parent_phone)
        self.assertIn("Arjun Sharma", sms['message'])
        self.assertIn("safely returned to campus", sms['message'])

        # Verify NotificationLog table
        log_email = NotificationLog.objects.filter(
            recipient_email=self.student_profile.parent_email,
            notification_type=NotificationType.PARENT_RETURN_ALERT
        ).first()
        self.assertIsNotNone(log_email)
        self.assertEqual(log_email.status, DeliveryStatus.SENT)

    def test_duplicate_return_entry_rejected(self):
        """
        Attempting to confirm return entry a second time on an already RETURNED pass is rejected.
        """
        gate_pass, raw_token = self._create_and_exit_pass()

        self.client.force_authenticate(user=self.security)
        with self.captureOnCommitCallbacks(execute=True):
            res1 = self.client.post('/api/v1/gate-passes/confirm-return/', {'token': raw_token})
        self.assertEqual(res1.status_code, status.HTTP_200_OK)

        # Second attempt
        with self.captureOnCommitCallbacks(execute=True):
            res2 = self.client.post('/api/v1/gate-passes/confirm-return/', {'token': raw_token})
        self.assertEqual(res2.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("already been recorded", res2.data['detail'])

        # Attempt to exit again with returned pass is also rejected
        res_reexit = self.client.post('/api/v1/gate-passes/confirm-exit/', {'token': raw_token})
        self.assertEqual(res_reexit.status_code, status.HTTP_400_BAD_REQUEST)

    def test_overdue_curfew_detection(self):
        """
        Tests overdue detection when student's expected return time was in the past.
        """
        # Create a pass where end_date was yesterday (past curfew)
        yesterday = timezone.localdate() - timedelta(days=1)
        gate_pass, raw_token = self._create_and_exit_pass(start_d=yesterday - timedelta(days=1), end_d=yesterday)

        # Pass is USED and past deadline -> is_overdue should be True
        self.assertTrue(gate_pass.is_overdue)

        # Check /api/v1/gate-passes/outside/ endpoint
        self.client.force_authenticate(user=self.security)
        res_outside = self.client.get('/api/v1/gate-passes/outside/?overdue=true')
        self.assertEqual(res_outside.status_code, status.HTTP_200_OK)
        self.assertEqual(res_outside.data['overdue_count'], 1)
        self.assertTrue(res_outside.data['results'][0]['is_overdue'])
        self.assertGreater(res_outside.data['results'][0]['minutes_overdue'], 0)

        # Now confirm return entry
        with self.captureOnCommitCallbacks(execute=True):
            res_return = self.client.post('/api/v1/gate-passes/confirm-return/', {'token': raw_token})
        self.assertEqual(res_return.status_code, status.HTTP_200_OK)
        self.assertTrue(res_return.data['is_overdue'])

        gate_pass.refresh_from_db()
        self.assertEqual(gate_pass.status, PassStatus.RETURNED)
        self.assertTrue(gate_pass.returned_overdue)

    def test_return_entry_invalid_token_rejected(self):
        """
        Supplying an invalid or forged clearance token to return verification is rejected.
        """
        self.client.force_authenticate(user=self.security)
        response = self.client.post('/api/v1/gate-passes/verify-return/', {
            'token': 'FORGED_INVALID_CLEARANCE_TOKEN_XYZ999'
        })
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertFalse(response.data['valid'])
        self.assertEqual(response.data['outcome'], VerificationOutcome.INVALID_TOKEN)

    def test_return_entry_wrong_gate_rejected(self):
        """
        If a pass is restricted to a specific gate, scanning at an unauthorized gate checkpoint is rejected.
        """
        # Create an exit pass explicitly bound only to Hostel Gate
        app = LeaveApplication.objects.create(
            student=self.student,
            leave_type=LeaveType.HOSTEL_OUTPASS,
            start_date=timezone.localdate(),
            end_date=timezone.localdate() + timedelta(days=1),
            reason='Hostel movement',
            status=LeaveStatus.HOD_APPROVED
        )
        gate_pass = GatePass.objects.create(
            leave_application=app,
            gate_type=GateType.HOSTEL_GATE,
            valid_from=timezone.now() - timedelta(hours=1),
            valid_until=timezone.now() + timedelta(days=1),
            status=PassStatus.USED,
            exit_recorded_at=timezone.now() - timedelta(hours=1)
        )
        raw_token = derive_pass_token(gate_pass.pass_id, str(app.application_id))
        gate_pass.token_hash = hash_token(raw_token)
        gate_pass.save()

        # Security is at 'College Main Gate', but pass is authorized only for 'Hostel Gate'
        self.client.force_authenticate(user=self.security)
        response = self.client.post('/api/v1/gate-passes/verify-return/', {
            'token': raw_token
        })
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertFalse(response.data['valid'])
        self.assertEqual(response.data['outcome'], VerificationOutcome.WRONG_GATE)

