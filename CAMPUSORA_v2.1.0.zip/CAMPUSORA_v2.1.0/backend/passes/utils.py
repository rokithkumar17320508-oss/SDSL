"""
Cryptographic Token Utilities and QR Barcode Generation for CAMPUSORA Gate Passes.
Uses Python's secrets module and SHA-256 hashing.
"""

import io
import json
import base64
import secrets
import hashlib
import hmac
from django.conf import settings
import qrcode
from qrcode.constants import ERROR_CORRECT_M


def generate_secure_token() -> str:
    """
    Generates a cryptographically strong, unguessable random token (32 bytes urlsafe).
    Never stored in plaintext in the database.
    """
    return secrets.token_urlsafe(32)


def derive_pass_token(pass_id: str, salt: str = '') -> str:
    """
    Deterministically derives an unguessable 256-bit token using HMAC-SHA256 with the server SECRET_KEY.
    Enables authorized pass views without storing plaintext in the database.
    """
    key = settings.SECRET_KEY.encode('utf-8')
    msg = f"campusora_gatepass_{pass_id}_{salt}".encode('utf-8')
    digest = hmac.new(key, msg, hashlib.sha256).digest()
    return base64.urlsafe_b64encode(digest).decode('utf-8').rstrip('=')


def hash_token(raw_token: str) -> str:
    """
    Computes standard SHA-256 hash of a raw token for safe database lookups.
    """
    cleaned = raw_token.strip()
    return hashlib.sha256(cleaned.encode('utf-8')).hexdigest()


def build_qr_payload(pass_id: str, raw_token: str) -> str:
    """
    Builds structured QR verification payload.
    Omits personal information, passwords, and JWTs.
    """
    return json.dumps({
        "system": "CAMPUSORA",
        "pass_id": pass_id,
        "token": raw_token
    })


def parse_qr_token(scanned_text: str) -> str:
    """
    Extracts the raw verification token from scanned QR text or manual input.
    Supports JSON payload, colon-delimited string, or raw token string.
    """
    text = (scanned_text or '').strip()
    if not text:
        return ""

    # Try parsing JSON
    try:
        data = json.loads(text)
        if isinstance(data, dict) and 'token' in data:
            return data['token'].strip()
    except (json.JSONDecodeError, TypeError):
        pass

    # Try colon-delimited format CAMPUSORA:<pass_id>:<token>
    if text.startswith('CAMPUSORA:') and text.count(':') >= 2:
        parts = text.split(':')
        return parts[-1].strip()

    # Raw token input fallback
    return text


def generate_qr_data_uri(qr_content: str) -> str:
    """
    Generates a base64 Data URI PNG for inline image rendering.
    """
    qr = qrcode.QRCode(
        version=1,
        error_correction=ERROR_CORRECT_M,
        box_size=8,
        border=2,
    )
    qr.add_data(qr_content)
    qr.make(fit=True)

    img = qr.make_image(fill_color="#1E293B", back_color="#FFFFFF")
    buffer = io.BytesIO()
    img.save(buffer, format="PNG")
    b64_str = base64.b64encode(buffer.getvalue()).decode('utf-8')
    return f"data:image/png;base64,{b64_str}"
