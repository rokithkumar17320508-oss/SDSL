from django.urls import path
from .views import (
    GatePassListView,
    ActiveGatePassView,
    GatePassGenerateView,
    GatePassVerifyView,
    GatePassVerifyReturnView,
    GatePassConfirmExitView,
    GatePassConfirmReturnView,
    GatePassDenyExitView,
    ActiveOutsideStudentsView,
    GateEventListView,
)

urlpatterns = [
    path('gate-passes/', GatePassListView.as_view(), name='gate-pass-list'),
    path('gate-passes/active/', ActiveGatePassView.as_view(), name='active-gate-pass'),
    path('gate-passes/generate/', GatePassGenerateView.as_view(), name='gate-pass-generate'),
    path('gate-passes/verify/', GatePassVerifyView.as_view(), name='gate-pass-verify'),
    path('gate-passes/verify-return/', GatePassVerifyReturnView.as_view(), name='gate-pass-verify-return'),
    path('gate-passes/confirm-exit/', GatePassConfirmExitView.as_view(), name='gate-pass-confirm-exit'),
    path('gate-passes/confirm-return/', GatePassConfirmReturnView.as_view(), name='gate-pass-confirm-return'),
    path('gate-passes/outside/', ActiveOutsideStudentsView.as_view(), name='gate-pass-outside'),
    path('gate-passes/deny-exit/', GatePassDenyExitView.as_view(), name='gate-pass-deny-exit'),
    path('gate-events/', GateEventListView.as_view(), name='gate-event-list'),
]
