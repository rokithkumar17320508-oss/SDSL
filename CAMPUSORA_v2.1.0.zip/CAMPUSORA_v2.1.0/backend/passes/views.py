"""
API Views for Secure QR Gate-Pass Generation, Verification, and Exit Logging.
Strictly enforces RBAC and atomic row-locked exit confirmations.
"""

from datetime import datetime, time
from django.utils import timezone
from django.db import transaction
from rest_framework import status, permissions
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.generics import ListAPIView
from .models import (
    GatePass,
    GateEvent,
    GateType,
    PassStatus,
    EventType,
    VerificationOutcome,
)
from .serializers import GatePassSerializer, GateEventSerializer
from .utils import (
    generate_secure_token,
    derive_pass_token,
    hash_token,
    parse_qr_token,
)
from accounts.models import Role
from leaves.models import LeaveApplication, LeaveStatus, LeaveType
from notifications.services import notify_gate_exit
from config.throttling import GatePassVerifyThrottle


class GatePassListView(ListAPIView):
    """
    List gate passes.
    - Students see only their own gate passes.
    - Security / HOD / Admin see all gate passes.
    """
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = GatePassSerializer

    def get_queryset(self):
        user = self.request.user
        if user.role == Role.STUDENT:
            return GatePass.objects.filter(
                leave_application__student=user
            ).select_related('leave_application', 'leave_application__student')
        elif user.role in [Role.SECURITY, Role.HOD] or user.is_staff or user.is_superuser:
            return GatePass.objects.all().select_related(
                'leave_application', 'leave_application__student'
            )
        return GatePass.objects.none()


class ActiveGatePassView(APIView):
    """
    Retrieves or auto-generates the current active gate pass for the authenticated student.
    Returns status: 'ACTIVE', 'USED', 'EXPIRED', 'PENDING', or 'NONE'.
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        user = request.user
        if user.role != Role.STUDENT:
            return Response(
                {"detail": "Only students have personal gate passes."},
                status=status.HTTP_403_FORBIDDEN
            )

        # 1. Look for existing gate pass for the student's active/current approved leave
        today = timezone.localdate()
        approved_apps = LeaveApplication.objects.filter(
            student=user,
            status=LeaveStatus.HOD_APPROVED,
            end_date__gte=today
        ).order_by('start_date', '-created_at')

        # Prioritize leave applications that have an ACTIVE or unissued gate pass
        active_app = None
        for app in approved_apps:
            gp = getattr(app, 'gate_pass', None)
            if not gp or gp.status == PassStatus.ACTIVE:
                active_app = app
                break

        latest_approved = active_app or approved_apps.first()
        if not latest_approved:
            # Fallback to any latest approved (e.g. to display expired/used pass)
            latest_approved = LeaveApplication.objects.filter(
                student=user,
                status=LeaveStatus.HOD_APPROVED
            ).order_by('-created_at').first()

        if latest_approved:
            # Check if GatePass already exists
            gate_pass = getattr(latest_approved, 'gate_pass', None)
            if not gate_pass:
                # Determine gate type
                if latest_approved.leave_type == LeaveType.HOSTEL_OUTPASS:
                    g_type = GateType.BOTH
                elif hasattr(user, 'student_profile') and user.student_profile.room_number and latest_approved.leave_type == LeaveType.REGULAR_LEAVE:
                    g_type = GateType.BOTH
                else:
                    g_type = GateType.COLLEGE_MAIN_GATE

                valid_from = timezone.make_aware(datetime.combine(latest_approved.start_date, time.min))
                valid_until = timezone.make_aware(datetime.combine(latest_approved.end_date, time(23, 59, 59)))

                gate_pass = GatePass(
                    leave_application=latest_approved,
                    gate_type=g_type,
                    token_hash="",
                    valid_from=valid_from,
                    valid_until=valid_until,
                    status=PassStatus.ACTIVE
                )
                gate_pass.save()

                active_token = derive_pass_token(gate_pass.pass_id, str(latest_approved.application_id))
                gate_pass.token_hash = hash_token(active_token)
                gate_pass.save(update_fields=['token_hash'])
            else:
                active_token = derive_pass_token(gate_pass.pass_id, str(gate_pass.leave_application.application_id))
                expected_hash = hash_token(active_token)
                if gate_pass.token_hash != expected_hash and gate_pass.status == PassStatus.ACTIVE:
                    gate_pass.token_hash = expected_hash
                    gate_pass.save(update_fields=['token_hash'])

            # Check expiration dynamically
            if gate_pass.status == PassStatus.ACTIVE and gate_pass.is_expired:
                gate_pass.status = PassStatus.EXPIRED
                gate_pass.save(update_fields=['status'])

            serializer = GatePassSerializer(gate_pass, context={'raw_token': active_token, 'request': request})
            return Response(serializer.data, status=status.HTTP_200_OK)

        # 2. Check for pending leave applications
        pending_app = LeaveApplication.objects.filter(
            student=user,
            status__in=[LeaveStatus.PENDING_FACULTY, LeaveStatus.PENDING_HOD]
        ).order_by('-created_at').first()

        if pending_app:
            return Response({
                "status": "PENDING",
                "message": f"Leave application {pending_app.application_id} ({pending_app.leave_type}) is awaiting college authorization. Gate pass will become active once HOD grants approval.",
                "application_id": pending_app.application_id,
                "leave_type": pending_app.leave_type,
                "leave_status": pending_app.status,
            }, status=status.HTTP_200_OK)

        # 3. Check for recently rejected application
        rejected_app = LeaveApplication.objects.filter(
            student=user,
            status=LeaveStatus.REJECTED
        ).order_by('-created_at').first()

        if rejected_app:
            return Response({
                "status": "REJECTED",
                "message": f"Your leave request {rejected_app.application_id} was rejected ({rejected_app.rejection_reason or 'Policy criteria not met'}). No gate clearance pass available.",
                "application_id": rejected_app.application_id,
                "leave_type": rejected_app.leave_type,
            }, status=status.HTTP_200_OK)

        return Response({
            "status": "NONE",
            "message": "No active or approved leave application found. Please apply for leave before requesting a gate pass."
        }, status=status.HTTP_200_OK)


class GatePassGenerateView(APIView):
    """
    Explicit pass generation endpoint:
    POST /api/v1/gate-passes/generate/
    Accepts: { "application_id": "APP-XXXX" }
    - Requires HOD Approved leave application
    - Binds token hash in database and returns raw token/QR to the caller
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        user = request.user
        app_id = request.data.get('application_id')
        if not app_id:
            return Response(
                {"detail": "application_id parameter is required."},
                status=status.HTTP_400_BAD_REQUEST
            )

        app = LeaveApplication.objects.filter(application_id=app_id).first()
        if not app:
            return Response(
                {"detail": "Leave application not found."},
                status=status.HTTP_404_NOT_FOUND
            )

        # Ownership / staff authorization
        if user.role == Role.STUDENT and app.student != user:
            return Response(
                {"detail": "You are not authorized to generate a gate pass for another student."},
                status=status.HTTP_403_FORBIDDEN
            )

        # Workflow validation: only HOD approved leave can produce a pass
        if app.status != LeaveStatus.HOD_APPROVED:
            return Response(
                {"detail": f"Gate pass can only be generated for HOD-approved leave applications (Current status: {app.status})."},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Check existing gate pass
        gate_pass = getattr(app, 'gate_pass', None)

        if not gate_pass:
            if app.leave_type == LeaveType.HOSTEL_OUTPASS:
                g_type = GateType.BOTH
            elif hasattr(app.student, 'student_profile') and app.student.student_profile.room_number and app.leave_type == LeaveType.REGULAR_LEAVE:
                g_type = GateType.BOTH
            else:
                g_type = GateType.COLLEGE_MAIN_GATE

            valid_from = timezone.make_aware(datetime.combine(app.start_date, time.min))
            valid_until = timezone.make_aware(datetime.combine(app.end_date, time(23, 59, 59)))

            gate_pass = GatePass(
                leave_application=app,
                gate_type=g_type,
                token_hash="",
                valid_from=valid_from,
                valid_until=valid_until,
                status=PassStatus.ACTIVE
            )
            gate_pass.save()

        raw_token = derive_pass_token(gate_pass.pass_id, str(app.application_id))
        gate_pass.token_hash = hash_token(raw_token)
        gate_pass.save(update_fields=['token_hash'])

        serializer = GatePassSerializer(gate_pass, context={'raw_token': raw_token, 'request': request})
        return Response(serializer.data, status=status.HTTP_201_CREATED)


class GatePassVerifyView(APIView):
    """
    Security verification endpoint:
    POST /api/v1/gate-passes/verify/
    Accepts: { "token": "..." } or { "qr_data": "..." }
    - Restricted to Security personnel only
    - Validates token hash, status, expiration, and authorized gate
    - DOES NOT consume the pass (inspection only)
    - Logs failed attempts
    """
    permission_classes = [permissions.IsAuthenticated]
    throttle_classes = [GatePassVerifyThrottle]

    def post(self, request):
        user = request.user
        if user.role != Role.SECURITY and not (user.is_staff or user.is_superuser):
            return Response(
                {"detail": "Only security personnel are authorized to verify gate passes."},
                status=status.HTTP_403_FORBIDDEN
            )

        raw_input = request.data.get('token') or request.data.get('qr_data') or ''
        token = parse_qr_token(raw_input)
        if not token:
            return Response(
                {"valid": False, "outcome": VerificationOutcome.INVALID_TOKEN, "detail": "Verification token is required."},
                status=status.HTTP_400_BAD_REQUEST
            )

        token_h = hash_token(token)
        gate_pass = GatePass.objects.select_related(
            'leave_application', 'leave_application__student'
        ).filter(token_hash=token_h).first()

        officer_gate = user.assigned_gate or 'College Main Gate'

        # 1. Token existence check
        if not gate_pass:
            GateEvent.objects.create(
                gate_pass=None,
                student=None,
                security_officer=user,
                gate_type=officer_gate,
                event_type=EventType.EXIT,
                verification_outcome=VerificationOutcome.INVALID_TOKEN,
                remarks="Unrecognized or forged QR token presented at checkpoint."
            )
            return Response({
                "valid": False,
                "outcome": VerificationOutcome.INVALID_TOKEN,
                "detail": "Invalid or unrecognized QR clearance token."
            }, status=status.HTTP_400_BAD_REQUEST)

        student = gate_pass.leave_application.student

        # 2. Leave Application Status Check
        if gate_pass.leave_application.status != LeaveStatus.HOD_APPROVED:
            GateEvent.objects.create(
                gate_pass=gate_pass,
                student=student,
                security_officer=user,
                gate_type=officer_gate,
                event_type=EventType.EXIT,
                verification_outcome=VerificationOutcome.DENIED,
                remarks=f"Underlying leave application is not HOD-approved (status: {gate_pass.leave_application.status})."
            )
            return Response({
                "valid": False,
                "outcome": VerificationOutcome.DENIED,
                "detail": "Underlying leave authorization is not active or approved."
            }, status=status.HTTP_400_BAD_REQUEST)

        # 3. Revoked Status Check
        if gate_pass.status == PassStatus.REVOKED:
            GateEvent.objects.create(
                gate_pass=gate_pass,
                student=student,
                security_officer=user,
                gate_type=officer_gate,
                event_type=EventType.EXIT,
                verification_outcome=VerificationOutcome.REVOKED,
                remarks="Revoked gate pass presented."
            )
            return Response({
                "valid": False,
                "outcome": VerificationOutcome.REVOKED,
                "detail": "This gate pass has been revoked by institutional administration."
            }, status=status.HTTP_400_BAD_REQUEST)

        # Check Verification Mode: 'exit' (default) vs 'entry' / 'return'
        mode = (request.data.get('mode') or 'exit').strip().lower()

        if mode in ['entry', 'return']:
            # Return Entry Verification
            if gate_pass.status == PassStatus.RETURNED:
                entry_time_str = gate_pass.entry_recorded_at.strftime('%Y-%m-%d %H:%M') if gate_pass.entry_recorded_at else 'earlier'
                return Response({
                    "valid": False,
                    "mode": "ENTRY",
                    "outcome": VerificationOutcome.ALREADY_RETURNED,
                    "detail": f"This pass has already been processed for return entry at {entry_time_str} and cannot be reused."
                }, status=status.HTTP_400_BAD_REQUEST)

            if gate_pass.status == PassStatus.ACTIVE:
                return Response({
                    "valid": False,
                    "mode": "ENTRY",
                    "outcome": VerificationOutcome.NOT_EXITED,
                    "detail": "Student has not yet completed an authorized exit. Departure confirmation is required before return entry can be verified."
                }, status=status.HTTP_400_BAD_REQUEST)

            if gate_pass.status != PassStatus.USED:
                return Response({
                    "valid": False,
                    "mode": "ENTRY",
                    "outcome": VerificationOutcome.DENIED,
                    "detail": f"Gate pass status '{gate_pass.status}' is not eligible for return entry."
                }, status=status.HTTP_400_BAD_REQUEST)

            # Checkpoint Gate Authorization Check
            if not gate_pass.is_valid_for_gate(officer_gate):
                return Response({
                    "valid": False,
                    "mode": "ENTRY",
                    "outcome": VerificationOutcome.WRONG_GATE,
                    "detail": f"Wrong gate: This pass authorizes movement via '{gate_pass.gate_type}', but terminal is '{officer_gate}'."
                }, status=status.HTTP_400_BAD_REQUEST)

            # Valid for Return Entry
            reg_no = student.student_profile.registration_number if hasattr(student, 'student_profile') else student.username
            room_no = student.student_profile.room_number if hasattr(student, 'student_profile') else ''
            hostel_block = student.student_profile.hostel_block if hasattr(student, 'student_profile') else ''
            exp_ret = gate_pass.expected_return_time

            return Response({
                "valid": True,
                "mode": "ENTRY",
                "outcome": VerificationOutcome.SUCCESS,
                "pass_id": gate_pass.pass_id,
                "application_id": gate_pass.leave_application.application_id,
                "student": {
                    "id": student.id,
                    "name": student.get_full_name() or student.username,
                    "registration_number": reg_no,
                    "department": student.department,
                    "room_number": room_no,
                    "hostel_block": hostel_block,
                    "phone": student.phone_number,
                },
                "leave_type": gate_pass.leave_application.leave_type,
                "reason": gate_pass.leave_application.reason,
                "authorized_gate": gate_pass.gate_type,
                "exit_recorded_at": gate_pass.exit_recorded_at.isoformat() if gate_pass.exit_recorded_at else None,
                "expected_return_time": exp_ret.isoformat() if exp_ret else None,
                "is_overdue": gate_pass.is_overdue,
                "status": gate_pass.status,
                "officer_terminal_gate": officer_gate,
                "photo_url": f"/photos/students/{student.username}.jpg",
                "token": token,
            }, status=status.HTTP_200_OK)

        # Mode is EXIT
        # 4a. Check if already returned
        if gate_pass.status == PassStatus.RETURNED:
            entry_time_str = gate_pass.entry_recorded_at.strftime('%Y-%m-%d %H:%M') if gate_pass.entry_recorded_at else 'earlier'
            return Response({
                "valid": False,
                "outcome": VerificationOutcome.ALREADY_RETURNED,
                "detail": f"This pass has already completed both exit and return entry (returned at {entry_time_str})."
            }, status=status.HTTP_400_BAD_REQUEST)

        # 4b. Already Used Check (for Departure)
        if gate_pass.status == PassStatus.USED:
            exit_time_str = gate_pass.exit_recorded_at.strftime('%Y-%m-%d %H:%M') if gate_pass.exit_recorded_at else 'earlier'
            GateEvent.objects.create(
                gate_pass=gate_pass,
                student=student,
                security_officer=user,
                gate_type=officer_gate,
                event_type=EventType.EXIT,
                verification_outcome=VerificationOutcome.ALREADY_USED,
                remarks=f"Replay attempt: pass previously exited at {exit_time_str}."
            )
            return Response({
                "valid": False,
                "outcome": VerificationOutcome.ALREADY_USED,
                "detail": f"This pass has already been used for campus exit at {exit_time_str} and cannot be reused."
            }, status=status.HTTP_400_BAD_REQUEST)

        # 5. Expiration Check
        if gate_pass.is_expired:
            gate_pass.status = PassStatus.EXPIRED
            gate_pass.save(update_fields=['status'])
            GateEvent.objects.create(
                gate_pass=gate_pass,
                student=student,
                security_officer=user,
                gate_type=officer_gate,
                event_type=EventType.EXIT,
                verification_outcome=VerificationOutcome.EXPIRED,
                remarks="Pass clearance window expired."
            )
            return Response({
                "valid": False,
                "outcome": VerificationOutcome.EXPIRED,
                "detail": f"Gate pass clearance expired on {gate_pass.valid_until.strftime('%Y-%m-%d %H:%M')}."
            }, status=status.HTTP_400_BAD_REQUEST)

        # 6. Checkpoint Gate Authorization Check
        if not gate_pass.is_valid_for_gate(officer_gate):
            GateEvent.objects.create(
                gate_pass=gate_pass,
                student=student,
                security_officer=user,
                gate_type=officer_gate,
                event_type=EventType.EXIT,
                verification_outcome=VerificationOutcome.WRONG_GATE,
                remarks=f"Pass authorized for {gate_pass.gate_type}; attempted at {officer_gate}."
            )
            return Response({
                "valid": False,
                "outcome": VerificationOutcome.WRONG_GATE,
                "detail": f"Wrong gate: This pass authorizes exit via '{gate_pass.gate_type}', but terminal is '{officer_gate}'."
            }, status=status.HTTP_400_BAD_REQUEST)

        # Valid Pass: return student identity for visual officer confirmation
        reg_no = student.student_profile.registration_number if hasattr(student, 'student_profile') else student.username
        room_no = student.student_profile.room_number if hasattr(student, 'student_profile') else ''

        return Response({
            "valid": True,
            "outcome": VerificationOutcome.SUCCESS,
            "pass_id": gate_pass.pass_id,
            "application_id": gate_pass.leave_application.application_id,
            "student": {
                "id": student.id,
                "name": student.get_full_name() or student.username,
                "registration_number": reg_no,
                "department": student.department,
                "room_number": room_no,
                "phone": student.phone_number,
            },
            "leave_type": gate_pass.leave_application.leave_type,
            "reason": gate_pass.leave_application.reason,
            "authorized_gate": gate_pass.gate_type,
            "valid_from": gate_pass.valid_from,
            "valid_until": gate_pass.valid_until,
            "status": gate_pass.status,
            "officer_terminal_gate": officer_gate,
            "token": token,
        }, status=status.HTTP_200_OK)


class GatePassConfirmExitView(APIView):
    """
    Atomic exit confirmation endpoint:
    POST /api/v1/gate-passes/confirm-exit/
    Accepts: { "token": "...", "remarks": "..." }
    - Row-locked with select_for_update() inside transaction.atomic()
    - Marks status = USED and saves exit timestamp
    - Creates immutable GateEvent log
    - Guarantees single-use: concurrent or repeat requests are rejected
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        user = request.user
        if user.role != Role.SECURITY and not (user.is_staff or user.is_superuser):
            return Response(
                {"detail": "Only security personnel are authorized to confirm gate exits."},
                status=status.HTTP_403_FORBIDDEN
            )

        raw_input = request.data.get('token') or request.data.get('qr_data') or ''
        token = parse_qr_token(raw_input)
        if not token:
            return Response(
                {"detail": "Verification token is required to confirm exit."},
                status=status.HTTP_400_BAD_REQUEST
            )

        token_h = hash_token(token)
        officer_gate = user.assigned_gate or 'College Main Gate'
        remarks = (request.data.get('remarks') or '').strip()

        with transaction.atomic():
            gate_pass = GatePass.objects.select_for_update().select_related(
                'leave_application', 'leave_application__student'
            ).filter(token_hash=token_h).first()

            if not gate_pass:
                return Response(
                    {"detail": "Gate pass not found for the supplied token."},
                    status=status.HTTP_404_NOT_FOUND
                )

            # Re-validate state under row-level lock
            if gate_pass.status == PassStatus.RETURNED:
                return Response(
                    {"detail": "This gate pass has already completed return entry and cannot be reused for exit."},
                    status=status.HTTP_400_BAD_REQUEST
                )

            if gate_pass.status == PassStatus.USED:
                return Response(
                    {"detail": "This gate pass has already been used and cannot be reused."},
                    status=status.HTTP_400_BAD_REQUEST
                )

            if gate_pass.status == PassStatus.REVOKED:
                return Response(
                    {"detail": "This gate pass has been revoked."},
                    status=status.HTTP_400_BAD_REQUEST
                )

            if gate_pass.is_expired:
                gate_pass.status = PassStatus.EXPIRED
                gate_pass.save(update_fields=['status'])
                return Response(
                    {"detail": "Gate pass clearance has expired."},
                    status=status.HTTP_400_BAD_REQUEST
                )

            if not gate_pass.is_valid_for_gate(officer_gate):
                return Response(
                    {"detail": f"Wrong gate checkpoint: Pass not authorized for {officer_gate}."},
                    status=status.HTTP_400_BAD_REQUEST
                )

            # Atomic status update
            now = timezone.now()
            gate_pass.status = PassStatus.USED
            gate_pass.exit_recorded_at = now
            gate_pass.save(update_fields=['status', 'exit_recorded_at'])

            # Log exit event in PostgreSQL
            event_remarks = remarks or f"Departure cleared at {officer_gate} by {user.get_full_name() or user.username}."
            event = GateEvent.objects.create(
                gate_pass=gate_pass,
                student=gate_pass.leave_application.student,
                security_officer=user,
                gate_type=officer_gate,
                event_type=EventType.EXIT,
                verification_outcome=VerificationOutcome.SUCCESS,
                remarks=event_remarks
            )

            # Trigger automated parent departure alerts (Email + SMS) & hostel warden alert
            notify_gate_exit(event)

            return Response({
                "detail": "Exit confirmed successfully.",
                "pass_id": gate_pass.pass_id,
                "status": gate_pass.status,
                "exit_recorded_at": now.isoformat(),
                "event_id": event.id,
                "officer_gate": officer_gate,
            }, status=status.HTTP_200_OK)


class GatePassDenyExitView(APIView):
    """
    Officer denial endpoint:
    POST /api/v1/gate-passes/deny-exit/
    Accepts: { "token": "...", "reason": "..." }
    - Logs DENIED gate event
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        user = request.user
        if user.role != Role.SECURITY and not (user.is_staff or user.is_superuser):
            return Response(
                {"detail": "Only security personnel can record gate denials."},
                status=status.HTTP_403_FORBIDDEN
            )

        token = parse_qr_token(request.data.get('token') or '')
        reason = (request.data.get('reason') or request.data.get('remarks') or '').strip()
        if not reason:
            return Response(
                {"detail": "Reason for denial is mandatory."},
                status=status.HTTP_400_BAD_REQUEST
            )

        officer_gate = user.assigned_gate or 'College Main Gate'
        gate_pass = None
        student = None
        if token:
            token_h = hash_token(token)
            gate_pass = GatePass.objects.filter(token_hash=token_h).first()
            if gate_pass:
                student = gate_pass.leave_application.student

        GateEvent.objects.create(
            gate_pass=gate_pass,
            student=student,
            security_officer=user,
            gate_type=officer_gate,
            event_type=EventType.EXIT,
            verification_outcome=VerificationOutcome.DENIED,
            remarks=reason
        )

        return Response({
            "detail": "Gate departure clearance denied and recorded in security audit log."
        }, status=status.HTTP_200_OK)


class GatePassVerifyReturnView(APIView):
    """
    Dedicated return entry verification endpoint:
    POST /api/v1/gate-passes/verify-return/
    Accepts: { "token": "..." } or { "qr_data": "..." }
    - Verifies student has completed an authorized exit (status is USED)
    - Compares current time with expected return deadline (overdue detection)
    - Returns student details, photograph, exit timestamp, expected return time
    """
    permission_classes = [permissions.IsAuthenticated]
    throttle_classes = [GatePassVerifyThrottle]

    def post(self, request):
        data = request.data.copy() if hasattr(request.data, 'copy') else dict(request.data)
        data['mode'] = 'entry'
        request._full_data = data
        return GatePassVerifyView().post(request)


class GatePassConfirmReturnView(APIView):
    """
    Atomic return entry confirmation endpoint:
    POST /api/v1/gate-passes/confirm-return/
    Accepts: { "token": "...", "remarks": "..." }
    - Row-locked with select_for_update() inside transaction.atomic()
    - Verifies pass is currently USED
    - Transitions status = RETURNED and saves entry_recorded_at timestamp
    - Creates immutable GateEvent log with event_type = ENTRY
    - Detects whether return was overdue
    - Triggers parent and warden return notifications
    - Guarantees single-use return: duplicate return attempts are rejected
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        user = request.user
        if user.role != Role.SECURITY and not (user.is_staff or user.is_superuser):
            return Response(
                {"detail": "Only security personnel are authorized to confirm return entry."},
                status=status.HTTP_403_FORBIDDEN
            )

        raw_input = request.data.get('token') or request.data.get('qr_data') or ''
        token = parse_qr_token(raw_input)
        if not token:
            return Response(
                {"detail": "Verification token is required to confirm return entry."},
                status=status.HTTP_400_BAD_REQUEST
            )

        token_h = hash_token(token)
        officer_gate = user.assigned_gate or 'College Main Gate'
        remarks = (request.data.get('remarks') or '').strip()

        with transaction.atomic():
            gate_pass = GatePass.objects.select_for_update().select_related(
                'leave_application', 'leave_application__student'
            ).filter(token_hash=token_h).first()

            if not gate_pass:
                return Response(
                    {"detail": "Gate pass not found for the supplied token."},
                    status=status.HTTP_404_NOT_FOUND
                )

            # Prevent duplicate return confirmations
            if gate_pass.status == PassStatus.RETURNED:
                entry_time_str = gate_pass.entry_recorded_at.strftime('%Y-%m-%d %H:%M') if gate_pass.entry_recorded_at else 'earlier'
                return Response(
                    {"detail": f"Return entry has already been recorded for this gate pass at {entry_time_str}."},
                    status=status.HTTP_400_BAD_REQUEST
                )

            # Must have previously completed an authorized exit
            if gate_pass.status != PassStatus.USED:
                return Response(
                    {"detail": f"Cannot confirm return entry: student has not completed an authorized departure (current status: {gate_pass.status})."},
                    status=status.HTTP_400_BAD_REQUEST
                )

            if gate_pass.status == PassStatus.REVOKED:
                return Response(
                    {"detail": "This gate pass has been revoked."},
                    status=status.HTTP_400_BAD_REQUEST
                )

            if not gate_pass.is_valid_for_gate(officer_gate):
                return Response(
                    {"detail": f"Wrong gate checkpoint: Pass not authorized for {officer_gate}."},
                    status=status.HTTP_400_BAD_REQUEST
                )

            # Atomic status update to RETURNED
            now = timezone.now()
            gate_pass.status = PassStatus.RETURNED
            gate_pass.entry_recorded_at = now
            gate_pass.save(update_fields=['status', 'entry_recorded_at'])

            # Determine if student returned overdue
            was_overdue = gate_pass.returned_overdue
            overdue_note = " (RETURNED OVERDUE - PAST CURFEW)" if was_overdue else ""

            # Log ENTRY event in PostgreSQL
            event_remarks = remarks or f"Return entry cleared at {officer_gate} by {user.get_full_name() or user.username}{overdue_note}."
            event = GateEvent.objects.create(
                gate_pass=gate_pass,
                student=gate_pass.leave_application.student,
                security_officer=user,
                gate_type=officer_gate,
                event_type=EventType.ENTRY,
                verification_outcome=VerificationOutcome.SUCCESS,
                remarks=event_remarks
            )

            # Trigger automated parent & warden return notifications
            try:
                from notifications.services import notify_gate_return
                notify_gate_return(event)
            except Exception:
                pass

            student = gate_pass.leave_application.student
            reg_no = student.student_profile.registration_number if hasattr(student, 'student_profile') else student.username

            return Response({
                "detail": "Return entry confirmed successfully.",
                "pass_id": gate_pass.pass_id,
                "status": gate_pass.status,
                "entry_recorded_at": now.isoformat(),
                "exit_recorded_at": gate_pass.exit_recorded_at.isoformat() if gate_pass.exit_recorded_at else None,
                "expected_return_time": gate_pass.expected_return_time.isoformat() if gate_pass.expected_return_time else None,
                "is_overdue": was_overdue,
                "event_id": event.id,
                "officer_gate": officer_gate,
                "student": {
                    "name": student.get_full_name() or student.username,
                    "registration_number": reg_no,
                    "department": student.department,
                }
            }, status=status.HTTP_200_OK)


class ActiveOutsideStudentsView(APIView):
    """
    Overdue & active outside student monitoring endpoint:
    GET /api/v1/gate-passes/outside/
    Lists students who have departed (status = USED) and not yet returned.
    Query params:
    - overdue=true: returns only overdue students
    - department=...: filter by department
    - hostel_block=...: filter by residential block
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        user = request.user
        from django.db.models import Q
        qs = GatePass.objects.filter(status=PassStatus.USED).select_related(
            'leave_application', 'leave_application__student', 'leave_application__student__student_profile'
        )

        # Role-based restriction
        if user.role == Role.FACULTY:
            qs = qs.filter(
                Q(leave_application__student__student_profile__advisor=user) |
                Q(leave_application__student__department=user.department)
            ).distinct()
        elif user.role == Role.HOD:
            if not (user.is_superuser or user.department == 'Administration'):
                qs = qs.filter(leave_application__student__department=user.department)
        elif user.role == Role.STUDENT:
            qs = qs.filter(leave_application__student=user)
        # Security, admin, staff see all

        dept = request.query_params.get('department')
        if dept:
            qs = qs.filter(leave_application__student__department=dept)

        hostel_block = request.query_params.get('hostel_block')
        if hostel_block:
            qs = qs.filter(leave_application__student__student_profile__hostel_block__iexact=hostel_block)

        overdue_only = request.query_params.get('overdue', '').lower() in ('true', '1', 'yes')

        now = timezone.now()
        results = []
        for gp in qs.order_by('exit_recorded_at'):
            is_overdue = gp.is_overdue
            if overdue_only and not is_overdue:
                continue

            student = gp.leave_application.student
            sp = getattr(student, 'student_profile', None)
            deadline = gp.expected_return_time
            minutes_diff = int((now - deadline).total_seconds() / 60) if (is_overdue and deadline) else 0

            results.append({
                "pass_id": gp.pass_id,
                "application_id": gp.leave_application.application_id,
                "student_name": student.get_full_name() or student.username,
                "registration_number": sp.registration_number if sp else 'N/A',
                "department": student.department,
                "hostel_block": sp.hostel_block if sp else '',
                "room_number": sp.room_number if sp else '',
                "parent_name": sp.parent_name if sp else '',
                "parent_phone": sp.parent_phone if sp else '',
                "leave_type": gp.leave_application.leave_type,
                "gate_type": gp.gate_type,
                "status": gp.status,
                "exit_recorded_at": gp.exit_recorded_at.isoformat() if gp.exit_recorded_at else None,
                "expected_return_time": deadline.isoformat() if deadline else None,
                "is_overdue": is_overdue,
                "minutes_overdue": max(0, minutes_diff),
                "photo_url": f"/photos/students/{student.username}.jpg",
            })

        return Response({
            "count": len(results),
            "overdue_count": sum(1 for r in results if r['is_overdue']),
            "results": results,
        }, status=status.HTTP_200_OK)


class GateEventListView(ListAPIView):
    """
    Activity history endpoint:
    GET /api/v1/gate-events/
    - Lists recent gate events for Security and Admin
    """
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = GateEventSerializer

    def get_queryset(self):
        user = self.request.user
        if user.role != Role.SECURITY and not (user.is_staff or user.is_superuser):
            return GateEvent.objects.none()

        return GateEvent.objects.select_related(
            'gate_pass', 'student', 'student__student_profile', 'security_officer'
        ).all()[:100]
