"""
Serializers for CAMPUSORA Gate Passes and Checkpoint Events.
Omits raw token hashes from client responses.
"""

from rest_framework import serializers
from .models import GatePass, GateEvent, PassStatus
from .utils import build_qr_payload, generate_qr_data_uri


class GatePassSerializer(serializers.ModelSerializer):
    id = serializers.CharField(source='pass_id', read_only=True)
    application_id = serializers.CharField(source='leave_application.application_id', read_only=True)
    student_name = serializers.SerializerMethodField()
    student_registration = serializers.SerializerMethodField()
    department = serializers.SerializerMethodField()
    leave_type = serializers.CharField(source='leave_application.leave_type', read_only=True)
    start_date = serializers.DateField(source='leave_application.start_date', read_only=True)
    end_date = serializers.DateField(source='leave_application.end_date', read_only=True)
    reason = serializers.CharField(source='leave_application.reason', read_only=True)
    is_expired = serializers.BooleanField(read_only=True)
    is_overdue = serializers.BooleanField(read_only=True)
    returned_overdue = serializers.BooleanField(read_only=True)
    is_returned = serializers.BooleanField(read_only=True)
    expected_return_time = serializers.DateTimeField(read_only=True)
    room_number = serializers.SerializerMethodField()
    hostel_block = serializers.SerializerMethodField()
    photo_url = serializers.SerializerMethodField()
    qr_code_image = serializers.SerializerMethodField()
    raw_token = serializers.SerializerMethodField()

    class Meta:
        model = GatePass
        fields = [
            'id',
            'pass_id',
            'application_id',
            'student_name',
            'student_registration',
            'department',
            'room_number',
            'hostel_block',
            'photo_url',
            'leave_type',
            'start_date',
            'end_date',
            'reason',
            'gate_type',
            'status',
            'valid_from',
            'valid_until',
            'is_expired',
            'is_overdue',
            'returned_overdue',
            'is_returned',
            'expected_return_time',
            'created_at',
            'exit_recorded_at',
            'entry_recorded_at',
            'qr_code_image',
            'raw_token',
        ]
        read_only_fields = fields

    def get_room_number(self, obj):
        student = obj.leave_application.student
        if hasattr(student, 'student_profile'):
            return student.student_profile.room_number
        return None

    def get_hostel_block(self, obj):
        student = obj.leave_application.student
        if hasattr(student, 'student_profile'):
            return student.student_profile.hostel_block
        return None

    def get_photo_url(self, obj):
        student = obj.leave_application.student
        # Return standard institutional photo or photo identifier
        return f"/photos/students/{student.username}.jpg"


    def get_student_name(self, obj):
        student = obj.leave_application.student
        return student.get_full_name() or student.username

    def get_student_registration(self, obj):
        student = obj.leave_application.student
        if hasattr(student, 'student_profile'):
            return student.student_profile.registration_number
        return None

    def get_department(self, obj):
        student = obj.leave_application.student
        if hasattr(student, 'student_profile'):
            return student.student_profile.department
        return student.department

    def get_raw_token(self, obj):
        # Transmitted only if dynamically passed in serializer context (e.g. at generation/owner view)
        return self.context.get('raw_token')

    def get_qr_code_image(self, obj):
        raw_token = self.context.get('raw_token')
        if raw_token and obj.status == PassStatus.ACTIVE and not obj.is_expired:
            payload = build_qr_payload(obj.pass_id, raw_token)
            try:
                return generate_qr_data_uri(payload)
            except Exception:
                return None
        return None


class GateEventSerializer(serializers.ModelSerializer):
    pass_id = serializers.SerializerMethodField()
    student_name = serializers.SerializerMethodField()
    student_registration = serializers.SerializerMethodField()
    security_officer_name = serializers.SerializerMethodField()

    class Meta:
        model = GateEvent
        fields = [
            'id',
            'pass_id',
            'student_name',
            'student_registration',
            'security_officer_name',
            'gate_type',
            'event_type',
            'verification_outcome',
            'remarks',
            'timestamp',
        ]
        read_only_fields = fields

    def get_pass_id(self, obj):
        return obj.gate_pass.pass_id if obj.gate_pass else None

    def get_student_name(self, obj):
        if obj.student:
            return obj.student.get_full_name() or obj.student.username
        return None

    def get_student_registration(self, obj):
        if obj.student and hasattr(obj.student, 'student_profile'):
            return obj.student.student_profile.registration_number
        return None

    def get_security_officer_name(self, obj):
        return obj.security_officer.get_full_name() or obj.security_officer.username
