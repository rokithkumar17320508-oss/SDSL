"""
Rate limiting and throttling classes for CAMPUSORA API.
Protects authentication endpoints from brute-force password guessing
and gate verification endpoints from automated credential/QR scanning.
"""

from rest_framework.throttling import AnonRateThrottle, UserRateThrottle


class AuthRateThrottle(AnonRateThrottle):
    """
    Strict throttling for authentication operations (login, refresh, password reset).
    Default: 15 requests per minute.
    """
    scope = 'auth'


class GatePassVerifyThrottle(UserRateThrottle):
    """
    Throttling for gate pass verification and QR code scans by Security personnel.
    Default: 120 requests per minute per officer terminal.
    """
    scope = 'verify'
