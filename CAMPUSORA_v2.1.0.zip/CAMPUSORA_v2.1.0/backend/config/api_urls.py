from django.urls import path, include
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny


@api_view(['GET'])
@permission_classes([AllowAny])
def health_check(request):
    """Public health-check endpoint for load balancers and deployment monitoring."""
    return Response({
        'status': 'healthy',
        'service': 'campusora-api',
        'version': '2.0.0',
    })


urlpatterns = [
    path('health/', health_check, name='health-check'),
    path('auth/', include('accounts.urls')),
    path('notifications/', include('notifications.urls')),
    path('analytics/', include('analytics.urls')),
    path('', include('leaves.urls')),
    path('', include('passes.urls')),
]
