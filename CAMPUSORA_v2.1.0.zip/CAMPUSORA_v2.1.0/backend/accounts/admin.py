from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import User, StudentProfile, FacultyProfile, WardenProfile


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    list_display = (
        'username',
        'email',
        'first_name',
        'last_name',
        'role',
        'department',
        'is_staff',
        'is_active',
    )
    list_filter = ('role', 'is_staff', 'is_superuser', 'is_active', 'department')
    search_fields = ('username', 'first_name', 'last_name', 'email', 'department')
    ordering = ('username',)

    fieldsets = BaseUserAdmin.fieldsets + (
        ('CAMPUSORA Role & Metadata', {
            'fields': ('role', 'department', 'phone_number')
        }),
    )
    add_fieldsets = BaseUserAdmin.add_fieldsets + (
        ('CAMPUSORA Role & Metadata', {
            'fields': ('role', 'department', 'phone_number')
        }),
    )


@admin.register(StudentProfile)
class StudentProfileAdmin(admin.ModelAdmin):
    list_display = (
        'registration_number',
        'user',
        'department',
        'year',
        'semester',
        'section',
        'room_number',
    )
    search_fields = (
        'registration_number',
        'user__username',
        'user__first_name',
        'user__last_name',
        'department',
    )
    list_filter = ('department', 'year', 'semester', 'section')


@admin.register(FacultyProfile)
class FacultyProfileAdmin(admin.ModelAdmin):
    list_display = (
        'employee_id',
        'user',
        'department',
        'designation',
        'cabin_number',
    )
    search_fields = (
        'employee_id',
        'user__username',
        'user__first_name',
        'user__last_name',
        'department',
    )
    list_filter = ('department', 'designation')


@admin.register(WardenProfile)
class WardenProfileAdmin(admin.ModelAdmin):
    list_display = (
        'employee_id',
        'user',
        'assigned_hostel',
        'cabin_office',
    )
    search_fields = (
        'employee_id',
        'user__username',
        'user__first_name',
        'user__last_name',
        'assigned_hostel',
    )
    list_filter = ('assigned_hostel',)

