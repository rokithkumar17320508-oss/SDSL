"""
Serializers for CAMPUSORA Authentication & User Profiles.
Ensures no sensitive credentials, password hashes, or internal salts are exposed.
"""

from rest_framework import serializers
from django.contrib.auth import authenticate
from .models import User, Role, StudentProfile, FacultyProfile


class UserProfileSerializer(serializers.ModelSerializer):
    """
    Safe user profile representation for /api/v1/auth/me/.
    Omits password, salts, and secret credentials.
    """
    name = serializers.SerializerMethodField()
    role_display = serializers.CharField(source='get_role_display', read_only=True)
    registration_number = serializers.SerializerMethodField()
    employee_id = serializers.SerializerMethodField()
    academic_details = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = [
            'id',
            'username',
            'email',
            'name',
            'role',
            'role_display',
            'department',
            'phone_number',
            'assigned_gate',
            'registration_number',
            'employee_id',
            'academic_details',
        ]
        read_only_fields = fields

    def get_name(self, obj):
        return obj.get_full_name() or obj.username

    def get_registration_number(self, obj):
        if hasattr(obj, 'student_profile'):
            return obj.student_profile.registration_number
        return None

    def get_employee_id(self, obj):
        if hasattr(obj, 'faculty_profile'):
            return obj.faculty_profile.employee_id
        elif hasattr(obj, 'warden_profile'):
            return obj.warden_profile.employee_id
        return None

    def get_academic_details(self, obj):
        if hasattr(obj, 'student_profile'):
            profile = obj.student_profile
            return {
                'year': profile.year,
                'semester': profile.semester,
                'section': profile.section,
                'room_number': profile.room_number,
                'hostel_block': profile.hostel_block,
                'parent_name': profile.parent_name,
                'parent_email': profile.parent_email,
                'parent_phone': profile.parent_phone,
                'emergency_contact': profile.emergency_contact,
            }
        elif hasattr(obj, 'faculty_profile'):
            profile = obj.faculty_profile
            return {
                'designation': profile.designation,
                'cabin_number': profile.cabin_number,
            }
        elif hasattr(obj, 'warden_profile'):
            profile = obj.warden_profile
            return {
                'assigned_hostel': profile.assigned_hostel,
                'cabin_office': profile.cabin_office,
            }
        return None


class LoginSerializer(serializers.Serializer):
    """
    Validates username and password credentials against Django authentication backend.
    """
    username = serializers.CharField(required=True, write_only=True)
    password = serializers.CharField(required=True, write_only=True, style={'input_type': 'password'})

    def validate(self, attrs):
        username = attrs.get('username')
        password = attrs.get('password')

        if not username or not password:
            raise serializers.ValidationError("Both username and password are required.")

        user = authenticate(username=username, password=password)
        if not user:
            raise serializers.ValidationError("Invalid credentials. Please verify your username and password.")

        if not user.is_active:
            raise serializers.ValidationError("This user account has been disabled.")

        attrs['user'] = user
        return attrs
