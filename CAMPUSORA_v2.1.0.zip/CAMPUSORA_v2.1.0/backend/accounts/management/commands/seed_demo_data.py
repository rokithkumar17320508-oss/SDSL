"""
Management command to seed initial CAMPUSORA demo accounts and sample applications.
Safe for development and evaluation.
"""

from datetime import date, timedelta
from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from accounts.models import Role, StudentProfile, FacultyProfile, WardenProfile
from leaves.models import LeaveApplication, LeaveType, LeaveStatus
from approvals.models import ApprovalRecord, ReviewerRole, Decision

User = get_user_model()


class Command(BaseCommand):
    help = "Seeds initial demo users, profiles, and sample leave applications"

    def handle(self, *args, **options):
        self.stdout.write("Seeding CAMPUSORA demo data...")

        # 1. Superuser / Admin
        admin_user, created = User.objects.get_or_create(
            username='admin',
            defaults={
                'email': 'admin@campusora.edu',
                'first_name': 'Campusora',
                'last_name': 'Administrator',
                'role': Role.HOD,
                'department': 'Administration',
                'is_staff': True,
                'is_superuser': True,
            }
        )
        if created:
            admin_user.set_password('AdminPassword123!')
            admin_user.save()
            self.stdout.write(self.style.SUCCESS("Created admin user: admin / AdminPassword123!"))

        # 2. Student User (Arjun Sharma)
        student_user, s_created = User.objects.get_or_create(
            username='arjun',
            defaults={
                'email': 'arjun.sharma@campusora.edu',
                'first_name': 'Arjun',
                'last_name': 'Sharma',
                'role': Role.STUDENT,
                'department': 'Computer Science & Engineering',
                'phone_number': '+91 98765 43210',
            }
        )
        if s_created:
            student_user.set_password('StudentPassword123!')
            student_user.save()
            StudentProfile.objects.create(
                user=student_user,
                registration_number='2024CSE1084',
                department='Computer Science & Engineering',
                year=3,
                semester=6,
                section='A',
                room_number='BH-2, Room 405',
                hostel_block='BH-2',
                parent_name='Sunil Sharma',
                parent_email='parent.sharma@campusora.edu',
                parent_phone='+91 98765 00001',
                emergency_contact='+91 98765 00000'
            )
            self.stdout.write(self.style.SUCCESS("Created student user: arjun / StudentPassword123!"))
        else:
            # Update existing profile with parent details and hostel block
            if hasattr(student_user, 'student_profile'):
                sp = student_user.student_profile
                updated = False
                if not sp.hostel_block:
                    sp.hostel_block = 'BH-2'
                    updated = True
                if not sp.parent_name:
                    sp.parent_name = 'Sunil Sharma'
                    updated = True
                if not sp.parent_email:
                    sp.parent_email = 'parent.sharma@campusora.edu'
                    updated = True
                if not sp.parent_phone:
                    sp.parent_phone = '+91 98765 00001'
                    updated = True
                if updated:
                    sp.save()
                    self.stdout.write(self.style.SUCCESS("Updated student arjun parent and hostel details."))

        # 3. Faculty User (Dr. S. K. Verma)
        faculty_user, f_created = User.objects.get_or_create(
            username='skverma',
            defaults={
                'email': 'skverma@campusora.edu',
                'first_name': 'S. K.',
                'last_name': 'Verma',
                'role': Role.FACULTY,
                'department': 'Computer Science & Engineering',
                'phone_number': '+91 98765 11111',
                'is_staff': True,
            }
        )
        if f_created:
            faculty_user.set_password('FacultyPassword123!')
            faculty_user.save()
            FacultyProfile.objects.create(
                user=faculty_user,
                employee_id='EMP-CSE-042',
                department='Computer Science & Engineering',
                designation='Associate Professor & Class Advisor',
                cabin_number='CS-302'
            )
            self.stdout.write(self.style.SUCCESS("Created faculty user: skverma / FacultyPassword123!"))

        # Ensure student is linked to advisor Dr. S. K. Verma
        if hasattr(student_user, 'student_profile') and not student_user.student_profile.advisor:
            student_user.student_profile.advisor = faculty_user
            student_user.student_profile.save(update_fields=['advisor'])
            self.stdout.write(self.style.SUCCESS("Linked student arjun to advisor skverma."))

        # 4. HOD User (Prof. R. Mehra)
        hod_user, h_created = User.objects.get_or_create(
            username='rmehra',
            defaults={
                'email': 'rmehra@campusora.edu',
                'first_name': 'R.',
                'last_name': 'Mehra',
                'role': Role.HOD,
                'department': 'Computer Science & Engineering',
                'phone_number': '+91 98765 22222',
                'is_staff': True,
            }
        )
        if h_created:
            hod_user.set_password('HodPassword123!')
            hod_user.save()
            FacultyProfile.objects.create(
                user=hod_user,
                employee_id='EMP-CSE-001',
                department='Computer Science & Engineering',
                designation='Professor & Head of Department',
                cabin_number='HOD-CSE Wing A'
            )
            self.stdout.write(self.style.SUCCESS("Created HOD user: rmehra / HodPassword123!"))

        # 5. Security User (Officer Vikram Singh - Main Gate)
        sec_user, sec_created = User.objects.get_or_create(
            username='security_gate1',
            defaults={
                'email': 'security.main@campusora.edu',
                'first_name': 'Vikram',
                'last_name': 'Singh',
                'role': Role.SECURITY,
                'department': 'Campus Safety & Security',
                'phone_number': '+91 98765 33333',
                'assigned_gate': 'College Main Gate',
            }
        )
        if sec_created:
            sec_user.set_password('SecurityPassword123!')
            sec_user.save()
            self.stdout.write(self.style.SUCCESS("Created security user: security_gate1 / SecurityPassword123!"))
        elif sec_user.assigned_gate != 'College Main Gate':
            sec_user.assigned_gate = 'College Main Gate'
            sec_user.save(update_fields=['assigned_gate'])

        # 5b. Hostel Security User (Officer Ramesh Kumar - Hostel Gate)
        sec_hostel_user, sec_h_created = User.objects.get_or_create(
            username='security_hostel1',
            defaults={
                'email': 'security.hostel@campusora.edu',
                'first_name': 'Ramesh',
                'last_name': 'Kumar',
                'role': Role.SECURITY,
                'department': 'Campus Safety & Security',
                'phone_number': '+91 98765 44444',
                'assigned_gate': 'Hostel Gate',
            }
        )
        if sec_h_created:
            sec_hostel_user.set_password('SecurityPassword123!')
            sec_hostel_user.save()
            self.stdout.write(self.style.SUCCESS("Created security user: security_hostel1 / SecurityPassword123!"))
        elif sec_hostel_user.assigned_gate != 'Hostel Gate':
            sec_hostel_user.assigned_gate = 'Hostel Gate'
            sec_hostel_user.save(update_fields=['assigned_gate'])

        # 5c. Hostel Warden User (Rajesh Patil - BH-2)
        wrd_bh2, wrd_bh2_created = User.objects.get_or_create(
            username='warden_bh2',
            defaults={
                'email': 'warden.bh2@campusora.edu',
                'first_name': 'Rajesh',
                'last_name': 'Patil',
                'role': Role.WARDEN,
                'department': 'Hostel Administration',
                'phone_number': '+91 98765 55555',
                'is_staff': True,
            }
        )
        if wrd_bh2_created:
            wrd_bh2.set_password('WardenPassword123!')
            wrd_bh2.save()
            WardenProfile.objects.create(
                user=wrd_bh2,
                employee_id='EMP-WRD-001',
                assigned_hostel='BH-2',
                cabin_office='BH-2 Ground Floor Office'
            )
            self.stdout.write(self.style.SUCCESS("Created warden user: warden_bh2 / WardenPassword123!"))
        elif not hasattr(wrd_bh2, 'warden_profile'):
            WardenProfile.objects.create(
                user=wrd_bh2,
                employee_id='EMP-WRD-001',
                assigned_hostel='BH-2',
                cabin_office='BH-2 Ground Floor Office'
            )

        # 5d. Hostel Warden User (Ananya Sen - GH-1)
        wrd_gh1, wrd_gh1_created = User.objects.get_or_create(
            username='warden_gh1',
            defaults={
                'email': 'warden.gh1@campusora.edu',
                'first_name': 'Ananya',
                'last_name': 'Sen',
                'role': Role.WARDEN,
                'department': 'Hostel Administration',
                'phone_number': '+91 98765 66666',
                'is_staff': True,
            }
        )
        if wrd_gh1_created:
            wrd_gh1.set_password('WardenPassword123!')
            wrd_gh1.save()
            WardenProfile.objects.create(
                user=wrd_gh1,
                employee_id='EMP-WRD-002',
                assigned_hostel='GH-1',
                cabin_office='GH-1 Ground Floor Office'
            )
            self.stdout.write(self.style.SUCCESS("Created warden user: warden_gh1 / WardenPassword123!"))
        elif not hasattr(wrd_gh1, 'warden_profile'):
            WardenProfile.objects.create(
                user=wrd_gh1,
                employee_id='EMP-WRD-002',
                assigned_hostel='GH-1',
                cabin_office='GH-1 Ground Floor Office'
            )


        # 6. Sample Leave Applications
        today = date.today()
        if not LeaveApplication.objects.filter(student=student_user).exists():
            # Approved pass
            app1 = LeaveApplication.objects.create(
                application_id='APP-1035',
                student=student_user,
                leave_type=LeaveType.HOSTEL_OUTPASS,
                start_date=today + timedelta(days=1),
                end_date=today + timedelta(days=3),
                reason='Family function at home town.',
                status=LeaveStatus.HOD_APPROVED,
                faculty_reviewer=faculty_user,
                hod_reviewer=hod_user
            )
            ApprovalRecord.objects.create(
                leave_application=app1,
                reviewer=faculty_user,
                reviewer_role=ReviewerRole.FACULTY,
                decision=Decision.FORWARDED_TO_HOD,
                remarks='Academic standing verified. Attendance satisfactory (87.5%).'
            )
            ApprovalRecord.objects.create(
                leave_application=app1,
                reviewer=hod_user,
                reviewer_role=ReviewerRole.HOD,
                decision=Decision.HOD_APPROVED,
                remarks='Authorized. Gate pass generated.'
            )

            # Pending HOD pass
            app2 = LeaveApplication.objects.create(
                application_id='APP-1042',
                student=student_user,
                leave_type=LeaveType.ON_DUTY,
                start_date=today + timedelta(days=5),
                end_date=today + timedelta(days=6),
                reason='State Hackathon 2026 Participation.',
                status=LeaveStatus.PENDING_HOD,
                faculty_reviewer=faculty_user
            )
            ApprovalRecord.objects.create(
                leave_application=app2,
                reviewer=faculty_user,
                reviewer_role=ReviewerRole.FACULTY,
                decision=Decision.FORWARDED_TO_HOD,
                remarks='College representation letter verified.'
            )

            # Pending Faculty pass
            LeaveApplication.objects.create(
                application_id='APP-1050',
                student=student_user,
                leave_type=LeaveType.DAY_PASS,
                start_date=today + timedelta(days=2),
                end_date=today + timedelta(days=2),
                reason='Doctor appointment at City Hospital.',
                status=LeaveStatus.PENDING_FACULTY
            )

            self.stdout.write(self.style.SUCCESS("Created 3 initial sample leave applications."))

        # Backfill existing applications with reviewer references if null
        LeaveApplication.objects.filter(application_id='APP-1035', faculty_reviewer__isnull=True).update(
            faculty_reviewer=faculty_user,
            hod_reviewer=hod_user
        )
        LeaveApplication.objects.filter(application_id='APP-1042', faculty_reviewer__isnull=True).update(
            faculty_reviewer=faculty_user
        )

        self.stdout.write(self.style.SUCCESS("CAMPUSORA demo seeding complete!"))
