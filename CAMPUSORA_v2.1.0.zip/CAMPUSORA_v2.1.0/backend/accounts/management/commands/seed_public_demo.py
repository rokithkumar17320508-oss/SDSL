"""
Management command to seed a clean, synthetic demonstration dataset for public demos.
Zero private student or parent data is used (RFC 2606 example.com domains and synthetic numbers).
Credentials are configurable via environment variables and never hardcoded into production code.
"""

import os
import string
import secrets
from datetime import date, timedelta
from django.conf import settings
from django.core.management import call_command
from django.core.management.base import BaseCommand, CommandError
from django.contrib.auth import get_user_model
from django.utils import timezone
from accounts.models import Role, StudentProfile, FacultyProfile, WardenProfile
from leaves.models import LeaveApplication, LeaveType, LeaveStatus
from approvals.models import ApprovalRecord, ReviewerRole, Decision
from passes.models import GatePass, PassStatus, GateType, GateEvent, EventType, VerificationOutcome
from passes.utils import derive_pass_token, hash_token
from notifications.models import NotificationLog, NotificationChannel, NotificationType

User = get_user_model()


def generate_secure_password(length=18):
    """Generates cryptographically strong random password for demonstration accounts."""
    chars = string.ascii_letters + string.digits + "!@#$%^&*()-_=+"
    return ''.join(secrets.choice(chars) for _ in range(length))


class Command(BaseCommand):
    help = "Seeds synthetic demonstration accounts and workflow data for safe public demonstrations."

    def add_arguments(self, parser):
        parser.add_argument(
            '--clean',
            action='store_true',
            help='Removes previous demo_ accounts and demo applications before seeding',
        )
        parser.add_argument(
            '--generate-passwords',
            action='store_true',
            help='Generates new cryptographically secure random passwords for demo personas',
        )
        parser.add_argument(
            '--credentials-file',
            type=str,
            default=None,
            help='Path to securely write generated credentials (saved with mode 0600)',
        )
        parser.add_argument(
            '--force-primary',
            action='store_true',
            help='Bypasses safety guard on local campusora_db (USE WITH CAUTION)',
        )

    def handle(self, *args, **options):
        # 1. Database Safety Guard (Task 3)
        default_db = settings.DATABASES['default']
        db_name = default_db.get('NAME', '')
        db_host = default_db.get('HOST', '')
        force_primary = options.get('force_primary', False)

        if db_name == 'campusora_db' and db_host in ('127.0.0.1', 'localhost', '') and not force_primary:
            raise CommandError(
                "CRITICAL DATABASE SAFETY GUARD ACTIVATED:\n"
                "Refusing to execute public demonstration seeder against local primary database 'campusora_db'.\n"
                "The target database must be a dedicated demonstration database (such as your remote Neon\n"
                "database via DATABASE_URL, or local campusora_demo_db).\n\n"
                "To safely seed Neon from Ubuntu terminal, run:\n"
                "  DATABASE_URL=\"postgresql://...neon.tech/neondb?sslmode=require\" python manage.py seed_public_demo\n"
            )

        clean = options.get('clean', False)
        gen_pw = options.get('generate_passwords', False)
        creds_file = options.get('credentials_file', None)

        self.stdout.write(self.style.NOTICE(f"Connecting to database: {db_name} on {db_host or 'local socket'}..."))

        # Determine demonstration account passwords
        if gen_pw:
            student_pw = generate_secure_password()
            faculty_pw = generate_secure_password()
            hod_pw = generate_secure_password()
            security_pw = generate_secure_password()
            warden_pw = generate_secure_password()
        else:
            student_pw = os.getenv('DEMO_STUDENT_PASSWORD', 'DemoStudent2026!')
            faculty_pw = os.getenv('DEMO_FACULTY_PASSWORD', 'DemoFaculty2026!')
            hod_pw = os.getenv('DEMO_HOD_PASSWORD', 'DemoHod2026!')
            security_pw = os.getenv('DEMO_SECURITY_PASSWORD', 'DemoSecurity2026!')
            warden_pw = os.getenv('DEMO_WARDEN_PASSWORD', 'DemoWarden2026!')

        # If credentials file requested or generated, write securely without logging to stdout (Task 5)
        if creds_file:
            creds_content = (
                f"# CAMPUSORA Demonstration Account Credentials\n"
                f"# Generated: {timezone.now().isoformat()}\n"
                f"# DO NOT COMMIT TO VERSION CONTROL\n\n"
                f"DEMO_STUDENT_USERNAME=demo_student\n"
                f"DEMO_STUDENT_PASSWORD={student_pw}\n\n"
                f"DEMO_FACULTY_USERNAME=demo_faculty\n"
                f"DEMO_FACULTY_PASSWORD={faculty_pw}\n\n"
                f"DEMO_HOD_USERNAME=demo_hod\n"
                f"DEMO_HOD_PASSWORD={hod_pw}\n\n"
                f"DEMO_SECURITY_USERNAME=demo_security\n"
                f"DEMO_SECURITY_PASSWORD={security_pw}\n\n"
                f"DEMO_WARDEN_USERNAME=demo_warden\n"
                f"DEMO_WARDEN_PASSWORD={warden_pw}\n"
            )
            # Write with owner-only read permissions (0600)
            fd = os.open(creds_file, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with open(fd, 'w') as f:
                f.write(creds_content)
            self.stdout.write(self.style.SUCCESS(f"Credentials written securely to {creds_file} (mode 0600)."))
            self.stdout.write(self.style.NOTICE("Passwords will NOT be printed to deployment logs to prevent exposure."))
        elif not gen_pw:
            self.stdout.write(self.style.NOTICE("Using environment configured demo passwords."))

        if clean:
            self.stdout.write("Cleaning previous synthetic demo records...")
            demo_usernames = ['demo_student', 'demo_faculty', 'demo_hod', 'demo_security', 'demo_warden']
            LeaveApplication.objects.filter(student__username__in=demo_usernames).delete()
            User.objects.filter(username__in=demo_usernames).delete()
            self.stdout.write(self.style.SUCCESS("Previous demo records purged cleanly."))

        # 1. Faculty Advisor (Dr. Anita Verma)
        faculty_user, _ = User.objects.get_or_create(
            username=os.getenv('DEMO_FACULTY_USERNAME', 'demo_faculty'),
            defaults={
                'email': 'demo.faculty@campusora.edu',
                'first_name': 'Anita',
                'last_name': 'Verma',
                'role': Role.FACULTY,
                'department': 'Computer Science & Engineering',
                'phone_number': '+91 98000 00003',
                'is_staff': True,
            }
        )
        faculty_user.set_password(faculty_pw)
        faculty_user.save()

        FacultyProfile.objects.update_or_create(
            user=faculty_user,
            defaults={
                'employee_id': 'EMP-CSE-101',
                'department': 'Computer Science & Engineering',
                'designation': 'Associate Professor & Class Advisor',
                'cabin_number': 'CS-204',
            }
        )

        # 2. HOD (Prof. Rajesh Mehra)
        hod_user, _ = User.objects.get_or_create(
            username=os.getenv('DEMO_HOD_USERNAME', 'demo_hod'),
            defaults={
                'email': 'demo.hod@campusora.edu',
                'first_name': 'Rajesh',
                'last_name': 'Mehra',
                'role': Role.HOD,
                'department': 'Computer Science & Engineering',
                'phone_number': '+91 98000 00004',
                'is_staff': True,
            }
        )
        hod_user.set_password(hod_pw)
        hod_user.save()

        FacultyProfile.objects.update_or_create(
            user=hod_user,
            defaults={
                'employee_id': 'EMP-CSE-001',
                'department': 'Computer Science & Engineering',
                'designation': 'Professor & Head of Department',
                'cabin_number': 'HOD-CSE Office',
            }
        )

        # 3. Security Officer (Officer Vikram Rathore - Main Gate)
        security_user, _ = User.objects.get_or_create(
            username=os.getenv('DEMO_SECURITY_USERNAME', 'demo_security'),
            defaults={
                'email': 'demo.security@campusora.edu',
                'first_name': 'Vikram',
                'last_name': 'Rathore',
                'role': Role.SECURITY,
                'department': 'Campus Safety & Security',
                'phone_number': '+91 98000 00005',
                'assigned_gate': 'College Main Gate',
            }
        )
        security_user.set_password(security_pw)
        security_user.assigned_gate = 'College Main Gate'
        security_user.save()

        # 4. Hostel Warden (Warden Suresh Patil - BH-1)
        warden_user, _ = User.objects.get_or_create(
            username=os.getenv('DEMO_WARDEN_USERNAME', 'demo_warden'),
            defaults={
                'email': 'demo.warden@campusora.edu',
                'first_name': 'Suresh',
                'last_name': 'Patil',
                'role': Role.WARDEN,
                'department': 'Hostel Administration',
                'phone_number': '+91 98000 00006',
                'is_staff': True,
            }
        )
        warden_user.set_password(warden_pw)
        warden_user.save()

        WardenProfile.objects.update_or_create(
            user=warden_user,
            defaults={
                'employee_id': 'EMP-WRD-001',
                'assigned_hostel': 'BH-1',
                'cabin_office': 'BH-1 Ground Floor Office',
            }
        )

        # 5. Student (Aarav Sharma - Synthetic details only)
        student_user, _ = User.objects.get_or_create(
            username=os.getenv('DEMO_STUDENT_USERNAME', 'demo_student'),
            defaults={
                'email': 'demo.student@campusora.edu',
                'first_name': 'Aarav',
                'last_name': 'Sharma',
                'role': Role.STUDENT,
                'department': 'Computer Science & Engineering',
                'phone_number': '+91 98000 00001',
            }
        )
        student_user.set_password(student_pw)
        student_user.save()

        StudentProfile.objects.update_or_create(
            user=student_user,
            defaults={
                'registration_number': '2026CS101',
                'department': 'Computer Science & Engineering',
                'year': 3,
                'semester': 6,
                'section': 'A',
                'room_number': 'BH-1, Room 204',
                'hostel_block': 'BH-1',
                'parent_name': 'Ramesh Sharma',
                'parent_email': 'parent.demo@example.com',
                'parent_phone': '+91 98000 00002',
                'emergency_contact': '+91 98000 00000',
                'advisor': faculty_user,
            }
        )

        self.stdout.write(self.style.SUCCESS("Demonstration User Personas Seeded Successfully:"))
        self.stdout.write(f"  - Student:  {student_user.username}")
        self.stdout.write(f"  - Faculty:  {faculty_user.username}")
        self.stdout.write(f"  - HOD:      {hod_user.username}")
        self.stdout.write(f"  - Security: {security_user.username}")
        self.stdout.write(f"  - Warden:   {warden_user.username}")

        # Seed Sample Demonstration Workflow Applications
        today = date.today()
        now = timezone.now()

        # Application 1: ACTIVE PASS (Ready for live exit scan)
        app1, _ = LeaveApplication.objects.update_or_create(
            application_id='APP-DEMO-01',
            defaults={
                'student': student_user,
                'leave_type': LeaveType.HOSTEL_OUTPASS,
                'start_date': today,
                'end_date': today + timedelta(days=2),
                'reason': 'Attending regional inter-college robotics competition at City Tech.',
                'status': LeaveStatus.HOD_APPROVED,
                'faculty_reviewer': faculty_user,
                'hod_reviewer': hod_user,
            }
        )
        ApprovalRecord.objects.get_or_create(
            leave_application=app1,
            reviewer=faculty_user,
            reviewer_role=ReviewerRole.FACULTY,
            defaults={'decision': Decision.FORWARDED_TO_HOD, 'remarks': 'Academic standing verified. Participation authorized.'}
        )
        ApprovalRecord.objects.get_or_create(
            leave_application=app1,
            reviewer=hod_user,
            reviewer_role=ReviewerRole.HOD,
            defaults={'decision': Decision.HOD_APPROVED, 'remarks': 'Institutional representation authorized. Gate pass granted.'}
        )

        raw_token1 = derive_pass_token('GP-DEMO-01', 'demo_active')
        pass1, _ = GatePass.objects.update_or_create(
            pass_id='GP-DEMO-01',
            defaults={
                'leave_application': app1,
                'gate_type': GateType.COLLEGE_MAIN_GATE,
                'token_hash': hash_token(raw_token1),
                'valid_from': now - timedelta(hours=1),
                'valid_until': now + timedelta(days=2),
                'status': PassStatus.ACTIVE,
            }
        )

        # Application 2: USED PASS (Exit completed, ready for live return verification)
        app2, _ = LeaveApplication.objects.update_or_create(
            application_id='APP-DEMO-02',
            defaults={
                'student': student_user,
                'leave_type': LeaveType.DAY_PASS,
                'start_date': today,
                'end_date': today,
                'reason': 'Scheduled dental consultation and routine medical checkup.',
                'status': LeaveStatus.HOD_APPROVED,
                'faculty_reviewer': faculty_user,
                'hod_reviewer': hod_user,
            }
        )
        ApprovalRecord.objects.get_or_create(
            leave_application=app2,
            reviewer=faculty_user,
            reviewer_role=ReviewerRole.FACULTY,
            defaults={'decision': Decision.FORWARDED_TO_HOD, 'remarks': 'Medical appointment letter noted.'}
        )
        ApprovalRecord.objects.get_or_create(
            leave_application=app2,
            reviewer=hod_user,
            reviewer_role=ReviewerRole.HOD,
            defaults={'decision': Decision.HOD_APPROVED, 'remarks': 'Day pass cleared.'}
        )

        raw_token2 = derive_pass_token('GP-DEMO-02', 'demo_used')
        pass2, _ = GatePass.objects.update_or_create(
            pass_id='GP-DEMO-02',
            defaults={
                'leave_application': app2,
                'gate_type': GateType.COLLEGE_MAIN_GATE,
                'token_hash': hash_token(raw_token2),
                'valid_from': now - timedelta(hours=4),
                'valid_until': now + timedelta(hours=6),
                'status': PassStatus.USED,
                'exit_recorded_at': now - timedelta(hours=2),
            }
        )
        GateEvent.objects.get_or_create(
            gate_pass=pass2,
            event_type=EventType.EXIT,
            defaults={
                'student': student_user,
                'security_officer': security_user,
                'gate_type': 'College Main Gate',
                'verification_outcome': VerificationOutcome.SUCCESS,
                'remarks': 'Departure verified. Identity matched with student card.',
            }
        )

        # Application 3: RETURNED PASS (Full lifecycle complete)
        app3, _ = LeaveApplication.objects.update_or_create(
            application_id='APP-DEMO-03',
            defaults={
                'student': student_user,
                'leave_type': LeaveType.REGULAR_LEAVE,
                'start_date': today - timedelta(days=2),
                'end_date': today - timedelta(days=1),
                'reason': 'Weekend family visit.',
                'status': LeaveStatus.HOD_APPROVED,
                'faculty_reviewer': faculty_user,
                'hod_reviewer': hod_user,
            }
        )
        raw_token3 = derive_pass_token('GP-DEMO-03', 'demo_returned')
        pass3, _ = GatePass.objects.update_or_create(
            pass_id='GP-DEMO-03',
            defaults={
                'leave_application': app3,
                'gate_type': GateType.COLLEGE_MAIN_GATE,
                'token_hash': hash_token(raw_token3),
                'valid_from': now - timedelta(days=2),
                'valid_until': now - timedelta(days=1),
                'status': PassStatus.RETURNED,
                'exit_recorded_at': now - timedelta(days=2, hours=3),
                'entry_recorded_at': now - timedelta(days=1, hours=2),
            }
        )
        GateEvent.objects.get_or_create(
            gate_pass=pass3,
            event_type=EventType.EXIT,
            defaults={
                'student': student_user,
                'security_officer': security_user,
                'gate_type': 'College Main Gate',
                'verification_outcome': VerificationOutcome.SUCCESS,
                'remarks': 'Weekend exit cleared.',
            }
        )
        GateEvent.objects.get_or_create(
            gate_pass=pass3,
            event_type=EventType.ENTRY,
            defaults={
                'student': student_user,
                'security_officer': security_user,
                'gate_type': 'College Main Gate',
                'verification_outcome': VerificationOutcome.RETURN_SUCCESS,
                'remarks': 'Return on time. In good order.',
            }
        )

        # Application 4: PENDING_FACULTY (For live Faculty demonstration)
        LeaveApplication.objects.update_or_create(
            application_id='APP-DEMO-04',
            defaults={
                'student': student_user,
                'leave_type': LeaveType.ON_DUTY,
                'start_date': today + timedelta(days=3),
                'end_date': today + timedelta(days=4),
                'reason': 'Paper presentation on AI Ethics at National University Conference.',
                'status': LeaveStatus.PENDING_FACULTY,
            }
        )

        # Application 5: PENDING_HOD (For live HOD demonstration)
        app5, _ = LeaveApplication.objects.update_or_create(
            application_id='APP-DEMO-05',
            defaults={
                'student': student_user,
                'leave_type': LeaveType.HOSTEL_OUTPASS,
                'start_date': today + timedelta(days=5),
                'end_date': today + timedelta(days=7),
                'reason': 'Family engagement ceremony in native town.',
                'status': LeaveStatus.PENDING_HOD,
                'faculty_reviewer': faculty_user,
            }
        )
        ApprovalRecord.objects.get_or_create(
            leave_application=app5,
            reviewer=faculty_user,
            reviewer_role=ReviewerRole.FACULTY,
            defaults={'decision': Decision.FORWARDED_TO_HOD, 'remarks': 'Leave dates reconciled with laboratory schedule. Recommended.'}
        )

        # Application 6: REJECTED (Disciplinary / Policy sample)
        app6, _ = LeaveApplication.objects.update_or_create(
            application_id='APP-DEMO-06',
            defaults={
                'student': student_user,
                'leave_type': LeaveType.DAY_PASS,
                'start_date': today + timedelta(days=1),
                'end_date': today + timedelta(days=1),
                'reason': 'Shopping outside campus during core laboratory hours.',
                'status': LeaveStatus.REJECTED,
                'faculty_reviewer': faculty_user,
            }
        )
        ApprovalRecord.objects.get_or_create(
            leave_application=app6,
            reviewer=faculty_user,
            reviewer_role=ReviewerRole.FACULTY,
            defaults={'decision': Decision.REJECTED, 'remarks': 'Absence during mandatory operating systems lab cannot be sanctioned.'}
        )

        # Application 7: OVERDUE OUTSIDE (To demonstrate security curfew alerts)
        app7, _ = LeaveApplication.objects.update_or_create(
            application_id='APP-DEMO-07',
            defaults={
                'student': student_user,
                'leave_type': LeaveType.DAY_PASS,
                'start_date': today - timedelta(days=1),
                'end_date': today - timedelta(days=1),
                'reason': 'Out-of-campus study circle and project discussion.',
                'status': LeaveStatus.HOD_APPROVED,
                'faculty_reviewer': faculty_user,
                'hod_reviewer': hod_user,
            }
        )
        raw_token7 = derive_pass_token('GP-DEMO-07', 'demo_overdue')
        pass7, _ = GatePass.objects.update_or_create(
            pass_id='GP-DEMO-07',
            defaults={
                'leave_application': app7,
                'gate_type': GateType.COLLEGE_MAIN_GATE,
                'token_hash': hash_token(raw_token7),
                'valid_from': now - timedelta(days=1, hours=8),
                'valid_until': now - timedelta(days=1, hours=2),
                'status': PassStatus.USED,
                'exit_recorded_at': now - timedelta(days=1, hours=7),
            }
        )
        GateEvent.objects.get_or_create(
            gate_pass=pass7,
            event_type=EventType.EXIT,
            defaults={
                'student': student_user,
                'security_officer': security_user,
                'gate_type': 'College Main Gate',
                'verification_outcome': VerificationOutcome.SUCCESS,
                'remarks': 'Departure recorded yesterday morning.',
            }
        )

        # Seed Notification Audit Trail
        NotificationLog.objects.get_or_create(
            recipient_user=student_user,
            notification_type=NotificationType.HOD_APPROVED,
            channel=NotificationChannel.EMAIL,
            defaults={
                'recipient_name': student_user.get_full_name(),
                'recipient_email': student_user.email,
                'recipient_type': 'STUDENT',
                'subject': 'CAMPUSORA Alert: Leave Application Approved & Gate Pass Ready',
                'status': 'SENT',
            }
        )
        NotificationLog.objects.get_or_create(
            recipient_user=student_user,
            notification_type=NotificationType.PARENT_EXIT_ALERT,
            channel=NotificationChannel.SMS,
            defaults={
                'recipient_name': student_user.student_profile.parent_name,
                'recipient_phone': student_user.student_profile.parent_phone,
                'recipient_type': 'PARENT',
                'subject': 'Parent Departure Alert',
                'status': 'SENT',
            }
        )

        # Seed all 240 First-Year CSE students across 4 sections (CSE-A, CSE-B, CSE-C, CSE-D)
        self.stdout.write(self.style.NOTICE("\nProvisioning 240 First-Year CSE Students across 4 sections..."))
        call_command('seed_cse_sections')

        self.stdout.write(self.style.SUCCESS("\nDemo Workflow Records Successfully Seeded:"))
        self.stdout.write("  - Core Demo Personas (Student, Faculty, HOD, Security, Warden)")
        self.stdout.write("  - 240 First-Year CSE Students (60 in CSE-A, 60 in CSE-B, 60 in CSE-C, 60 in CSE-D)")
        self.stdout.write("  - Sectional Leave Applications across all lifecycle states")
        self.stdout.write("  - 1 ACTIVE Gate Pass (GP-DEMO-01) ready for live departure scan")
        self.stdout.write("  - 1 USED Gate Pass (GP-DEMO-02) ready for live return scan")
        self.stdout.write("  - 1 OVERDUE Pass (GP-DEMO-07) showing outside curfew alert")
        self.stdout.write("  - Complete audit ledger of GateEvents and NotificationLogs")
        self.stdout.write(self.style.SUCCESS("Demonstration Database Preparation Complete."))
