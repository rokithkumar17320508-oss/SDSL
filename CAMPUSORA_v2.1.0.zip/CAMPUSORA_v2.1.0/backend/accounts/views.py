"""
Authentication & Authorization API Views for CAMPUSORA.
Supports HttpOnly cookie JWT handling, refresh-token rotation, blacklisting, and RBAC checks.
"""

from django.conf import settings
from rest_framework import status, permissions
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.serializers import TokenRefreshSerializer
from rest_framework_simplejwt.exceptions import InvalidToken, TokenError

from .models import Role
from .serializers import UserProfileSerializer, LoginSerializer
from .permissions import IsStudentUser, IsFacultyUser, IsHodUser, IsSecurityUser
from config.throttling import AuthRateThrottle


def set_jwt_cookies(response, access_token, refresh_token=None):
    """
    Sets secure HttpOnly cookies for JWT tokens with configurable security attributes.
    """
    access_lifetime = int(settings.SIMPLE_JWT['ACCESS_TOKEN_LIFETIME'].total_seconds())
    secure = getattr(settings, 'JWT_AUTH_COOKIE_SECURE', False)
    samesite = getattr(settings, 'JWT_AUTH_COOKIE_SAMESITE', 'Lax')
    path = getattr(settings, 'JWT_AUTH_COOKIE_PATH', '/')
    domain = getattr(settings, 'JWT_AUTH_COOKIE_DOMAIN', None)

    response.set_cookie(
        key=getattr(settings, 'JWT_AUTH_COOKIE', 'campusora_access_token'),
        value=str(access_token),
        max_age=access_lifetime,
        httponly=True,
        secure=secure,
        samesite=samesite,
        path=path,
        domain=domain,
    )

    if refresh_token:
        refresh_lifetime = int(settings.SIMPLE_JWT['REFRESH_TOKEN_LIFETIME'].total_seconds())
        response.set_cookie(
            key=getattr(settings, 'JWT_AUTH_REFRESH_COOKIE', 'campusora_refresh_token'),
            value=str(refresh_token),
            max_age=refresh_lifetime,
            httponly=True,
            secure=secure,
            samesite=samesite,
            path=path,
            domain=domain,
        )


class LoginView(APIView):
    """
    POST /api/v1/auth/login/
    Validates user credentials against Django's Argon2-backed authentication.
    Issues JWT access/refresh tokens in HttpOnly cookies and response payload.
    """
    permission_classes = [permissions.AllowAny]
    throttle_classes = [AuthRateThrottle]

    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']

        refresh = RefreshToken.for_user(user)
        # Custom claims for rapid token identification
        refresh['role'] = user.role
        refresh['username'] = user.username

        access_token = str(refresh.access_token)
        refresh_token = str(refresh)

        response_data = {
            'message': 'Login successful',
            'user': UserProfileSerializer(user).data,
            'access': access_token,
            'refresh': refresh_token,
        }

        response = Response(response_data, status=status.HTTP_200_OK)
        set_jwt_cookies(response, access_token, refresh_token)
        return response


class RefreshTokenView(APIView):
    """
    POST /api/v1/auth/refresh/
    Rotates the refresh token and issues a fresh access token.
    Invalidates (blacklists) previous refresh token.
    """
    permission_classes = [permissions.AllowAny]
    throttle_classes = [AuthRateThrottle]

    def post(self, request):
        # Prefer explicit request payload, fall back to HttpOnly cookie
        refresh_cookie_name = getattr(settings, 'JWT_AUTH_REFRESH_COOKIE', 'campusora_refresh_token')
        refresh_token = request.data.get('refresh') or request.COOKIES.get(refresh_cookie_name)

        if not refresh_token:
            return Response(
                {'detail': 'Refresh token was not provided in cookies or request body.'},
                status=status.HTTP_400_BAD_REQUEST
            )

        serializer = TokenRefreshSerializer(data={'refresh': refresh_token})
        try:
            serializer.is_valid(raise_exception=True)
        except (InvalidToken, TokenError) as exc:
            return Response({'detail': str(exc)}, status=status.HTTP_401_UNAUTHORIZED)

        data = serializer.validated_data
        new_access = data.get('access')
        new_refresh = data.get('refresh', refresh_token)

        response = Response({
            'message': 'Token refreshed successfully',
            'access': new_access,
            'refresh': new_refresh,
        }, status=status.HTTP_200_OK)

        set_jwt_cookies(response, new_access, new_refresh)
        return response


class LogoutView(APIView):
    """
    POST /api/v1/auth/logout/
    Blacklists the active refresh token and clears HttpOnly authentication cookies.
    """
    permission_classes = [permissions.AllowAny]
    throttle_classes = [AuthRateThrottle]

    def post(self, request):
        refresh_cookie_name = getattr(settings, 'JWT_AUTH_REFRESH_COOKIE', 'campusora_refresh_token')
        refresh_token = request.data.get('refresh') or request.COOKIES.get(refresh_cookie_name)

        if refresh_token:
            try:
                token = RefreshToken(refresh_token)
                token.blacklist()
            except (TokenError, InvalidToken):
                # Token may already be blacklisted or expired; proceed to clear cookies safely
                pass

        response = Response({'detail': 'Logout successful. Session terminated.'}, status=status.HTTP_200_OK)

        # Clear authentication cookies
        access_cookie = getattr(settings, 'JWT_AUTH_COOKIE', 'campusora_access_token')
        path = getattr(settings, 'JWT_AUTH_COOKIE_PATH', '/')
        domain = getattr(settings, 'JWT_AUTH_COOKIE_DOMAIN', None)
        response.delete_cookie(access_cookie, path=path, domain=domain)
        response.delete_cookie(refresh_cookie_name, path=path, domain=domain)

        return response


class CurrentUserProfileView(APIView):
    """
    GET /api/v1/auth/me/
    Returns the authenticated user's safe institutional profile metadata.
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        serializer = UserProfileSerializer(request.user)
        return Response(serializer.data, status=status.HTTP_200_OK)


# Role-Restricted Test Endpoints for Boundary Verification
class StudentOnlyView(APIView):
    permission_classes = [IsStudentUser]

    def get(self, request):
        return Response({'message': f"Authorized student access: {request.user.username}", 'role': request.user.role})


class FacultyOnlyView(APIView):
    permission_classes = [IsFacultyUser]

    def get(self, request):
        return Response({'message': f"Authorized faculty access: {request.user.username}", 'role': request.user.role})


class HodOnlyView(APIView):
    permission_classes = [IsHodUser]

    def get(self, request):
        return Response({'message': f"Authorized HOD access: {request.user.username}", 'role': request.user.role})


class SecurityOnlyView(APIView):
    permission_classes = [IsSecurityUser]

    def get(self, request):
        return Response({'message': f"Authorized security access: {request.user.username}", 'role': request.user.role})
