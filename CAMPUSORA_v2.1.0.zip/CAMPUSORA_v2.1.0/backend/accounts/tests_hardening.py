"""
Day 10 Production Hardening & Security Audit Test Suite for CAMPUSORA.
Validates:
1. DRF Rate limiting / throttling on authentication endpoints (429 Too Many Requests).
2. HttpOnly Cookie security attributes.
3. Role-based access control boundary enforcement.
4. Input sanitization and error masking.
"""

from django.test import TestCase
from django.core.cache import cache
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient
from rest_framework import status
from accounts.models import Role

User = get_user_model()


class SecurityHardeningTests(TestCase):
    def setUp(self):
        cache.clear()
        self.client = APIClient()
        self.student = User.objects.create_user(
            username='student_hardened',
            password='TestPassword123!',
            role=Role.STUDENT,
            department='Computer Science & Engineering'
        )
        self.security = User.objects.create_user(
            username='sec_hardened',
            password='SecurityPassword123!',
            role=Role.SECURITY,
            assigned_gate='College Main Gate'
        )

    def test_auth_login_throttling(self):
        """
        Verify that repeated rapid login attempts beyond rate limit trigger HTTP 429 Too Many Requests.
        Default rate: 15/minute.
        """
        for i in range(15):
            res = self.client.post('/api/v1/auth/login/', {
                'username': 'invalid_user',
                'password': 'WrongPassword123!'
            }, format='json')
            self.assertIn(res.status_code, [status.HTTP_401_UNAUTHORIZED, status.HTTP_400_BAD_REQUEST])

        # 16th request must be throttled with 429
        res_throttled = self.client.post('/api/v1/auth/login/', {
            'username': 'invalid_user',
            'password': 'WrongPassword123!'
        }, format='json')
        self.assertEqual(res_throttled.status_code, status.HTTP_429_TOO_MANY_REQUESTS)

    def test_jwt_httponly_cookie_flags(self):
        """
        Verifies login sets HttpOnly cookies with Lax SameSite.
        """
        res = self.client.post('/api/v1/auth/login/', {
            'username': 'student_hardened',
            'password': 'TestPassword123!'
        }, format='json')
        self.assertEqual(res.status_code, status.HTTP_200_OK)

        access_cookie = res.cookies.get('campusora_access_token')
        refresh_cookie = res.cookies.get('campusora_refresh_token')

        self.assertIsNotNone(access_cookie)
        self.assertTrue(access_cookie['httponly'])
        self.assertEqual(access_cookie['samesite'], 'Lax')
        self.assertEqual(access_cookie['path'], '/')

        self.assertIsNotNone(refresh_cookie)
        self.assertTrue(refresh_cookie['httponly'])

    def test_unauthorized_role_boundary_enforcement(self):
        """
        Verifies a Student cannot call Security verification endpoints or HOD endpoints.
        """
        self.client.force_authenticate(user=self.student)
        
        # Student trying to call security verification
        res_sec = self.client.post('/api/v1/gate-passes/verify/', {'token': 'fake_token'}, format='json')
        self.assertEqual(res_sec.status_code, status.HTTP_403_FORBIDDEN)

        # Student trying to call security return confirmation
        res_ret = self.client.post('/api/v1/gate-passes/confirm-return/', {'token': 'fake_token'}, format='json')
        self.assertEqual(res_ret.status_code, status.HTTP_403_FORBIDDEN)

    def test_malformed_input_sanitization(self):
        """
        Verifies SQL injection, HTML tags, or malformed data in clearance token are handled safely.
        """
        self.client.force_authenticate(user=self.security)
        malformed_inputs = [
            "'; DROP TABLE passes_gatepass; --",
            "<script>alert('xss')</script>",
            "A" * 1000, # Overflow attempt
            "",
            "   ",
        ]
        for bad_input in malformed_inputs:
            res = self.client.post('/api/v1/gate-passes/verify/', {'token': bad_input}, format='json')
            self.assertIn(res.status_code, [status.HTTP_400_BAD_REQUEST, status.HTTP_404_NOT_FOUND])
            self.assertFalse(res.data.get('valid', True))
