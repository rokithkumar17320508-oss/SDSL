from django.urls import path
from .views import (
    LoginView,
    RefreshTokenView,
    LogoutView,
    CurrentUserProfileView,
    StudentOnlyView,
    FacultyOnlyView,
    HodOnlyView,
    SecurityOnlyView,
)

urlpatterns = [
    path('login/', LoginView.as_view(), name='auth-login'),
    path('refresh/', RefreshTokenView.as_view(), name='auth-refresh'),
    path('logout/', LogoutView.as_view(), name='auth-logout'),
    path('me/', CurrentUserProfileView.as_view(), name='auth-me'),

    # Role restriction verification endpoints
    path('student-only/', StudentOnlyView.as_view(), name='auth-student-only'),
    path('faculty-only/', FacultyOnlyView.as_view(), name='auth-faculty-only'),
    path('hod-only/', HodOnlyView.as_view(), name='auth-hod-only'),
    path('security-only/', SecurityOnlyView.as_view(), name='auth-security-only'),
]
