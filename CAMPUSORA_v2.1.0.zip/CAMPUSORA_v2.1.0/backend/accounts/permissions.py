"""
Role-based authorization permissions for CAMPUSORA.
Strictly enforces access boundaries at the backend layer.
"""

from rest_framework.permissions import BasePermission
from .models import Role


class IsStudentUser(BasePermission):
    """
    Allows access only to authenticated users with the STUDENT role.
    """
    message = "Access restricted to authenticated students only."

    def has_permission(self, request, view):
        return bool(
            request.user
            and request.user.is_authenticated
            and request.user.role == Role.STUDENT
        )


class IsFacultyUser(BasePermission):
    """
    Allows access only to authenticated users with the FACULTY role.
    """
    message = "Access restricted to faculty advisors only."

    def has_permission(self, request, view):
        return bool(
            request.user
            and request.user.is_authenticated
            and request.user.role == Role.FACULTY
        )


class IsHodUser(BasePermission):
    """
    Allows access only to authenticated users with the HOD role.
    """
    message = "Access restricted to Heads of Department only."

    def has_permission(self, request, view):
        return bool(
            request.user
            and request.user.is_authenticated
            and request.user.role == Role.HOD
        )


class IsSecurityUser(BasePermission):
    """
    Allows access only to authenticated security personnel.
    """
    message = "Access restricted to authorized campus security personnel only."

    def has_permission(self, request, view):
        return bool(
            request.user
            and request.user.is_authenticated
            and request.user.role == Role.SECURITY
        )


class IsFacultyOrHodUser(BasePermission):
    """
    Allows access to either Faculty or HOD accounts.
    """
    message = "Access restricted to faculty advisors or Heads of Department."

    def has_permission(self, request, view):
        return bool(
            request.user
            and request.user.is_authenticated
            and request.user.role in [Role.FACULTY, Role.HOD]
        )
