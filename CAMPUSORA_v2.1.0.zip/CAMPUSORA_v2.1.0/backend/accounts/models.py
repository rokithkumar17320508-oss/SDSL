"""
CAMPUSORA User and Profile Models
Role-based authorization for Student, Faculty, HOD, and Security personnel.
"""

from django.contrib.auth.models import AbstractUser
from django.db import models


class Role(models.TextChoices):
    STUDENT = 'STUDENT', 'Student'
    FACULTY = 'FACULTY', 'Faculty Advisor'
    HOD = 'HOD', 'Head of Department'
    SECURITY = 'SECURITY', 'Security Personnel'
    WARDEN = 'WARDEN', 'Hostel Warden'


class User(AbstractUser):
    """
    Custom user model for CAMPUSORA.
    Uses AbstractUser with role-based segregation and institutional metadata.
    """
    role = models.CharField(
        max_length=20,
        choices=Role.choices,
        default=Role.STUDENT,
        db_index=True,
        help_text="Designated role within the CAMPUSORA portal"
    )
    phone_number = models.CharField(
        max_length=15,
        blank=True,
        help_text="Institutional or verified mobile contact number"
    )
    department = models.CharField(
        max_length=100,
        blank=True,
        help_text="Academic department (e.g. Computer Science & Engineering)"
    )
    assigned_gate = models.CharField(
        max_length=50,
        blank=True,
        default='College Main Gate',
        help_text="Designated security checkpoint gate"
    )

    @property
    def is_student(self):
        return self.role == Role.STUDENT

    @property
    def is_faculty(self):
        return self.role == Role.FACULTY

    @property
    def is_hod(self):
        return self.role == Role.HOD

    @property
    def is_security(self):
        return self.role == Role.SECURITY

    @property
    def is_warden(self):
        return self.role == Role.WARDEN

    def __str__(self):
        full_name = self.get_full_name()
        display = full_name if full_name else self.username
        return f"{display} ({self.get_role_display()})"


class StudentProfile(models.Model):
    """
    Academic and institutional details for student users.
    Avoids storing sensitive personal or financial information.
    """
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name='student_profile',
        limit_choices_to={'role': Role.STUDENT}
    )
    registration_number = models.CharField(
        max_length=30,
        unique=True,
        db_index=True,
        help_text="Unique University Registration / Roll Number (e.g. 2024CSE1084)"
    )
    department = models.CharField(
        max_length=100,
        help_text="Enrolled Academic Department"
    )
    year = models.PositiveSmallIntegerField(
        default=1,
        help_text="Current academic year (1-4)"
    )
    semester = models.PositiveSmallIntegerField(
        default=1,
        help_text="Current academic semester (1-8)"
    )
    section = models.CharField(
        max_length=10,
        blank=True,
        default='A',
        help_text="Class Section (e.g. A, B)"
    )
    room_number = models.CharField(
        max_length=50,
        blank=True,
        help_text="Hostel Block & Room or Day Scholar indicator"
    )
    hostel_block = models.CharField(
        max_length=50,
        blank=True,
        default='',
        help_text="Assigned residential block (e.g. BH-2, GH-1)"
    )
    parent_name = models.CharField(
        max_length=100,
        blank=True,
        default='',
        help_text="Full name of verified parent or legal guardian"
    )
    parent_email = models.EmailField(
        blank=True,
        default='',
        help_text="Verified email address for departure alerts"
    )
    parent_phone = models.CharField(
        max_length=20,
        blank=True,
        default='',
        help_text="Verified phone number for departure SMS alerts"
    )
    emergency_contact = models.CharField(
        max_length=15,
        blank=True,
        help_text="Emergency contact phone number"
    )
    advisor = models.ForeignKey(
        User,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='advisees',
        limit_choices_to={'role': Role.FACULTY},
        help_text="Assigned Faculty Advisor"
    )

    class Meta:
        verbose_name = "Student Profile"
        verbose_name_plural = "Student Profiles"
        ordering = ['registration_number']

    def __str__(self):
        name = self.user.get_full_name() or self.user.username
        return f"{name} ({self.registration_number}) - {self.department}"


class FacultyProfile(models.Model):
    """
    Institutional metadata for faculty advisors and department heads.
    """
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name='faculty_profile',
        limit_choices_to={'role__in': [Role.FACULTY, Role.HOD]}
    )
    employee_id = models.CharField(
        max_length=30,
        unique=True,
        db_index=True,
        help_text="Institutional Employee Identification Number (e.g. EMP-CSE-042)"
    )
    department = models.CharField(
        max_length=100,
        help_text="Academic Department"
    )
    designation = models.CharField(
        max_length=100,
        default="Assistant Professor",
        help_text="Academic Title / Designation"
    )
    cabin_number = models.CharField(
        max_length=50,
        blank=True,
        help_text="Office Cabin Location"
    )

    class Meta:
        verbose_name = "Faculty Profile"
        verbose_name_plural = "Faculty Profiles"
        ordering = ['employee_id']

    def __str__(self):
        name = self.user.get_full_name() or self.user.username
        return f"{name} ({self.employee_id}) - {self.department}"


class WardenProfile(models.Model):
    """
    Institutional metadata for hostel wardens.
    """
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name='warden_profile',
        limit_choices_to={'role': Role.WARDEN}
    )
    employee_id = models.CharField(
        max_length=30,
        unique=True,
        db_index=True,
        help_text="Institutional Employee Identification Number (e.g. EMP-WRD-001)"
    )
    assigned_hostel = models.CharField(
        max_length=50,
        db_index=True,
        help_text="Designated residential hostel block (e.g. BH-2, GH-1)"
    )
    cabin_office = models.CharField(
        max_length=50,
        blank=True,
        help_text="Warden Office Location"
    )

    class Meta:
        verbose_name = "Warden Profile"
        verbose_name_plural = "Warden Profiles"
        ordering = ['employee_id']

    def __str__(self):
        name = self.user.get_full_name() or self.user.username
        return f"{name} ({self.employee_id}) - {self.assigned_hostel}"

