"""
Automated Idempotency Tests for CAMPUSORA Demonstration Seeders.
Validates that repeated executions of the 240-student seeder
create zero duplicate student profiles, user records, or leave applications.
Runs inside an isolated Django test database — never touches the primary database.
"""

from django.test import TestCase
from django.core.management import call_command
from accounts.models import User, StudentProfile, Role
from leaves.models import LeaveApplication


class SeederIdempotencyTestCase(TestCase):
    """
    Validates that seed_cse_sections is 100% idempotent and safe for repeated runs.
    """

    def test_seeder_idempotency_and_zero_duplicates(self):
        # 1. First execution: provisions 240 First-Year CSE students
        call_command('seed_cse_sections')

        total_y1_first = StudentProfile.objects.filter(year=1, department='Computer Science & Engineering').count()
        total_users_first = User.objects.filter(role=Role.STUDENT, department='Computer Science & Engineering').count()
        total_apps_first = LeaveApplication.objects.count()

        self.assertEqual(total_y1_first, 240, f"Expected 240 students on first run, got {total_y1_first}")
        self.assertEqual(total_users_first, 240, f"Expected 240 user accounts, got {total_users_first}")
        self.assertGreater(total_apps_first, 0, "Expected leave applications to be seeded")

        # Verify each section has exactly 60 students
        for sec in ['A', 'B', 'C', 'D']:
            sec_cnt = StudentProfile.objects.filter(section=sec, year=1).count()
            self.assertEqual(sec_cnt, 60, f"Section CSE-{sec} has {sec_cnt} students instead of 60")

        # 2. Second execution: must not create any duplicates
        call_command('seed_cse_sections')

        total_y1_second = StudentProfile.objects.filter(year=1, department='Computer Science & Engineering').count()
        total_users_second = User.objects.filter(role=Role.STUDENT, department='Computer Science & Engineering').count()
        total_apps_second = LeaveApplication.objects.count()

        self.assertEqual(
            total_y1_second, total_y1_first,
            f"Idempotency violation: student count changed from {total_y1_first} to {total_y1_second}"
        )
        self.assertEqual(
            total_users_second, total_users_first,
            f"Idempotency violation: user count changed from {total_users_first} to {total_users_second}"
        )
        self.assertEqual(
            total_apps_second, total_apps_first,
            f"Idempotency violation: application count changed from {total_apps_first} to {total_apps_second}"
        )

        # Re-verify section integrity
        for sec in ['A', 'B', 'C', 'D']:
            sec_cnt = StudentProfile.objects.filter(section=sec, year=1).count()
            self.assertEqual(sec_cnt, 60, f"Section CSE-{sec} has {sec_cnt} students on second run")
