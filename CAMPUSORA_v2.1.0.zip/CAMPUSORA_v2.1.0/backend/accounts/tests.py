from django.test import TestCase
from django.contrib.auth import get_user_model
from django.contrib.auth.hashers import identify_hasher
from rest_framework.test import APIClient
from rest_framework import status
from rest_framework_simplejwt.tokens import RefreshToken, AccessToken
from rest_framework_simplejwt.token_blacklist.models import BlacklistedToken
from .models import Role, StudentProfile, FacultyProfile

User = get_user_model()


class UserModelTest(TestCase):
    def setUp(self):
        self.student_user = User.objects.create_user(
            username='arjun_sharma',
            email='arjun.sharma@campusora.edu',
            password='TestPassword123!',
            role=Role.STUDENT,
            department='Computer Science & Engineering',
            phone_number='+91 98765 43210'
        )

    def test_user_creation_and_argon2_hashing(self):
        self.assertEqual(self.student_user.username, 'arjun_sharma')
        self.assertTrue(self.student_user.is_student)
        self.assertFalse(self.student_user.is_faculty)
        
        # Verify Argon2 password hasher is used
        hasher = identify_hasher(self.student_user.password)
        self.assertEqual(hasher.algorithm, 'argon2')

    def test_student_profile(self):
        profile = StudentProfile.objects.create(
            user=self.student_user,
            registration_number='2024CSE1084',
            department='Computer Science & Engineering',
            year=3,
            semester=6,
            section='A',
            room_number='BH-2, Room 405',
            emergency_contact='+91 98765 00000'
        )
        self.assertEqual(profile.registration_number, '2024CSE1084')
        self.assertEqual(self.student_user.student_profile.year, 3)

    def test_faculty_profile(self):
        faculty_user = User.objects.create_user(
            username='dr_verma',
            email='skverma@campusora.edu',
            password='FacultyPassword123!',
            role=Role.FACULTY,
            department='Computer Science & Engineering'
        )
        profile = FacultyProfile.objects.create(
            user=faculty_user,
            employee_id='EMP-CSE-042',
            department='Computer Science & Engineering',
            designation='Associate Professor & Class Advisor',
            cabin_number='CS-302'
        )
        self.assertEqual(profile.employee_id, 'EMP-CSE-042')
        self.assertTrue(faculty_user.is_faculty)


class AuthenticationAndRBACTest(TestCase):
    def setUp(self):
        self.client = APIClient()

        # Student User
        self.student = User.objects.create_user(
            username='arjun',
            password='StudentPassword123!',
            role=Role.STUDENT,
            department='Computer Science & Engineering',
            first_name='Arjun',
            last_name='Sharma'
        )
        StudentProfile.objects.create(
            user=self.student,
            registration_number='2024CSE1084',
            department='Computer Science & Engineering',
            year=3,
            semester=6
        )

        # Faculty User
        self.faculty = User.objects.create_user(
            username='skverma',
            password='FacultyPassword123!',
            role=Role.FACULTY,
            department='Computer Science & Engineering',
            first_name='S. K.',
            last_name='Verma'
        )
        FacultyProfile.objects.create(
            user=self.faculty,
            employee_id='EMP-CSE-042',
            department='Computer Science & Engineering'
        )

        # HOD User
        self.hod = User.objects.create_user(
            username='rmehra',
            password='HodPassword123!',
            role=Role.HOD,
            department='Computer Science & Engineering',
            first_name='R.',
            last_name='Mehra'
        )

        # Security User
        self.security = User.objects.create_user(
            username='security_gate1',
            password='SecurityPassword123!',
            role=Role.SECURITY,
            department='Campus Safety & Security',
            first_name='Vikram',
            last_name='Singh'
        )

    def test_login_with_correct_credentials(self):
        response = self.client.post('/api/v1/auth/login/', {
            'username': 'arjun',
            'password': 'StudentPassword123!'
        })
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        data = response.json()
        self.assertIn('access', data)
        self.assertIn('refresh', data)
        self.assertEqual(data['user']['role'], 'STUDENT')
        self.assertEqual(data['user']['registration_number'], '2024CSE1084')
        
        # Verify HttpOnly cookies
        self.assertIn('campusora_access_token', response.cookies)
        self.assertIn('campusora_refresh_token', response.cookies)
        self.assertTrue(response.cookies['campusora_access_token']['httponly'])

    def test_login_with_incorrect_credentials(self):
        response = self.client.post('/api/v1/auth/login/', {
            'username': 'arjun',
            'password': 'WrongPassword999!'
        })
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertNotIn('access', response.json())

    def test_user_profile_me_endpoint(self):
        self.client.force_authenticate(user=self.student)
        response = self.client.get('/api/v1/auth/me/')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        data = response.json()
        self.assertEqual(data['username'], 'arjun')
        self.assertEqual(data['role'], 'STUDENT')
        self.assertEqual(data['registration_number'], '2024CSE1084')
        self.assertNotIn('password', data)

    def test_refresh_token_rotation_and_blacklisting(self):
        # Initial login
        login_res = self.client.post('/api/v1/auth/login/', {
            'username': 'arjun',
            'password': 'StudentPassword123!'
        })
        old_refresh = login_res.json()['refresh']

        # Call refresh endpoint
        refresh_res = self.client.post('/api/v1/auth/refresh/', {
            'refresh': old_refresh
        })
        self.assertEqual(refresh_res.status_code, status.HTTP_200_OK)
        new_refresh = refresh_res.json()['refresh']
        self.assertNotEqual(old_refresh, new_refresh)

        # Attempt to use blacklisted old refresh token
        retry_res = self.client.post('/api/v1/auth/refresh/', {
            'refresh': old_refresh
        })
        self.assertEqual(retry_res.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_logout_invalidates_refresh_token(self):
        login_res = self.client.post('/api/v1/auth/login/', {
            'username': 'arjun',
            'password': 'StudentPassword123!'
        })
        refresh_token = login_res.json()['refresh']

        # Logout
        logout_res = self.client.post('/api/v1/auth/logout/', {
            'refresh': refresh_token
        })
        self.assertEqual(logout_res.status_code, status.HTTP_200_OK)

        # Verify old refresh token is blacklisted
        refresh_attempt = self.client.post('/api/v1/auth/refresh/', {
            'refresh': refresh_token
        })
        self.assertEqual(refresh_attempt.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_role_based_access_control(self):
        # 1. Student access
        self.client.force_authenticate(user=self.student)
        self.assertEqual(self.client.get('/api/v1/auth/student-only/').status_code, status.HTTP_200_OK)
        self.assertEqual(self.client.get('/api/v1/auth/hod-only/').status_code, status.HTTP_403_FORBIDDEN)
        self.assertEqual(self.client.get('/api/v1/auth/faculty-only/').status_code, status.HTTP_403_FORBIDDEN)
        self.assertEqual(self.client.get('/api/v1/auth/security-only/').status_code, status.HTTP_403_FORBIDDEN)

        # 2. Faculty access
        self.client.force_authenticate(user=self.faculty)
        self.assertEqual(self.client.get('/api/v1/auth/faculty-only/').status_code, status.HTTP_200_OK)
        self.assertEqual(self.client.get('/api/v1/auth/student-only/').status_code, status.HTTP_403_FORBIDDEN)
        self.assertEqual(self.client.get('/api/v1/auth/hod-only/').status_code, status.HTTP_403_FORBIDDEN)

        # 3. HOD access
        self.client.force_authenticate(user=self.hod)
        self.assertEqual(self.client.get('/api/v1/auth/hod-only/').status_code, status.HTTP_200_OK)
        self.assertEqual(self.client.get('/api/v1/auth/security-only/').status_code, status.HTTP_403_FORBIDDEN)
        self.assertEqual(self.client.get('/api/v1/auth/student-only/').status_code, status.HTTP_403_FORBIDDEN)

        # 4. Security access
        self.client.force_authenticate(user=self.security)
        self.assertEqual(self.client.get('/api/v1/auth/security-only/').status_code, status.HTTP_200_OK)
        self.assertEqual(self.client.get('/api/v1/auth/hod-only/').status_code, status.HTTP_403_FORBIDDEN)
        self.assertEqual(self.client.get('/api/v1/auth/faculty-only/').status_code, status.HTTP_403_FORBIDDEN)

        # 5. Anonymous access
        self.client.logout()
        self.assertEqual(self.client.get('/api/v1/auth/student-only/').status_code, status.HTTP_401_UNAUTHORIZED)
        self.assertEqual(self.client.get('/api/v1/auth/faculty-only/').status_code, status.HTTP_401_UNAUTHORIZED)
        self.assertEqual(self.client.get('/api/v1/auth/hod-only/').status_code, status.HTTP_401_UNAUTHORIZED)
        self.assertEqual(self.client.get('/api/v1/auth/security-only/').status_code, status.HTTP_401_UNAUTHORIZED)
