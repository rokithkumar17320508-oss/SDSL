# CAMPUSORA Backend Service (Day 5 — PostgreSQL & Secure JWT Authentication)

Welcome to the **CAMPUSORA** backend service. This Django + Django REST Framework service powers the college leave management system with a native **PostgreSQL 18** database, **Argon2** password hashing, **SimpleJWT** token authentication with secure HttpOnly cookies, and strict Role-Based Access Control (RBAC).

---

## 1. System Overview & Architecture

- **Framework:** Django 5.2.x with Django REST Framework (DRF) 3.18.x
- **Python Version:** Python 3.14
- **Database Engine:** PostgreSQL 18.6 (`campusora_db` on `127.0.0.1:5433` / `127.0.0.1:5432`)
- **Database Driver:** `psycopg` (Psycopg 3.3.x with native binary bindings)
- **Password Hasher:** Argon2 (`argon2-cffi`)
- **Authentication:** `djangorestframework-simplejwt` with `token_blacklist`
- **Session Transport:** Secure HttpOnly cookies (`campusora_access_token`, `campusora_refresh_token`) with Bearer header fallback
- **CORS Protection:** Whitelisted to `http://localhost:5173` and `http://127.0.0.1:5173` with credentials support

---

## 2. Directory Structure

```
backend/
├── manage.py
├── requirements.txt
├── .env.example
├── .env                     # Local environment settings (git-ignored)
├── .gitignore
├── config/
│   ├── settings.py          # Security, DB, SimpleJWT, CORS, REST Framework settings
│   ├── urls.py              # Root router mounting /admin/ and /api/v1/
│   ├── api_urls.py          # API v1 versioned route dispatcher
│   ├── wsgi.py
│   └── asgi.py
├── accounts/
│   ├── models.py            # User (AbstractUser), StudentProfile, FacultyProfile
│   ├── authentication.py    # JWTCookieAuthentication class
│   ├── permissions.py       # IsStudentUser, IsFacultyUser, IsHodUser, IsSecurityUser
│   ├── serializers.py       # UserProfileSerializer, LoginSerializer
│   ├── views.py             # LoginView, RefreshTokenView, LogoutView, CurrentUserProfileView
│   ├── urls.py              # Routes for /auth/login/, /auth/refresh/, /auth/logout/, /auth/me/
│   ├── admin.py             # UserAdmin with role filters and metadata
│   ├── tests.py             # 12 unit tests for Argon2, login, refresh rotation, logout, RBAC
│   └── management/
│       └── commands/
│           └── seed_demo_data.py  # Instant demo data seeding matching Day 1-3
├── leaves/
│   ├── models.py            # LeaveApplication with date validation and auto-ID
│   ├── serializers.py       # LeaveApplicationSerializer & LeaveTypeSerializer
│   ├── views.py             # HealthCheckView, LeaveTypesView, Application views
│   ├── urls.py              # Routes for /health/, /leave-types/, /applications/
│   ├── admin.py             # LeaveApplication admin with search and filters
│   └── tests.py             # Date validation, status defaults, and API tests
└── approvals/
    ├── models.py            # ApprovalRecord (immutable audit log)
    ├── admin.py             # Read-only audit log in Django Admin
    └── tests.py             # Immutability and mandatory rejection remarks tests
```

---

## 3. PostgreSQL Database Configuration

### A. Dedicated Database & User
- **Database:** `campusora_db`
- **Owner / User:** `campusora_user`
- **Port:** `5433` (configured to prevent conflicts with default system services)
- **Host:** `127.0.0.1`

### B. Environment Variables (`backend/.env`)
```ini
SECRET_KEY=your_generated_secret_key_here
DEBUG=True
ALLOWED_HOSTS=localhost,127.0.0.1,0.0.0.0
CORS_ALLOWED_ORIGINS=http://localhost:5173,http://127.0.0.1:5173

# Database Settings (PostgreSQL 18)
DB_ENGINE=postgresql
DB_NAME=campusora_db
DB_USER=campusora_user
DB_PASSWORD=your_secure_db_password_here
DB_HOST=127.0.0.1
DB_PORT=5433
```

---

## 4. SQLite Data Migration to PostgreSQL (Completed)

All existing Day 4 records were safely migrated from SQLite into PostgreSQL using serialized Django fixtures (`sqlite_data_export.json`):
- **Users Migrated:** 5 (`admin`, `arjun`, `skverma`, `rmehra`, `security_gate1`)
- **Student Profiles:** 1 (Arjun Sharma, `2024CSE1084`)
- **Faculty Profiles:** 2 (`EMP-CSE-042`, `EMP-CSE-001`)
- **Leave Applications:** 4 (`APP-1035`, `APP-1042`, `APP-1050`, `APP-7220`)
- **Approval Records:** 3 (Immutable historical endorsements)
- **Backup:** Preserved at `backend/campusora_dev.sqlite3.bak`.

---

## 5. Authentication API Reference (`/api/v1/auth/`)

| Method | Endpoint | Description | Auth Required | Cookie Transport |
|---|---|---|---|---|
| `POST` | `/api/v1/auth/login/` | Validates credentials, sets HttpOnly cookies, returns safe user metadata | None | Sets `campusora_access_token` and `campusora_refresh_token` |
| `POST` | `/api/v1/auth/refresh/` | Rotates refresh token, invalidates old token, sets new cookies | None (reads cookie) | Updates cookies |
| `POST` | `/api/v1/auth/logout/` | Blacklists refresh token, deletes HttpOnly cookies | None (reads cookie) | Deletes cookies (max-age=0) |
| `GET` | `/api/v1/auth/me/` | Retrieves authenticated user profile | `IsAuthenticated` | Transmitted via cookie or header |

### Sample User Profile Response (`GET /api/v1/auth/me/`):
```json
{
  "id": 2,
  "username": "arjun",
  "email": "arjun.sharma@campusora.edu",
  "name": "Arjun Sharma",
  "role": "STUDENT",
  "role_display": "Student",
  "department": "Computer Science & Engineering",
  "phone_number": "+91 98765 43210",
  "registration_number": "2024CSE1084",
  "employee_id": null,
  "academic_details": {
    "year": 3,
    "semester": 6,
    "section": "A",
    "room_number": "BH-2, Room 405",
    "emergency_contact": "+91 98765 00000"
  }
}
```

---

## 6. Role-Based Access Control (RBAC)

The backend implements four dedicated permission classes (`accounts/permissions.py`):
1. `IsStudentUser`: Ensures only student accounts access student submissions and personal records.
2. `IsFacultyUser`: Ensures only faculty advisors access department leave queues.
3. `IsHodUser`: Ensures only Heads of Department access executive authorization queues.
4. `IsSecurityUser`: Ensures only security officers access gate verification terminals.

Cross-role violations return `403 Forbidden` (`{"detail": "Access restricted to ... only."}`).

---

## 7. Running Backend & Tests

```bash
# Activate virtual environment
source backend/.venv/bin/activate

# Run automated test suite (18 tests covering Argon2, JWT, and RBAC)
python backend/manage.py test

# Start development server
python backend/manage.py runserver 127.0.0.1:8000
```

---

## 8. Day 6 Integration Roadmap

1. Wire real backend CRUD for student leave applications (`POST /api/v1/applications/`).
2. Implement backend approval endpoints (`/api/v1/applications/{id}/forward/`, `/api/v1/applications/{id}/approve/`, `/api/v1/applications/{id}/reject/`).
3. Connect React Student, Faculty, and HOD dashboards to fetch and update live PostgreSQL data.
4. Implement Security Gate Pass verification API (`GET /api/v1/gate-pass/verify/{token}/`).
