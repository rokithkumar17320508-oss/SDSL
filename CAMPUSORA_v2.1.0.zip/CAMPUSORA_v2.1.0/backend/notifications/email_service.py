"""
Transactional Email Service for CAMPUSORA.
Renders branded HTML and plain-text email templates and delivers via configured backend.
"""

import logging
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from django.conf import settings

logger = logging.getLogger(__name__)


def send_campusora_email(
    subject: str,
    template_base_name: str,
    context: dict,
    recipient_list: list[str],
    from_email: str | None = None
) -> tuple[bool, str, str]:
    """
    Renders both HTML and plain-text templates and delivers an institutional email.
    
    Args:
        subject: The email subject line.
        template_base_name: Base name of template without extension (e.g. 'application_submitted').
        context: Context dictionary passed into the templates.
        recipient_list: List of destination email addresses.
        from_email: Sender address, defaults to settings.DEFAULT_FROM_EMAIL.
        
    Returns:
        tuple[bool, str, str]: (is_success, error_message, plain_text_body)
    """
    if not recipient_list:
        return False, "Recipient list is empty.", ""

    sender = from_email or getattr(
        settings, 'DEFAULT_FROM_EMAIL', 'CAMPUSORA Alerts <notifications@campusora.edu>'
    )
    html_template = f"notifications/email/{template_base_name}.html"
    text_template = f"notifications/email/{template_base_name}.txt"

    # Augment context with standard institutional branding
    context_data = {
        'institution_name': 'CAMPUSORA',
        'tagline': 'Smarter Campus. Simpler Life.',
        'support_email': 'support@campusora.edu',
        'current_year': 2026,
        **context
    }

    try:
        html_content = render_to_string(html_template, context_data)
    except Exception as exc:
        err = f"Failed to render HTML email template '{html_template}': {exc}"
        logger.error(err)
        return False, err, ""

    try:
        text_content = render_to_string(text_template, context_data)
    except Exception:
        # Fallback to minimal text if text template fails
        text_content = f"CAMPUSORA Notification: {subject}\n\nPlease check your student/faculty portal."

    try:
        email = EmailMultiAlternatives(
            subject=subject,
            body=text_content,
            from_email=sender,
            to=recipient_list
        )
        email.attach_alternative(html_content, "text/html")
        email.send(fail_silently=False)
        return True, "", text_content
    except Exception as exc:
        err = f"Failed to send email to {recipient_list}: {exc}"
        logger.exception(err)
        return False, err, text_content
