"""
CAMPUSORA Notification Models
Tracks delivery logs, recipient metadata, and audit records for transactional emails and SMS alerts.
"""

from django.db import models
from django.conf import settings
from django.utils import timezone


class NotificationChannel(models.TextChoices):
    EMAIL = 'EMAIL', 'Email Notification'
    SMS = 'SMS', 'SMS Alert'


class NotificationType(models.TextChoices):
    APPLICATION_SUBMITTED = 'APPLICATION_SUBMITTED', 'Application Submitted'
    FACULTY_FORWARDED = 'FACULTY_FORWARDED', 'Application Recommended to HOD'
    FACULTY_REJECTED = 'FACULTY_REJECTED', 'Application Rejected by Faculty'
    HOD_APPROVED = 'HOD_APPROVED', 'Application Approved by HOD'
    HOD_REJECTED = 'HOD_REJECTED', 'Application Rejected by HOD'
    PARENT_EXIT_ALERT = 'PARENT_EXIT_ALERT', 'Parent Gate Exit Alert'
    WARDEN_EXIT_ALERT = 'WARDEN_EXIT_ALERT', 'Hostel Warden Exit Alert'
    PARENT_RETURN_ALERT = 'PARENT_RETURN_ALERT', 'Parent Gate Return Alert'
    WARDEN_RETURN_ALERT = 'WARDEN_RETURN_ALERT', 'Hostel Warden Return Alert'



class DeliveryStatus(models.TextChoices):
    PENDING = 'PENDING', 'Pending'
    SENT = 'SENT', 'Sent'
    FAILED = 'FAILED', 'Failed'


class RecipientType(models.TextChoices):
    STUDENT = 'STUDENT', 'Student'
    PARENT = 'PARENT', 'Parent / Guardian'
    WARDEN = 'WARDEN', 'Hostel Warden'
    FACULTY = 'FACULTY', 'Faculty Advisor'
    SECURITY = 'SECURITY', 'Security Personnel'


class NotificationLog(models.Model):
    """
    Immutable audit log of all automated notification attempts (Email and SMS).
    Captures delivery outcome, recipient addresses, related objects, and error traces.
    """
    recipient_email = models.CharField(
        max_length=255,
        blank=True,
        default='',
        help_text="Target email address for email notifications"
    )
    recipient_phone = models.CharField(
        max_length=30,
        blank=True,
        default='',
        help_text="Target phone number for SMS alerts"
    )
    recipient_name = models.CharField(
        max_length=150,
        blank=True,
        default='',
        help_text="Display name of the recipient"
    )
    recipient_type = models.CharField(
        max_length=20,
        choices=RecipientType.choices,
        default=RecipientType.STUDENT,
        db_index=True
    )
    recipient_user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='notifications',
        help_text="Registered user if the recipient is an enrolled user"
    )
    notification_type = models.CharField(
        max_length=30,
        choices=NotificationType.choices,
        db_index=True
    )
    channel = models.CharField(
        max_length=10,
        choices=NotificationChannel.choices,
        default=NotificationChannel.EMAIL,
        db_index=True
    )
    status = models.CharField(
        max_length=15,
        choices=DeliveryStatus.choices,
        default=DeliveryStatus.PENDING,
        db_index=True
    )
    subject = models.CharField(
        max_length=255,
        blank=True,
        default='',
        help_text="Email subject or SMS summary"
    )
    message_body = models.TextField(
        blank=True,
        default='',
        help_text="Rendered text body or SMS content"
    )
    error_message = models.TextField(
        blank=True,
        default='',
        help_text="Exception message or provider error if delivery failed"
    )
    related_application = models.ForeignKey(
        'leaves.LeaveApplication',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='notifications',
        help_text="Related leave application if applicable"
    )
    related_gate_event = models.ForeignKey(
        'passes.GateEvent',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='notifications',
        help_text="Related gate clearance exit event if applicable"
    )
    metadata = models.JSONField(
        default=dict,
        blank=True,
        help_text="Additional structured context (e.g. gate name, hostel block, etc.)"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        db_index=True
    )
    sent_at = models.DateTimeField(
        null=True,
        blank=True
    )

    class Meta:
        verbose_name = "Notification Log"
        verbose_name_plural = "Notification Logs"
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['notification_type', 'status']),
            models.Index(fields=['recipient_email', 'status']),
            models.Index(fields=['created_at']),
        ]

    def __str__(self):
        target = self.recipient_email or self.recipient_phone or 'Unknown'
        return f"[{self.get_channel_display()}] {self.get_notification_type_display()} -> {target} ({self.get_status_display()})"

    def mark_sent(self):
        self.status = DeliveryStatus.SENT
        self.sent_at = timezone.now()
        self.save(update_fields=['status', 'sent_at'])

    def mark_failed(self, error: str):
        self.status = DeliveryStatus.FAILED
        self.error_message = str(error)
        self.save(update_fields=['status', 'error_message'])
