"""
URL Routing for CAMPUSORA Notifications.
"""

from django.urls import path
from .views import NotificationListView, NotificationSummaryView

app_name = 'notifications'

urlpatterns = [
    path('', NotificationListView.as_view(), name='notification-list'),
    path('summary/', NotificationSummaryView.as_view(), name='notification-summary'),
]
