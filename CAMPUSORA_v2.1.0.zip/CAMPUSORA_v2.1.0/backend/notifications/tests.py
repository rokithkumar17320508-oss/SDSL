"""
Comprehensive Automated Tests for CAMPUSORA Notifications & Parent/Warden Alerts.
Covers:
1. Student Lifecycle Notifications (Submitted, Recommended, Approved, Rejected)
2. Parent Exit Alerts (Email & SMS)
3. Hostel Warden Targeted Alerts (Strict block isolation)
4. Duplicate Notification Suppression
5. Error Tolerance & Graceful Degradation
6. API Access Control & Permissions
"""

from datetime import date, timedelta
from django.utils import timezone
from django.test import TestCase, override_settings
from django.core import mail
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient
from rest_framework import status

from accounts.models import Role, StudentProfile, FacultyProfile, WardenProfile
from leaves.models import LeaveApplication, LeaveType, LeaveStatus
from passes.models import GatePass, GateEvent, GateType, PassStatus, EventType, VerificationOutcome
from passes.utils import derive_pass_token, hash_token
from notifications.models import (
    NotificationLog,
    NotificationType,
    NotificationChannel,
    DeliveryStatus,
    RecipientType,
)
from notifications.sms import MockSMSProvider, get_sms_provider

User = get_user_model()


@override_settings(
    EMAIL_BACKEND='django.core.mail.backends.locmem.EmailBackend',
    SMS_PROVIDER='mock'
)
class NotificationServiceTests(TestCase):
    """
    Unit and integration tests for notification triggers and dispatch services.
    """
    def setUp(self):
        MockSMSProvider.reset()
        mail.outbox = []

        # Create Student
        self.student = User.objects.create_user(
            username='test_student',
            email='student@campusora.edu',
            password='TestPassword123!',
            first_name='Arjun',
            last_name='Sharma',
            role=Role.STUDENT,
            department='Computer Science & Engineering'
        )
        self.student_profile = StudentProfile.objects.create(
            user=self.student,
            registration_number='2024CSE1084',
            department='Computer Science & Engineering',
            year=3,
            semester=6,
            section='A',
            room_number='BH-2, Room 405',
            hostel_block='BH-2',
            parent_name='Sunil Sharma',
            parent_email='parent.sharma@example.com',
            parent_phone='+919876500001'
        )

        # Create Faculty
        self.faculty = User.objects.create_user(
            username='test_faculty',
            email='faculty@campusora.edu',
            password='TestPassword123!',
            first_name='S. K.',
            last_name='Verma',
            role=Role.FACULTY,
            department='Computer Science & Engineering'
        )
        self.faculty_profile = FacultyProfile.objects.create(
            user=self.faculty,
            employee_id='EMP-FAC-01',
            department='Computer Science & Engineering',
            designation='Class Advisor'
        )
        self.student_profile.advisor = self.faculty
        self.student_profile.save()

        # Create HOD
        self.hod = User.objects.create_user(
            username='test_hod',
            email='hod@campusora.edu',
            password='TestPassword123!',
            first_name='R.',
            last_name='Mehra',
            role=Role.HOD,
            department='Computer Science & Engineering'
        )

        # Create Security
        self.security = User.objects.create_user(
            username='test_security',
            email='security@campusora.edu',
            password='TestPassword123!',
            first_name='Vikram',
            last_name='Singh',
            role=Role.SECURITY,
            assigned_gate='College Main Gate'
        )

        # Create Wardens (BH-2 and GH-1)
        self.warden_bh2_user = User.objects.create_user(
            username='warden_bh2',
            email='warden.bh2@campusora.edu',
            password='TestPassword123!',
            first_name='Rajesh',
            last_name='Patil',
            role=Role.WARDEN
        )
        self.warden_bh2_profile = WardenProfile.objects.create(
            user=self.warden_bh2_user,
            employee_id='EMP-WRD-001',
            assigned_hostel='BH-2'
        )

        self.warden_gh1_user = User.objects.create_user(
            username='warden_gh1',
            email='warden.gh1@campusora.edu',
            password='TestPassword123!',
            first_name='Ananya',
            last_name='Sen',
            role=Role.WARDEN
        )
        self.warden_gh1_profile = WardenProfile.objects.create(
            user=self.warden_gh1_user,
            employee_id='EMP-WRD-002',
            assigned_hostel='GH-1'
        )

        self.client = APIClient()

    def test_student_submission_triggers_email(self):
        """
        When student submits a leave application, a confirmation email is dispatched.
        """
        self.client.force_authenticate(user=self.student)
        payload = {
            'type': LeaveType.HOSTEL_OUTPASS,
            'startDate': (date.today() + timedelta(days=1)).isoformat(),
            'endDate': (date.today() + timedelta(days=2)).isoformat(),
            'reason': 'Visiting parents over weekend.'
        }
        with self.captureOnCommitCallbacks(execute=True):
            response = self.client.post('/api/v1/applications/', payload)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

        app_id = response.data['application_id']
        app = LeaveApplication.objects.get(application_id=app_id)

        # Verify email in outbox
        self.assertEqual(len(mail.outbox), 1)
        sent_mail = mail.outbox[0]
        self.assertIn(self.student.email, sent_mail.to)
        self.assertIn(app_id, sent_mail.subject)

        # Verify NotificationLog
        log = NotificationLog.objects.filter(
            related_application=app,
            notification_type=NotificationType.APPLICATION_SUBMITTED
        ).first()
        self.assertIsNotNone(log)
        self.assertEqual(log.status, DeliveryStatus.SENT)
        self.assertEqual(log.recipient_email, self.student.email)

    def test_faculty_forward_triggers_email(self):
        """
        Faculty recommendation triggers notification to student.
        """
        app = LeaveApplication.objects.create(
            student=self.student,
            leave_type=LeaveType.REGULAR_LEAVE,
            start_date=date.today() + timedelta(days=1),
            end_date=date.today() + timedelta(days=2),
            reason='Academic conference',
            status=LeaveStatus.PENDING_FACULTY
        )

        self.client.force_authenticate(user=self.faculty)
        with self.captureOnCommitCallbacks(execute=True):
            response = self.client.post(f'/api/v1/applications/{app.application_id}/forward/', {
                'remarks': 'Recommended for attendance.'
            })
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        self.assertEqual(len(mail.outbox), 1)
        self.assertIn("Recommended to HOD", mail.outbox[0].subject)

        log = NotificationLog.objects.filter(
            related_application=app,
            notification_type=NotificationType.FACULTY_FORWARDED
        ).first()
        self.assertIsNotNone(log)
        self.assertEqual(log.status, DeliveryStatus.SENT)

    def test_faculty_rejection_triggers_email(self):
        """
        Faculty rejection triggers notification with reason to student.
        """
        app = LeaveApplication.objects.create(
            student=self.student,
            leave_type=LeaveType.REGULAR_LEAVE,
            start_date=date.today() + timedelta(days=1),
            end_date=date.today() + timedelta(days=2),
            reason='Personal reasons',
            status=LeaveStatus.PENDING_FACULTY
        )

        self.client.force_authenticate(user=self.faculty)
        with self.captureOnCommitCallbacks(execute=True):
            response = self.client.post(f'/api/v1/applications/{app.application_id}/reject/', {
                'remarks': 'Attendance shortage below 75%.'
            })
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        self.assertEqual(len(mail.outbox), 1)
        self.assertIn("Rejected", mail.outbox[0].subject)

        log = NotificationLog.objects.filter(
            related_application=app,
            notification_type=NotificationType.FACULTY_REJECTED
        ).first()
        self.assertIsNotNone(log)
        self.assertEqual(log.status, DeliveryStatus.SENT)

    def test_hod_approval_triggers_email(self):
        """
        HOD approval triggers notification that gate pass is active.
        """
        app = LeaveApplication.objects.create(
            student=self.student,
            leave_type=LeaveType.REGULAR_LEAVE,
            start_date=date.today() + timedelta(days=1),
            end_date=date.today() + timedelta(days=2),
            reason='Department project',
            status=LeaveStatus.PENDING_HOD
        )

        self.client.force_authenticate(user=self.hod)
        with self.captureOnCommitCallbacks(execute=True):
            response = self.client.post(f'/api/v1/applications/{app.application_id}/approve/', {
                'remarks': 'Approved by HOD.'
            })
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        self.assertEqual(len(mail.outbox), 1)
        self.assertIn("Approved", mail.outbox[0].subject)

        log = NotificationLog.objects.filter(
            related_application=app,
            notification_type=NotificationType.HOD_APPROVED
        ).first()
        self.assertIsNotNone(log)
        self.assertEqual(log.status, DeliveryStatus.SENT)

    def test_hod_rejection_triggers_email(self):
        """
        HOD rejection triggers notification with remarks.
        """
        app = LeaveApplication.objects.create(
            student=self.student,
            leave_type=LeaveType.REGULAR_LEAVE,
            start_date=date.today() + timedelta(days=1),
            end_date=date.today() + timedelta(days=2),
            reason='Department project',
            status=LeaveStatus.PENDING_HOD
        )

        self.client.force_authenticate(user=self.hod)
        with self.captureOnCommitCallbacks(execute=True):
            response = self.client.post(f'/api/v1/applications/{app.application_id}/reject/', {
                'remarks': 'Exam schedules conflict.'
            })
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        self.assertEqual(len(mail.outbox), 1)
        self.assertIn("Declined", mail.outbox[0].subject)

        log = NotificationLog.objects.filter(
            related_application=app,
            notification_type=NotificationType.HOD_REJECTED
        ).first()
        self.assertIsNotNone(log)
        self.assertEqual(log.status, DeliveryStatus.SENT)

    def test_security_confirm_exit_triggers_parent_and_warden_alerts(self):
        """
        Security exit confirmation triggers:
        1. Parent Email alert
        2. Parent SMS alert
        3. Assigned Hostel Warden alert (BH-2 only)
        4. Excludes unrelated wardens (GH-1)
        """
        app = LeaveApplication.objects.create(
            student=self.student,
            leave_type=LeaveType.HOSTEL_OUTPASS,
            start_date=date.today(),
            end_date=date.today() + timedelta(days=2),
            reason='Home visit',
            status=LeaveStatus.HOD_APPROVED
        )
        now = timezone.now()
        gate_pass = GatePass.objects.create(
            leave_application=app,
            gate_type=GateType.BOTH,
            valid_from=now - timedelta(hours=1),
            valid_until=now + timedelta(days=2),
            status=PassStatus.ACTIVE
        )
        raw_token = derive_pass_token(gate_pass.pass_id, str(app.application_id))
        gate_pass.token_hash = hash_token(raw_token)
        gate_pass.save()

        self.client.force_authenticate(user=self.security)
        with self.captureOnCommitCallbacks(execute=True):
            response = self.client.post('/api/v1/gate-passes/confirm-exit/', {
                'token': raw_token,
                'remarks': 'Identity confirmed via photo ID.'
            })
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        # Verify Pass transitioned to USED
        gate_pass.refresh_from_db()
        self.assertEqual(gate_pass.status, PassStatus.USED)

        # Check emails delivered (Parent email + BH-2 Warden email = 2 emails)
        self.assertEqual(len(mail.outbox), 2)
        recipients = [m.to[0] for m in mail.outbox]
        self.assertIn(self.student_profile.parent_email, recipients)
        self.assertIn(self.warden_bh2_user.email, recipients)
        self.assertNotIn(self.warden_gh1_user.email, recipients)  # Unrelated warden MUST NOT be notified

        # Check SMS delivered to parent
        self.assertEqual(len(MockSMSProvider.sent_messages), 1)
        sms = MockSMSProvider.sent_messages[0]
        self.assertEqual(sms['to'], self.student_profile.parent_phone)
        self.assertIn("Arjun Sharma", sms['message'])
        self.assertIn("College Main Gate", sms['message'])
        # Never expose token
        self.assertNotIn(raw_token, sms['message'])

        # Verify database logs
        parent_email_log = NotificationLog.objects.filter(
            recipient_email=self.student_profile.parent_email,
            notification_type=NotificationType.PARENT_EXIT_ALERT,
            channel=NotificationChannel.EMAIL
        ).first()
        self.assertIsNotNone(parent_email_log)
        self.assertEqual(parent_email_log.status, DeliveryStatus.SENT)

        parent_sms_log = NotificationLog.objects.filter(
            recipient_phone=self.student_profile.parent_phone,
            notification_type=NotificationType.PARENT_EXIT_ALERT,
            channel=NotificationChannel.SMS
        ).first()
        self.assertIsNotNone(parent_sms_log)
        self.assertEqual(parent_sms_log.status, DeliveryStatus.SENT)

        warden_log = NotificationLog.objects.filter(
            recipient_email=self.warden_bh2_user.email,
            notification_type=NotificationType.WARDEN_EXIT_ALERT
        ).first()
        self.assertIsNotNone(warden_log)
        self.assertEqual(warden_log.status, DeliveryStatus.SENT)

    def test_duplicate_notification_prevention(self):
        """
        Subsequent dispatch calls for the same event do not re-send or duplicate logs.
        """
        app = LeaveApplication.objects.create(
            student=self.student,
            leave_type=LeaveType.REGULAR_LEAVE,
            start_date=date.today() + timedelta(days=1),
            end_date=date.today() + timedelta(days=2),
            reason='Family event',
            status=LeaveStatus.PENDING_FACULTY
        )

        from notifications.services import notify_application_submitted
        with self.captureOnCommitCallbacks(execute=True):
            notify_application_submitted(app)
        self.assertEqual(len(mail.outbox), 1)
        self.assertEqual(NotificationLog.objects.filter(related_application=app).count(), 1)

        # Trigger again
        with self.captureOnCommitCallbacks(execute=True):
            notify_application_submitted(app)
        # Should still be 1 (no duplicate sent)
        self.assertEqual(len(mail.outbox), 1)
        self.assertEqual(NotificationLog.objects.filter(related_application=app).count(), 1)

    def test_fail_safe_notification_error_does_not_break_exit(self):
        """
        If SMS provider fails or email service encounters an error,
        the confirmed gate exit remains valid and USED; failure is logged.
        """
        MockSMSProvider.should_fail = True
        MockSMSProvider.failure_message = "Network gateway timeout"

        app = LeaveApplication.objects.create(
            student=self.student,
            leave_type=LeaveType.DAY_PASS,
            start_date=date.today(),
            end_date=date.today(),
            reason='Hospital visit',
            status=LeaveStatus.HOD_APPROVED
        )
        now = timezone.now()
        gate_pass = GatePass.objects.create(
            leave_application=app,
            gate_type=GateType.COLLEGE_MAIN_GATE,
            valid_from=now - timedelta(hours=1),
            valid_until=now + timedelta(hours=8),
            status=PassStatus.ACTIVE
        )
        raw_token = derive_pass_token(gate_pass.pass_id, str(app.application_id))
        gate_pass.token_hash = hash_token(raw_token)
        gate_pass.save()

        self.client.force_authenticate(user=self.security)
        with self.captureOnCommitCallbacks(execute=True):
            response = self.client.post('/api/v1/gate-passes/confirm-exit/', {
                'token': raw_token
            })
        # Exit MUST succeed regardless of notification failure
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        gate_pass.refresh_from_db()
        self.assertEqual(gate_pass.status, PassStatus.USED)

        # Check that the failed SMS was recorded as FAILED in PostgreSQL
        failed_sms_log = NotificationLog.objects.filter(
            recipient_phone=self.student_profile.parent_phone,
            channel=NotificationChannel.SMS,
            status=DeliveryStatus.FAILED
        ).first()
        self.assertIsNotNone(failed_sms_log)
        self.assertIn("Network gateway timeout", failed_sms_log.error_message)

    def test_notifications_api_rbac(self):
        """
        Test /api/v1/notifications/ endpoints and role access control.
        """
        # Anonymous is rejected
        res = self.client.get('/api/v1/notifications/')
        self.assertEqual(res.status_code, status.HTTP_401_UNAUTHORIZED)

        # Student sees own notifications
        NotificationLog.objects.create(
            recipient_email=self.student.email,
            recipient_user=self.student,
            notification_type=NotificationType.APPLICATION_SUBMITTED,
            status=DeliveryStatus.SENT,
            subject='Student Note'
        )
        NotificationLog.objects.create(
            recipient_email=self.warden_bh2_user.email,
            recipient_user=self.warden_bh2_user,
            notification_type=NotificationType.WARDEN_EXIT_ALERT,
            status=DeliveryStatus.SENT,
            subject='Warden Note'
        )

        self.client.force_authenticate(user=self.student)
        res = self.client.get('/api/v1/notifications/')
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        # Student should only see 1 notification
        self.assertEqual(len(res.data['results'] if 'results' in res.data else res.data), 1)

        # Summary endpoint
        res_summary = self.client.get('/api/v1/notifications/summary/')
        self.assertEqual(res_summary.status_code, status.HTTP_200_OK)
        self.assertEqual(res_summary.data['total'], 1)
        self.assertEqual(res_summary.data['sent'], 1)
