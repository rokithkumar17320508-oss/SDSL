"""
Notification Dispatch & Lifecycle Services for CAMPUSORA.
Guarantees transaction decoupling (on_commit), duplicate prevention, and fail-safe execution.
"""

import logging
from django.db import transaction
from django.utils import timezone
from .models import (
    NotificationLog,
    NotificationType,
    NotificationChannel,
    DeliveryStatus,
    RecipientType,
)
from .email_service import send_campusora_email
from .sms import get_sms_provider
from accounts.models import WardenProfile

logger = logging.getLogger(__name__)


def _dispatch_safely(dispatch_fn, *args, **kwargs):
    """
    Decouples execution using transaction.on_commit and wraps in try-except to prevent rollbacks.
    """
    def runner():
        try:
            dispatch_fn(*args, **kwargs)
        except Exception as exc:
            logger.exception(f"Unhandled exception in notification task '{dispatch_fn.__name__}': {exc}")

    try:
        transaction.on_commit(runner)
    except Exception:
        # If outside an active transaction block, execute immediately
        runner()


# ---------------------------------------------------------------------------
# 1. Student Application Notifications
# ---------------------------------------------------------------------------

def _send_student_application_notification(
    application,
    notification_type: str,
    subject: str,
    template_name: str,
    extra_context: dict | None = None
):
    student = application.student
    student_email = student.email
    if not student_email:
        logger.warning(f"Student {student.username} has no email address configured. Skipping notification.")
        return

    # Duplicate prevention: do not re-send if already marked SENT
    if NotificationLog.objects.filter(
        related_application=application,
        notification_type=notification_type,
        channel=NotificationChannel.EMAIL,
        status=DeliveryStatus.SENT
    ).exists():
        logger.info(f"Duplicate notification suppressed: {notification_type} for app {application.application_id}")
        return

    student_name = student.get_full_name() or student.username
    reg_no = student.student_profile.registration_number if hasattr(student, 'student_profile') else 'N/A'
    dept = student.student_profile.department if hasattr(student, 'student_profile') else student.department

    context = {
        'student_name': student_name,
        'registration_number': reg_no,
        'department': dept,
        'application_id': application.application_id,
        'leave_type': application.get_leave_type_display(),
        'start_date': application.start_date.strftime('%d %b %Y'),
        'end_date': application.end_date.strftime('%d %b %Y'),
        'reason': application.reason,
        'subject': subject,
        **(extra_context or {})
    }

    # Initialize log entry
    log_entry = NotificationLog.objects.create(
        recipient_email=student_email,
        recipient_name=student_name,
        recipient_type=RecipientType.STUDENT,
        recipient_user=student,
        notification_type=notification_type,
        channel=NotificationChannel.EMAIL,
        status=DeliveryStatus.PENDING,
        subject=subject,
        related_application=application,
        metadata={
            'application_id': application.application_id,
            'leave_type': application.leave_type,
            'registration_number': reg_no,
        }
    )

    try:
        success, err_msg, text_body = send_campusora_email(
            subject=subject,
            template_base_name=template_name,
            context=context,
            recipient_list=[student_email]
        )
        log_entry.message_body = text_body
        if success:
            log_entry.mark_sent()
        else:
            log_entry.mark_failed(err_msg)
    except Exception as exc:
        log_entry.mark_failed(str(exc))


def notify_application_submitted(application):
    """
    Triggered when a student submits a new leave application.
    """
    def action():
        _send_student_application_notification(
            application=application,
            notification_type=NotificationType.APPLICATION_SUBMITTED,
            subject=f"Leave Application Received — {application.application_id}",
            template_name="application_submitted"
        )
    _dispatch_safely(action)


def notify_faculty_forwarded(application, reviewer, remarks=""):
    """
    Triggered when a faculty advisor recommends and forwards an application to the HOD.
    """
    def action():
        reviewer_name = reviewer.get_full_name() or reviewer.username
        _send_student_application_notification(
            application=application,
            notification_type=NotificationType.FACULTY_FORWARDED,
            subject=f"Application Recommended to HOD — {application.application_id}",
            template_name="faculty_forwarded",
            extra_context={
                'faculty_name': reviewer_name,
                'remarks': remarks or "Academic standing verified. Recommended to HOD.",
            }
        )
    _dispatch_safely(action)


def notify_faculty_rejected(application, reviewer, remarks=""):
    """
    Triggered when a faculty advisor rejects an application.
    """
    def action():
        reviewer_name = reviewer.get_full_name() or reviewer.username
        _send_student_application_notification(
            application=application,
            notification_type=NotificationType.FACULTY_REJECTED,
            subject=f"Leave Application Rejected by Faculty — {application.application_id}",
            template_name="faculty_rejected",
            extra_context={
                'faculty_name': reviewer_name,
                'remarks': remarks or "Policy criteria not met.",
            }
        )
    _dispatch_safely(action)


def notify_hod_approved(application, reviewer, remarks=""):
    """
    Triggered when HOD grants final approval, activating the digital gate pass.
    """
    def action():
        reviewer_name = reviewer.get_full_name() or reviewer.username
        _send_student_application_notification(
            application=application,
            notification_type=NotificationType.HOD_APPROVED,
            subject=f"Leave Application Approved — Gate Pass Active ({application.application_id})",
            template_name="hod_approved",
            extra_context={
                'hod_name': reviewer_name,
                'remarks': remarks or "Departmental clearance granted. Gate pass authorized.",
            }
        )
    _dispatch_safely(action)


def notify_hod_rejected(application, reviewer, remarks=""):
    """
    Triggered when HOD rejects an application.
    """
    def action():
        reviewer_name = reviewer.get_full_name() or reviewer.username
        _send_student_application_notification(
            application=application,
            notification_type=NotificationType.HOD_REJECTED,
            subject=f"Leave Application Declined by HOD — {application.application_id}",
            template_name="hod_rejected",
            extra_context={
                'hod_name': reviewer_name,
                'remarks': remarks or "Clearance not approved.",
            }
        )
    _dispatch_safely(action)


# ---------------------------------------------------------------------------
# 2. Gate Departure Alerts (Parent & Hostel Warden)
# ---------------------------------------------------------------------------

def _dispatch_parent_alerts(gate_event):
    """
    Delivers Parent/Guardian departure alerts via Email and SMS.
    Never exposes QR tokens or authentication credentials.
    """
    student = gate_event.student
    student_profile = getattr(student, 'student_profile', None)
    if not student_profile:
        logger.warning(f"Student {student.username} has no profile. Cannot retrieve parent details.")
        return

    parent_name = student_profile.parent_name or "Parent / Guardian"
    parent_email = student_profile.parent_email
    parent_phone = student_profile.parent_phone
    student_name = student.get_full_name() or student.username
    reg_no = student_profile.registration_number
    gate_name = gate_event.gate_type or "Authorized Gate"
    exit_time_str = gate_event.timestamp.strftime('%d %b %Y, %I:%M %p')
    leave_app = gate_event.gate_pass.leave_application
    leave_type_str = leave_app.get_leave_type_display() if leave_app else "Authorized Exit"

    # A. Parent Email Alert
    if parent_email:
        # Check duplicate
        if not NotificationLog.objects.filter(
            related_gate_event=gate_event,
            recipient_email=parent_email,
            notification_type=NotificationType.PARENT_EXIT_ALERT,
            channel=NotificationChannel.EMAIL,
            status=DeliveryStatus.SENT
        ).exists():
            subject = f"Campus Departure Notice: {student_name} ({reg_no})"
            log_email = NotificationLog.objects.create(
                recipient_email=parent_email,
                recipient_name=parent_name,
                recipient_type=RecipientType.PARENT,
                recipient_user=None,
                notification_type=NotificationType.PARENT_EXIT_ALERT,
                channel=NotificationChannel.EMAIL,
                status=DeliveryStatus.PENDING,
                subject=subject,
                related_application=leave_app,
                related_gate_event=gate_event,
                metadata={
                    'student_name': student_name,
                    'registration_number': reg_no,
                    'gate': gate_name,
                    'exit_time': exit_time_str,
                }
            )
            try:
                success, err_msg, text_body = send_campusora_email(
                    subject=subject,
                    template_base_name="parent_exit_alert",
                    context={
                        'parent_name': parent_name,
                        'student_name': student_name,
                        'registration_number': reg_no,
                        'department': student.department,
                        'gate_name': gate_name,
                        'exit_time': exit_time_str,
                        'leave_type': leave_type_str,
                        'application_id': leave_app.application_id if leave_app else 'N/A',
                        'subject': subject,
                    },
                    recipient_list=[parent_email]
                )
                log_email.message_body = text_body
                if success:
                    log_email.mark_sent()
                else:
                    log_email.mark_failed(err_msg)
            except Exception as exc:
                log_email.mark_failed(str(exc))

    # B. Parent SMS Alert
    if parent_phone:
        # Check duplicate
        if not NotificationLog.objects.filter(
            related_gate_event=gate_event,
            recipient_phone=parent_phone,
            notification_type=NotificationType.PARENT_EXIT_ALERT,
            channel=NotificationChannel.SMS,
            status=DeliveryStatus.SENT
        ).exists():
            sms_text = (
                f"CAMPUSORA ALERT: Student {student_name} ({reg_no}) has cleared exit through "
                f"{gate_name} on {exit_time_str}. Leave: {leave_type_str}."
            )
            log_sms = NotificationLog.objects.create(
                recipient_phone=parent_phone,
                recipient_name=parent_name,
                recipient_type=RecipientType.PARENT,
                recipient_user=None,
                notification_type=NotificationType.PARENT_EXIT_ALERT,
                channel=NotificationChannel.SMS,
                status=DeliveryStatus.PENDING,
                subject=f"SMS Exit Alert for {student_name}",
                message_body=sms_text,
                related_application=leave_app,
                related_gate_event=gate_event,
                metadata={
                    'student_name': student_name,
                    'registration_number': reg_no,
                    'gate': gate_name,
                    'exit_time': exit_time_str,
                }
            )
            try:
                provider = get_sms_provider()
                sms_success, sms_err = provider.send_sms(
                    to_phone=parent_phone,
                    message=sms_text,
                    gate_event_id=gate_event.id
                )
                if sms_success:
                    log_sms.mark_sent()
                else:
                    log_sms.mark_failed(sms_err)
            except Exception as exc:
                log_sms.mark_failed(str(exc))


def _dispatch_warden_alerts(gate_event):
    """
    Notifies ONLY the authorized hostel warden responsible for the departed resident's block.
    Strictly filters out unrelated wardens.
    """
    student = gate_event.student
    student_profile = getattr(student, 'student_profile', None)
    if not student_profile:
        return

    # Determine hostel block
    hostel_block = student_profile.hostel_block
    if not hostel_block and student_profile.room_number:
        # Parse block from room_number string (e.g. 'BH-2, Room 405' -> 'BH-2')
        parts = student_profile.room_number.split(',')
        if parts:
            hostel_block = parts[0].strip()

    if not hostel_block:
        logger.info(f"Student {student.username} is not registered in a hostel block. Skipping warden alert.")
        return

    # Query wardens strictly assigned to this hostel block
    wardens = WardenProfile.objects.filter(assigned_hostel__iexact=hostel_block).select_related('user')
    if not wardens.exists():
        logger.warning(f"No warden registered for hostel block '{hostel_block}'. Skipping warden alert.")
        return

    student_name = student.get_full_name() or student.username
    reg_no = student_profile.registration_number
    gate_name = gate_event.gate_type or "Authorized Gate"
    exit_time_str = gate_event.timestamp.strftime('%d %b %Y, %I:%M %p')
    leave_app = gate_event.gate_pass.leave_application
    leave_type_str = leave_app.get_leave_type_display() if leave_app else "Hostel Outpass"
    security_officer_name = (
        gate_event.security_officer.get_full_name() or gate_event.security_officer.username
        if gate_event.security_officer else "Campus Security"
    )

    for warden_profile in wardens:
        warden_user = warden_profile.user
        warden_email = warden_user.email
        if not warden_email:
            continue

        # Prevent duplicates
        if NotificationLog.objects.filter(
            related_gate_event=gate_event,
            recipient_email=warden_email,
            notification_type=NotificationType.WARDEN_EXIT_ALERT,
            channel=NotificationChannel.EMAIL,
            status=DeliveryStatus.SENT
        ).exists():
            continue

        subject = f"Hostel Resident Departure Alert: {student_name} ({hostel_block})"
        log_entry = NotificationLog.objects.create(
            recipient_email=warden_email,
            recipient_name=warden_user.get_full_name() or warden_user.username,
            recipient_type=RecipientType.WARDEN,
            recipient_user=warden_user,
            notification_type=NotificationType.WARDEN_EXIT_ALERT,
            channel=NotificationChannel.EMAIL,
            status=DeliveryStatus.PENDING,
            subject=subject,
            related_application=leave_app,
            related_gate_event=gate_event,
            metadata={
                'hostel_block': hostel_block,
                'room_number': student_profile.room_number,
                'student_name': student_name,
                'registration_number': reg_no,
                'gate': gate_name,
            }
        )

        try:
            success, err_msg, text_body = send_campusora_email(
                subject=subject,
                template_base_name="warden_exit_alert",
                context={
                    'warden_name': warden_user.get_full_name() or warden_user.username,
                    'student_name': student_name,
                    'registration_number': reg_no,
                    'hostel_block': hostel_block,
                    'room_number': student_profile.room_number,
                    'gate_name': gate_name,
                    'exit_time': exit_time_str,
                    'leave_type': leave_type_str,
                    'start_date': leave_app.start_date.strftime('%d %b %Y') if leave_app else 'N/A',
                    'end_date': leave_app.end_date.strftime('%d %b %Y') if leave_app else 'N/A',
                    'security_officer': security_officer_name,
                    'subject': subject,
                },
                recipient_list=[warden_email]
            )
            log_entry.message_body = text_body
            if success:
                log_entry.mark_sent()
            else:
                log_entry.mark_failed(err_msg)
        except Exception as exc:
            log_entry.mark_failed(str(exc))


def notify_gate_exit(gate_event):
    """
    Orchestrates departure alerts when Security confirms student exit.
    Dispatches:
    1. Parent Email and SMS Alert
    2. Assigned Hostel Warden Alert (if student resides in hostel)
    """
    def action():
        _dispatch_parent_alerts(gate_event)
        _dispatch_warden_alerts(gate_event)

    _dispatch_safely(action)


# ---------------------------------------------------------------------------
# 3. Gate Return Alerts (Parent & Hostel Warden) - Day 9
# ---------------------------------------------------------------------------

def _dispatch_parent_return_alerts(gate_event):
    """
    Delivers Parent/Guardian return-entry notifications via Email and SMS.
    """
    student = gate_event.student
    student_profile = getattr(student, 'student_profile', None)
    if not student_profile:
        return

    parent_name = student_profile.parent_name or "Parent / Guardian"
    parent_email = student_profile.parent_email
    parent_phone = student_profile.parent_phone
    student_name = student.get_full_name() or student.username
    reg_no = student_profile.registration_number
    gate_name = gate_event.gate_type or "Authorized Gate"
    return_time_str = gate_event.timestamp.strftime('%d %b %Y, %I:%M %p')
    gate_pass = gate_event.gate_pass
    leave_app = gate_pass.leave_application if gate_pass else None
    is_overdue = gate_pass.returned_overdue if gate_pass else False

    # A. Parent Return Email Alert
    if parent_email:
        if not NotificationLog.objects.filter(
            related_gate_event=gate_event,
            recipient_email=parent_email,
            notification_type=NotificationType.PARENT_RETURN_ALERT,
            channel=NotificationChannel.EMAIL,
            status=DeliveryStatus.SENT
        ).exists():
            subject = f"Campus Return Notice: {student_name} ({reg_no})"
            log_email = NotificationLog.objects.create(
                recipient_email=parent_email,
                recipient_name=parent_name,
                recipient_type=RecipientType.PARENT,
                recipient_user=None,
                notification_type=NotificationType.PARENT_RETURN_ALERT,
                channel=NotificationChannel.EMAIL,
                status=DeliveryStatus.PENDING,
                subject=subject,
                related_application=leave_app,
                related_gate_event=gate_event,
                metadata={
                    'student_name': student_name,
                    'registration_number': reg_no,
                    'gate': gate_name,
                    'return_time': return_time_str,
                    'is_overdue': is_overdue,
                }
            )
            try:
                success, err_msg, text_body = send_campusora_email(
                    subject=subject,
                    template_base_name="parent_return_alert",
                    context={
                        'parent_name': parent_name,
                        'student_name': student_name,
                        'registration_number': reg_no,
                        'department': student.department,
                        'gate_name': gate_name,
                        'return_time': return_time_str,
                        'application_id': leave_app.application_id if leave_app else 'N/A',
                        'is_overdue': is_overdue,
                        'subject': subject,
                    },
                    recipient_list=[parent_email]
                )
                log_email.message_body = text_body
                if success:
                    log_email.mark_sent()
                else:
                    log_email.mark_failed(err_msg)
            except Exception as exc:
                log_email.mark_failed(str(exc))

    # B. Parent Return SMS Alert
    if parent_phone:
        if not NotificationLog.objects.filter(
            related_gate_event=gate_event,
            recipient_phone=parent_phone,
            notification_type=NotificationType.PARENT_RETURN_ALERT,
            channel=NotificationChannel.SMS,
            status=DeliveryStatus.SENT
        ).exists():
            overdue_txt = " (Overdue return)" if is_overdue else ""
            sms_text = (
                f"CAMPUSORA ALERT: Student {student_name} ({reg_no}) has safely returned to campus via "
                f"{gate_name} on {return_time_str}. Status: RETURNED & CLOSED{overdue_txt}."
            )
            log_sms = NotificationLog.objects.create(
                recipient_phone=parent_phone,
                recipient_name=parent_name,
                recipient_type=RecipientType.PARENT,
                recipient_user=None,
                notification_type=NotificationType.PARENT_RETURN_ALERT,
                channel=NotificationChannel.SMS,
                status=DeliveryStatus.PENDING,
                subject=f"SMS Return Alert for {student_name}",
                message_body=sms_text,
                related_application=leave_app,
                related_gate_event=gate_event,
                metadata={
                    'student_name': student_name,
                    'registration_number': reg_no,
                    'gate': gate_name,
                    'return_time': return_time_str,
                    'is_overdue': is_overdue,
                }
            )
            try:
                provider = get_sms_provider()
                sms_success, sms_err = provider.send_sms(
                    to_phone=parent_phone,
                    message=sms_text,
                    gate_event_id=gate_event.id
                )
                if sms_success:
                    log_sms.mark_sent()
                else:
                    log_sms.mark_failed(sms_err)
            except Exception as exc:
                log_sms.mark_failed(str(exc))


def _dispatch_warden_return_alerts(gate_event):
    """
    Notifies ONLY the authorized hostel warden responsible for the returned resident's block.
    """
    student = gate_event.student
    student_profile = getattr(student, 'student_profile', None)
    if not student_profile:
        return

    hostel_block = student_profile.hostel_block
    if not hostel_block and student_profile.room_number:
        parts = student_profile.room_number.split(',')
        if parts:
            hostel_block = parts[0].strip()

    if not hostel_block:
        return

    wardens = WardenProfile.objects.filter(assigned_hostel__iexact=hostel_block).select_related('user')
    if not wardens.exists():
        return

    student_name = student.get_full_name() or student.username
    reg_no = student_profile.registration_number
    gate_name = gate_event.gate_type or "Authorized Gate"
    return_time_str = gate_event.timestamp.strftime('%d %b %Y, %I:%M %p')
    gate_pass = gate_event.gate_pass
    leave_app = gate_pass.leave_application if gate_pass else None
    is_overdue = gate_pass.returned_overdue if gate_pass else False
    security_officer_name = (
        gate_event.security_officer.get_full_name() or gate_event.security_officer.username
        if gate_event.security_officer else "Campus Security"
    )

    for warden_profile in wardens:
        warden_user = warden_profile.user
        warden_email = warden_user.email
        if not warden_email:
            continue

        if NotificationLog.objects.filter(
            related_gate_event=gate_event,
            recipient_email=warden_email,
            notification_type=NotificationType.WARDEN_RETURN_ALERT,
            channel=NotificationChannel.EMAIL,
            status=DeliveryStatus.SENT
        ).exists():
            continue

        subject = f"Hostel Resident Return Notice: {student_name} ({hostel_block})"
        log_entry = NotificationLog.objects.create(
            recipient_email=warden_email,
            recipient_name=warden_user.get_full_name() or warden_user.username,
            recipient_type=RecipientType.WARDEN,
            recipient_user=warden_user,
            notification_type=NotificationType.WARDEN_RETURN_ALERT,
            channel=NotificationChannel.EMAIL,
            status=DeliveryStatus.PENDING,
            subject=subject,
            related_application=leave_app,
            related_gate_event=gate_event,
            metadata={
                'hostel_block': hostel_block,
                'room_number': student_profile.room_number,
                'student_name': student_name,
                'registration_number': reg_no,
                'gate': gate_name,
                'is_overdue': is_overdue,
            }
        )

        try:
            success, err_msg, text_body = send_campusora_email(
                subject=subject,
                template_base_name="warden_return_alert",
                context={
                    'warden_name': warden_user.get_full_name() or warden_user.username,
                    'student_name': student_name,
                    'registration_number': reg_no,
                    'hostel_block': hostel_block,
                    'room_number': student_profile.room_number,
                    'gate_name': gate_name,
                    'return_time': return_time_str,
                    'security_officer': security_officer_name,
                    'is_overdue': is_overdue,
                    'subject': subject,
                },
                recipient_list=[warden_email]
            )
            log_entry.message_body = text_body
            if success:
                log_entry.mark_sent()
            else:
                log_entry.mark_failed(err_msg)
        except Exception as exc:
            log_entry.mark_failed(str(exc))


def notify_gate_return(gate_event):
    """
    Orchestrates return alerts when Security confirms student return entry.
    Dispatches:
    1. Parent Email and SMS Return Alert
    2. Assigned Hostel Warden Return Alert
    """
    def action():
        _dispatch_parent_return_alerts(gate_event)
        _dispatch_warden_return_alerts(gate_event)

    _dispatch_safely(action)

