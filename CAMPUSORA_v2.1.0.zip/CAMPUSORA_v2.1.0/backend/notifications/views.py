"""
Views for CAMPUSORA Notification Logs and Audit History.
Allows authorized users to inspect automated notifications and delivery status.
"""

from rest_framework import permissions, generics
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
from django.db.models import Q
from accounts.models import Role
from .models import NotificationLog
from .serializers import NotificationLogSerializer


class NotificationListView(generics.ListAPIView):
    """
    List notification history.
    - Students see notifications related to their account or applications.
    - Wardens see alerts addressed to them.
    - Faculty see notifications for their department/advisees.
    - HOD, Security & Admin see full institutional logs.
    Supports filtering by query parameters: channel, status, type, application_id.
    """
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = NotificationLogSerializer

    def get_queryset(self):
        user = self.request.user
        qs = NotificationLog.objects.select_related(
            'recipient_user', 'related_application', 'related_gate_event'
        )

        if user.role == Role.STUDENT:
            qs = qs.filter(
                Q(recipient_user=user) |
                Q(related_application__student=user) |
                Q(related_gate_event__student=user)
            )
        elif user.role == Role.WARDEN:
            qs = qs.filter(recipient_user=user)
        elif user.role == Role.FACULTY:
            qs = qs.filter(
                Q(recipient_user=user) |
                Q(related_application__student__department=user.department) |
                Q(related_application__student__student_profile__advisor=user)
            )
        elif user.role in [Role.HOD, Role.SECURITY] or user.is_staff or user.is_superuser:
            pass  # Full access
        else:
            return NotificationLog.objects.none()

        # Query filters
        channel = self.request.query_params.get('channel')
        if channel:
            qs = qs.filter(channel__iexact=channel)

        notif_status = self.request.query_params.get('status')
        if notif_status:
            qs = qs.filter(status__iexact=notif_status)

        notif_type = self.request.query_params.get('type')
        if notif_type:
            qs = qs.filter(notification_type__iexact=notif_type)

        app_id = self.request.query_params.get('application_id')
        if app_id:
            qs = qs.filter(related_application__application_id=app_id)

        return qs.order_by('-created_at')


class NotificationSummaryView(APIView):
    """
    Provides count and summary metrics of sent/pending/failed notifications.
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        user = request.user
        base_qs = NotificationLog.objects.all()

        if user.role == Role.STUDENT:
            base_qs = base_qs.filter(
                Q(recipient_user=user) |
                Q(related_application__student=user) |
                Q(related_gate_event__student=user)
            )
        elif user.role == Role.WARDEN:
            base_qs = base_qs.filter(recipient_user=user)

        total = base_qs.count()
        sent_count = base_qs.filter(status='SENT').count()
        failed_count = base_qs.filter(status='FAILED').count()
        pending_count = base_qs.filter(status='PENDING').count()

        return Response({
            'total': total,
            'sent': sent_count,
            'failed': failed_count,
            'pending': pending_count,
        }, status=status.HTTP_200_OK)
