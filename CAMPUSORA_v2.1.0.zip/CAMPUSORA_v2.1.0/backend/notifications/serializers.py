"""
Serializers for CAMPUSORA Notification Logs and Audit History.
"""

from rest_framework import serializers
from .models import NotificationLog


class NotificationLogSerializer(models_serializer := serializers.ModelSerializer):
    notification_type_display = serializers.CharField(source='get_notification_type_display', read_only=True)
    channel_display = serializers.CharField(source='get_channel_display', read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    recipient_type_display = serializers.CharField(source='get_recipient_type_display', read_only=True)
    related_application_id = serializers.SerializerMethodField()
    timestamp = serializers.DateTimeField(source='created_at', read_only=True)

    class Meta:
        model = NotificationLog
        fields = [
            'id',
            'recipient_email',
            'recipient_phone',
            'recipient_name',
            'recipient_type',
            'recipient_type_display',
            'notification_type',
            'notification_type_display',
            'channel',
            'channel_display',
            'status',
            'status_display',
            'subject',
            'message_body',
            'error_message',
            'related_application_id',
            'metadata',
            'created_at',
            'sent_at',
            'timestamp',
        ]
        read_only_fields = fields

    def get_related_application_id(self, obj):
        if obj.related_application:
            return obj.related_application.application_id
        return obj.metadata.get('application_id')
