from django.contrib import admin
from .models import NotificationLog


@admin.register(NotificationLog)
class NotificationLogAdmin(admin.ModelAdmin):
    list_display = (
        'id',
        'channel',
        'notification_type',
        'recipient_name',
        'recipient_email',
        'recipient_phone',
        'status',
        'created_at',
    )
    list_filter = ('channel', 'notification_type', 'status', 'recipient_type')
    search_fields = (
        'recipient_email',
        'recipient_phone',
        'recipient_name',
        'subject',
        'related_application__application_id',
    )
    readonly_fields = (
        'created_at',
        'sent_at',
    )
