"""
Configurable SMS Provider Interface for CAMPUSORA Alerts.
Provides pluggable providers: Console, Mock (for testing), and Twilio.
"""

import logging
from abc import ABC, abstractmethod
from django.conf import settings

logger = logging.getLogger(__name__)


class BaseSMSProvider(ABC):
    """
    Abstract interface for CAMPUSORA SMS delivery providers.
    """
    @abstractmethod
    def send_sms(self, to_phone: str, message: str, **kwargs) -> tuple[bool, str]:
        """
        Sends an SMS to the designated phone number.
        Returns:
            tuple[bool, str]: (is_success, error_message_or_empty)
        """
        pass


class ConsoleSMSProvider(BaseSMSProvider):
    """
    Development SMS provider that logs outgoing SMS messages to the console.
    """
    def send_sms(self, to_phone: str, message: str, **kwargs) -> tuple[bool, str]:
        border = "=" * 60
        formatted_log = (
            f"\n{border}\n"
            f"[CAMPUSORA SMS GATEWAY - CONSOLE DISPATCH]\n"
            f"TO:      {to_phone}\n"
            f"MESSAGE: {message}\n"
            f"{border}\n"
        )
        print(formatted_log)
        logger.info(f"SMS dispatched to {to_phone}: {message}")
        return True, ""


class MockSMSProvider(BaseSMSProvider):
    """
    In-memory mock provider for automated unit and integration tests.
    """
    sent_messages: list[dict] = []
    should_fail: bool = False
    failure_message: str = "Simulated SMS provider error"

    @classmethod
    def reset(cls):
        cls.sent_messages = []
        cls.should_fail = False
        cls.failure_message = "Simulated SMS provider error"

    def send_sms(self, to_phone: str, message: str, **kwargs) -> tuple[bool, str]:
        if self.should_fail:
            return False, self.failure_message

        record = {
            'to': to_phone,
            'message': message,
            'extra': kwargs
        }
        self.sent_messages.append(record)
        return True, ""


class TwilioSMSProvider(BaseSMSProvider):
    """
    Twilio production SMS provider.
    Requires twilio library and environment credentials.
    """
    def __init__(self):
        self.account_sid = getattr(settings, 'TWILIO_ACCOUNT_SID', '')
        self.auth_token = getattr(settings, 'TWILIO_AUTH_TOKEN', '')
        self.from_number = getattr(settings, 'TWILIO_FROM_NUMBER', '')

    def send_sms(self, to_phone: str, message: str, **kwargs) -> tuple[bool, str]:
        if not (self.account_sid and self.auth_token and self.from_number):
            err = "Twilio credentials (TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_FROM_NUMBER) are incomplete."
            logger.error(err)
            return False, err

        try:
            from twilio.rest import Client
            client = Client(self.account_sid, self.auth_token)
            msg = client.messages.create(
                body=message,
                from_=self.from_number,
                to=to_phone
            )
            return True, msg.sid
        except ImportError:
            err = "Twilio package is not installed. Run `pip install twilio` to enable Twilio SMS."
            logger.error(err)
            return False, err
        except Exception as exc:
            logger.exception("Failed to dispatch Twilio SMS")
            return False, str(exc)


def get_sms_provider() -> BaseSMSProvider:
    """
    Factory resolving the active SMS provider from Django settings.
    """
    provider_name = getattr(settings, 'SMS_PROVIDER', 'console').lower()
    if provider_name == 'mock':
        return MockSMSProvider()
    elif provider_name == 'twilio':
        return TwilioSMSProvider()
    return ConsoleSMSProvider()
