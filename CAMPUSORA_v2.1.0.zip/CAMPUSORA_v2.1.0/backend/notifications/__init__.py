"""
CAMPUSORA Notifications App Package
"""
