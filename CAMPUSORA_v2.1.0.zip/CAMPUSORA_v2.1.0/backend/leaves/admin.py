from django.contrib import admin
from .models import LeaveApplication


@admin.register(LeaveApplication)
class LeaveApplicationAdmin(admin.ModelAdmin):
    list_display = (
        'application_id',
        'student',
        'leave_type',
        'start_date',
        'end_date',
        'status',
        'created_at',
    )
    list_filter = ('status', 'leave_type', 'created_at')
    search_fields = (
        'application_id',
        'student__username',
        'student__first_name',
        'student__last_name',
        'reason',
    )
    readonly_fields = ('created_at', 'updated_at')
