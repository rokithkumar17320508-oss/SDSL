"""
CAMPUSORA Leave Application Models.
Encapsulates leave categories, workflow statuses, and strict model validations.
"""

import random
from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models


class LeaveType(models.TextChoices):
    REGULAR_LEAVE = 'Regular Leave', 'Regular Leave'
    ON_DUTY = 'On-Duty', 'On-Duty'
    DAY_PASS = 'Day Pass', 'Day Pass'
    HOSTEL_OUTPASS = 'Hostel Outpass', 'Hostel Outpass'


class LeaveStatus(models.TextChoices):
    PENDING_FACULTY = 'Pending Faculty Review', 'Pending Faculty Review'
    PENDING_HOD = 'Pending HOD Review', 'Pending HOD Review'
    HOD_APPROVED = 'HOD Approved', 'HOD Approved'
    REJECTED = 'Rejected', 'Rejected'

    @classmethod
    def from_logical(cls, status_str):
        """Map logical status keywords (e.g. 'PENDING_FACULTY', 'APPROVED') to database representation."""
        mapping = {
            'PENDING_FACULTY': cls.PENDING_FACULTY,
            'PENDING_HOD': cls.PENDING_HOD,
            'APPROVED': cls.HOD_APPROVED,
            'HOD_APPROVED': cls.HOD_APPROVED,
            'REJECTED': cls.REJECTED,
        }
        return mapping.get(status_str, status_str)


def generate_application_id():
    """Generates a four-digit unique tracking ID matching frontend conventions (e.g. APP-1035)."""
    return f"APP-{random.randint(1000, 9999)}"


class LeaveApplication(models.Model):
    """
    Core leave application submitted by a student.
    Enforces dates validation and tracks multi-tier progression.
    """
    application_id = models.CharField(
        max_length=20,
        unique=True,
        db_index=True,
        default=generate_application_id,
        help_text="Unique Application Tracking ID"
    )
    student = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='leave_applications',
        help_text="Student submitting the application"
    )
    leave_type = models.CharField(
        max_length=30,
        choices=LeaveType.choices,
        help_text="Categorization of leave"
    )
    start_date = models.DateField(
        help_text="Commencement date of leave period"
    )
    end_date = models.DateField(
        help_text="Concluding date of leave period"
    )
    reason = models.TextField(
        help_text="Detailed justification submitted by the student"
    )
    status = models.CharField(
        max_length=30,
        choices=LeaveStatus.choices,
        default=LeaveStatus.PENDING_FACULTY,
        db_index=True,
        help_text="Current review status (defaults to Pending Faculty Review)"
    )
    faculty_reviewer = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='faculty_reviewed_applications',
        help_text="Faculty member who endorsed/reviewed this application"
    )
    hod_reviewer = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='hod_reviewed_applications',
        help_text="HOD who authorized/reviewed this application"
    )
    decision_timestamp = models.DateTimeField(
        null=True,
        blank=True,
        help_text="Timestamp of latest review decision"
    )
    rejection_reason = models.TextField(
        blank=True,
        default='',
        help_text="Mandatory rationale if rejected by faculty or HOD"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        db_index=True,
        help_text="Submission timestamp"
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        help_text="Last status update timestamp"
    )

    class Meta:
        verbose_name = "Leave Application"
        verbose_name_plural = "Leave Applications"
        ordering = ['-created_at']

    def clean(self):
        super().clean()
        if self.start_date and self.end_date:
            if self.end_date < self.start_date:
                raise ValidationError({
                    'end_date': 'End date cannot be earlier than start date.'
                })

    def save(self, *args, **kwargs):
        self.full_clean()
        super().save(*args, **kwargs)

    def __str__(self):
        student_display = self.student.get_full_name() or self.student.username
        return f"{self.application_id} - {student_display} ({self.status})"
