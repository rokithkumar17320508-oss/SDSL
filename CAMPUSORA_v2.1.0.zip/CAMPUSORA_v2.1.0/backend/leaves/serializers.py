from rest_framework import serializers
from .models import LeaveApplication, LeaveType, LeaveStatus
from approvals.models import ApprovalRecord, ReviewerRole
from accounts.models import Role


class LeaveTypeSerializer(serializers.Serializer):
    id = serializers.CharField()
    name = serializers.CharField()
    description = serializers.CharField()


class ApprovalRecordSerializer(serializers.ModelSerializer):
    reviewer_name = serializers.SerializerMethodField()

    class Meta:
        model = ApprovalRecord
        fields = [
            'id',
            'reviewer_name',
            'reviewer_role',
            'decision',
            'remarks',
            'timestamp',
        ]
        read_only_fields = fields

    def get_reviewer_name(self, obj):
        return obj.reviewer.get_full_name() or obj.reviewer.username


class LeaveApplicationSerializer(serializers.ModelSerializer):
    id = serializers.CharField(source='application_id', read_only=True)
    student_name = serializers.SerializerMethodField()
    studentName = serializers.SerializerMethodField()
    student_registration = serializers.SerializerMethodField()
    regNo = serializers.SerializerMethodField()
    department = serializers.SerializerMethodField()
    faculty_reviewer_name = serializers.SerializerMethodField()
    hod_reviewer_name = serializers.SerializerMethodField()
    approval_records = ApprovalRecordSerializer(many=True, read_only=True)

    # Aliases for frontend UI integration
    type = serializers.CharField(source='leave_type', required=False)
    startDate = serializers.DateField(source='start_date', required=False)
    endDate = serializers.DateField(source='end_date', required=False)
    submittedAt = serializers.SerializerMethodField()
    facultyRemarks = serializers.SerializerMethodField()
    hodRemarks = serializers.SerializerMethodField()

    class Meta:
        model = LeaveApplication
        fields = [
            'id',
            'application_id',
            'student_name',
            'studentName',
            'student_registration',
            'regNo',
            'department',
            'leave_type',
            'type',
            'start_date',
            'startDate',
            'end_date',
            'endDate',
            'reason',
            'status',
            'faculty_reviewer_name',
            'hod_reviewer_name',
            'rejection_reason',
            'decision_timestamp',
            'facultyRemarks',
            'hodRemarks',
            'created_at',
            'updated_at',
            'submittedAt',
            'approval_records',
        ]
        read_only_fields = [
            'id',
            'application_id',
            'student_name',
            'studentName',
            'student_registration',
            'regNo',
            'department',
            'status',
            'faculty_reviewer_name',
            'hod_reviewer_name',
            'rejection_reason',
            'decision_timestamp',
            'facultyRemarks',
            'hodRemarks',
            'created_at',
            'updated_at',
            'submittedAt',
            'approval_records',
        ]

    def to_internal_value(self, data):
        data = data.copy() if hasattr(data, 'copy') else dict(data)
        if 'type' in data and 'leave_type' not in data:
            data['leave_type'] = data['type']
        if 'startDate' in data and 'start_date' not in data:
            data['start_date'] = data['startDate']
        if 'endDate' in data and 'end_date' not in data:
            data['end_date'] = data['endDate']
        return super().to_internal_value(data)

    def get_student_name(self, obj):
        return obj.student.get_full_name() or obj.student.username

    def get_studentName(self, obj):
        return self.get_student_name(obj)

    def get_student_registration(self, obj):
        if hasattr(obj.student, 'student_profile'):
            return obj.student.student_profile.registration_number
        return None

    def get_regNo(self, obj):
        return self.get_student_registration(obj)

    def get_department(self, obj):
        if hasattr(obj.student, 'student_profile'):
            return obj.student.student_profile.department
        return obj.student.department

    def get_faculty_reviewer_name(self, obj):
        if obj.faculty_reviewer:
            return obj.faculty_reviewer.get_full_name() or obj.faculty_reviewer.username
        return None

    def get_hod_reviewer_name(self, obj):
        if obj.hod_reviewer:
            return obj.hod_reviewer.get_full_name() or obj.hod_reviewer.username
        return None

    def get_submittedAt(self, obj):
        return obj.created_at.strftime('%Y-%m-%d') if obj.created_at else None

    def get_facultyRemarks(self, obj):
        faculty_record = obj.approval_records.filter(reviewer_role=ReviewerRole.FACULTY).last()
        return faculty_record.remarks if faculty_record else ''

    def get_hodRemarks(self, obj):
        hod_record = obj.approval_records.filter(reviewer_role=ReviewerRole.HOD).last()
        return hod_record.remarks if hod_record else ''

    def validate(self, attrs):
        start_date = attrs.get('start_date')
        end_date = attrs.get('end_date')
        if start_date and end_date and end_date < start_date:
            raise serializers.ValidationError({
                'end_date': 'End date cannot be earlier than start date.'
            })
        return attrs

    def create(self, validated_data):
        user = self.context['request'].user
        if not user.is_authenticated or user.role != Role.STUDENT:
            raise serializers.ValidationError({
                'detail': 'Only authenticated students can submit leave applications.'
            })
        validated_data['student'] = user
        validated_data['status'] = LeaveStatus.PENDING_FACULTY
        return super().create(validated_data)
