from django.urls import path
from .views import (
    HealthCheckView,
    LeaveTypesView,
    LeaveApplicationListCreateView,
    LeaveApplicationDetailView,
    ForwardLeaveApplicationView,
    ApproveLeaveApplicationView,
    RejectLeaveApplicationView,
)

urlpatterns = [
    path('health/', HealthCheckView.as_view(), name='health-check'),
    path('leave-types/', LeaveTypesView.as_view(), name='leave-types'),
    path('applications/', LeaveApplicationListCreateView.as_view(), name='application-list-create'),
    path('applications/<str:application_id>/', LeaveApplicationDetailView.as_view(), name='application-detail'),
    path('applications/<str:application_id>/forward/', ForwardLeaveApplicationView.as_view(), name='application-forward'),
    path('applications/<str:application_id>/approve/', ApproveLeaveApplicationView.as_view(), name='application-approve'),
    path('applications/<str:application_id>/reject/', RejectLeaveApplicationView.as_view(), name='application-reject'),
]
