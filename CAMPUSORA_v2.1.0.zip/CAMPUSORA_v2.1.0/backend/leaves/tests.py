from datetime import date, timedelta
from django.test import TestCase, TransactionTestCase
from django.core.exceptions import ValidationError
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient
from rest_framework import status
from .models import LeaveApplication, LeaveType, LeaveStatus
from accounts.models import Role, StudentProfile, FacultyProfile
from approvals.models import ApprovalRecord, ReviewerRole, Decision

User = get_user_model()


class LeaveApplicationModelTest(TestCase):
    def setUp(self):
        self.student = User.objects.create_user(
            username='priya_student',
            password='Password123!',
            role=Role.STUDENT,
            department='Computer Science & Engineering'
        )

    def test_default_status_is_pending_faculty_review(self):
        today = date.today()
        leave = LeaveApplication.objects.create(
            student=self.student,
            leave_type=LeaveType.REGULAR_LEAVE,
            start_date=today,
            end_date=today + timedelta(days=2),
            reason='Family gathering'
        )
        self.assertEqual(leave.status, LeaveStatus.PENDING_FACULTY)
        self.assertTrue(leave.application_id.startswith('APP-'))

    def test_invalid_date_range_rejected_by_model(self):
        today = date.today()
        leave = LeaveApplication(
            student=self.student,
            leave_type=LeaveType.REGULAR_LEAVE,
            start_date=today + timedelta(days=5),
            end_date=today,  # Invalid: end date earlier than start date
            reason='Invalid dates'
        )
        with self.assertRaises(ValidationError):
            leave.full_clean()

    def test_approval_record_immutability(self):
        today = date.today()
        leave = LeaveApplication.objects.create(
            student=self.student,
            leave_type=LeaveType.DAY_PASS,
            start_date=today,
            end_date=today,
            reason='Medical checkup'
        )
        faculty = User.objects.create_user(
            username='prof_immutability',
            password='Password123!',
            role=Role.FACULTY,
            department='Computer Science & Engineering'
        )
        record = ApprovalRecord.objects.create(
            leave_application=leave,
            reviewer=faculty,
            reviewer_role=ReviewerRole.FACULTY,
            decision=Decision.FORWARDED_TO_HOD,
            remarks='First verified remarks'
        )
        # Attempting to update the record must raise ValidationError
        record.remarks = 'Attempted overwrite of audit log'
        with self.assertRaises(ValidationError):
            record.save()


class LeaveWorkflowAPITest(TestCase):
    def setUp(self):
        self.client = APIClient()

        # Faculty 1 & HOD 1 (CSE)
        self.faculty_cse = User.objects.create_user(
            username='skverma_cse',
            password='FacultyPassword123!',
            role=Role.FACULTY,
            department='Computer Science & Engineering'
        )
        self.hod_cse = User.objects.create_user(
            username='rmehra_cse',
            password='HodPassword123!',
            role=Role.HOD,
            department='Computer Science & Engineering'
        )

        # Faculty 2 & HOD 2 (ECE)
        self.faculty_ece = User.objects.create_user(
            username='anand_ece',
            password='FacultyPassword123!',
            role=Role.FACULTY,
            department='Electronics & Communication Engineering'
        )
        self.hod_ece = User.objects.create_user(
            username='sharma_ece',
            password='HodPassword123!',
            role=Role.HOD,
            department='Electronics & Communication Engineering'
        )

        # Student 1 (CSE) assigned to faculty_cse
        self.student_cse = User.objects.create_user(
            username='arjun_cse',
            password='StudentPassword123!',
            role=Role.STUDENT,
            department='Computer Science & Engineering'
        )
        self.student_cse_profile = StudentProfile.objects.create(
            user=self.student_cse,
            registration_number='2024CSE1084',
            department='Computer Science & Engineering',
            year=3,
            semester=6,
            advisor=self.faculty_cse
        )

        # Student 2 (ECE) assigned to faculty_ece
        self.student_ece = User.objects.create_user(
            username='kavya_ece',
            password='StudentPassword123!',
            role=Role.STUDENT,
            department='Electronics & Communication Engineering'
        )
        self.student_ece_profile = StudentProfile.objects.create(
            user=self.student_ece,
            registration_number='2024ECE2012',
            department='Electronics & Communication Engineering',
            year=2,
            semester=4,
            advisor=self.faculty_ece
        )

    # 1. Student creates a valid leave application
    def test_01_student_creates_valid_leave_application(self):
        self.client.force_authenticate(user=self.student_cse)
        today = date.today()
        payload = {
            'leave_type': 'Day Pass',
            'start_date': str(today),
            'end_date': str(today),
            'reason': 'Medical consultation at clinic'
        }
        response = self.client.post('/api/v1/applications/', payload)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(response.data.get('status'), 'Pending Faculty Review')
        self.assertTrue(response.data.get('application_id').startswith('APP-'))

    # 2. Invalid date ranges are rejected
    def test_02_invalid_date_range_rejected(self):
        self.client.force_authenticate(user=self.student_cse)
        today = date.today()
        payload = {
            'leave_type': 'Regular Leave',
            'start_date': str(today + timedelta(days=5)),
            'end_date': str(today),  # Invalid: end date earlier than start date
            'reason': 'Invalid dates travel'
        }
        response = self.client.post('/api/v1/applications/', payload)
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    # 3. Anonymous application submission is rejected
    def test_03_anonymous_application_submission_rejected(self):
        response = self.client.post('/api/v1/applications/', {
            'leave_type': 'Day Pass',
            'start_date': str(date.today()),
            'end_date': str(date.today()),
            'reason': 'Anonymous attempt'
        })
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    # 4. Student cannot submit an application for another student
    def test_04_student_cannot_submit_for_another_student(self):
        self.client.force_authenticate(user=self.student_cse)
        today = date.today()
        # Even if attacker supplies another student's ID or registration
        payload = {
            'student': self.student_ece.id,
            'student_id': self.student_ece.id,
            'leave_type': 'Hostel Outpass',
            'start_date': str(today),
            'end_date': str(today + timedelta(days=2)),
            'reason': 'Home visit for weekend'
        }
        response = self.client.post('/api/v1/applications/', payload)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        app = LeaveApplication.objects.get(application_id=response.data.get('application_id'))
        self.assertEqual(app.student, self.student_cse)
        self.assertNotEqual(app.student, self.student_ece)

    # 5. Student cannot access another student's private application
    def test_05_student_cannot_access_other_student_application(self):
        app = LeaveApplication.objects.create(
            student=self.student_ece,
            leave_type=LeaveType.DAY_PASS,
            start_date=date.today(),
            end_date=date.today(),
            reason='Private appointment'
        )
        self.client.force_authenticate(user=self.student_cse)
        response = self.client.get(f'/api/v1/applications/{app.application_id}/')
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    # 6. Faculty can access assigned applications
    def test_06_faculty_can_access_assigned_applications(self):
        app = LeaveApplication.objects.create(
            student=self.student_cse,
            leave_type=LeaveType.ON_DUTY,
            start_date=date.today(),
            end_date=date.today() + timedelta(days=1),
            reason='Technical conference presentation'
        )
        self.client.force_authenticate(user=self.faculty_cse)
        response = self.client.get(f'/api/v1/applications/{app.application_id}/')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data.get('application_id'), app.application_id)

    # 7. Faculty cannot access unauthorized applications (other department without advisor link)
    def test_07_faculty_cannot_access_unauthorized_applications(self):
        app = LeaveApplication.objects.create(
            student=self.student_ece,
            leave_type=LeaveType.REGULAR_LEAVE,
            start_date=date.today(),
            end_date=date.today() + timedelta(days=1),
            reason='Personal reasons'
        )
        self.client.force_authenticate(user=self.faculty_cse)
        response = self.client.get(f'/api/v1/applications/{app.application_id}/')
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    # 8. Faculty forwards an eligible application
    def test_08_faculty_forwards_eligible_application(self):
        app = LeaveApplication.objects.create(
            student=self.student_cse,
            leave_type=LeaveType.REGULAR_LEAVE,
            start_date=date.today(),
            end_date=date.today() + timedelta(days=2),
            reason='Family wedding function',
            status=LeaveStatus.PENDING_FACULTY
        )
        self.client.force_authenticate(user=self.faculty_cse)
        response = self.client.post(
            f'/api/v1/applications/{app.application_id}/forward/',
            {'remarks': 'Academic standing verified. Recommended to HOD.'}
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        app.refresh_from_db()
        self.assertEqual(app.status, LeaveStatus.PENDING_HOD)
        self.assertEqual(app.faculty_reviewer, self.faculty_cse)
        self.assertIsNotNone(app.decision_timestamp)

        # Audit record verification
        records = app.approval_records.all()
        self.assertEqual(records.count(), 1)
        record = records.first()
        self.assertEqual(record.reviewer, self.faculty_cse)
        self.assertEqual(record.decision, Decision.FORWARDED_TO_HOD)

    # 9. Faculty rejects an eligible application with mandatory remarks
    def test_09_faculty_rejects_eligible_application(self):
        app = LeaveApplication.objects.create(
            student=self.student_cse,
            leave_type=LeaveType.DAY_PASS,
            start_date=date.today(),
            end_date=date.today(),
            reason='Shopping outside campus',
            status=LeaveStatus.PENDING_FACULTY
        )
        self.client.force_authenticate(user=self.faculty_cse)
        response = self.client.post(
            f'/api/v1/applications/{app.application_id}/reject/',
            {'remarks': 'Attendance below threshold (68%). Day pass denied.'}
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        app.refresh_from_db()
        self.assertEqual(app.status, LeaveStatus.REJECTED)
        self.assertEqual(app.faculty_reviewer, self.faculty_cse)
        self.assertIn('Attendance below threshold', app.rejection_reason)

    # 10. HOD approves a forwarded application
    def test_10_hod_approves_forwarded_application(self):
        app = LeaveApplication.objects.create(
            student=self.student_cse,
            leave_type=LeaveType.ON_DUTY,
            start_date=date.today(),
            end_date=date.today() + timedelta(days=2),
            reason='National Robotics Championship',
            status=LeaveStatus.PENDING_HOD,
            faculty_reviewer=self.faculty_cse
        )
        ApprovalRecord.objects.create(
            leave_application=app,
            reviewer=self.faculty_cse,
            reviewer_role=ReviewerRole.FACULTY,
            decision=Decision.FORWARDED_TO_HOD,
            remarks='Recommended for college representation.'
        )

        self.client.force_authenticate(user=self.hod_cse)
        response = self.client.post(
            f'/api/v1/applications/{app.application_id}/approve/',
            {'remarks': 'Approved for National Robotics. Gate pass authorized.'}
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        app.refresh_from_db()
        self.assertEqual(app.status, LeaveStatus.HOD_APPROVED)
        self.assertEqual(app.hod_reviewer, self.hod_cse)
        self.assertIsNotNone(app.decision_timestamp)

        # Verify audit records count is 2 (Faculty + HOD)
        self.assertEqual(app.approval_records.count(), 2)

    # 11. HOD rejects a forwarded application with mandatory remarks
    def test_11_hod_rejects_forwarded_application(self):
        app = LeaveApplication.objects.create(
            student=self.student_cse,
            leave_type=LeaveType.HOSTEL_OUTPASS,
            start_date=date.today(),
            end_date=date.today() + timedelta(days=3),
            reason='Outstation trip with friends',
            status=LeaveStatus.PENDING_HOD,
            faculty_reviewer=self.faculty_cse
        )
        self.client.force_authenticate(user=self.hod_cse)
        response = self.client.post(
            f'/api/v1/applications/{app.application_id}/reject/',
            {'remarks': 'Departmental exams scheduled during this window. Denied.'}
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        app.refresh_from_db()
        self.assertEqual(app.status, LeaveStatus.REJECTED)
        self.assertEqual(app.hod_reviewer, self.hod_cse)
        self.assertIn('Departmental exams', app.rejection_reason)

    # 12. HOD cannot approve before Faculty forwarding
    def test_12_hod_cannot_approve_before_faculty_forwarding(self):
        app = LeaveApplication.objects.create(
            student=self.student_cse,
            leave_type=LeaveType.REGULAR_LEAVE,
            start_date=date.today(),
            end_date=date.today() + timedelta(days=1),
            reason='Personal affairs',
            status=LeaveStatus.PENDING_FACULTY
        )
        self.client.force_authenticate(user=self.hod_cse)
        response = self.client.post(
            f'/api/v1/applications/{app.application_id}/approve/',
            {'remarks': 'Bypassing faculty review attempt'}
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        app.refresh_from_db()
        self.assertEqual(app.status, LeaveStatus.PENDING_FACULTY)

    # 13. Student cannot call approval endpoints
    def test_13_student_cannot_call_approval_endpoints(self):
        app = LeaveApplication.objects.create(
            student=self.student_cse,
            leave_type=LeaveType.DAY_PASS,
            start_date=date.today(),
            end_date=date.today(),
            reason='Testing self approval',
            status=LeaveStatus.PENDING_FACULTY
        )
        self.client.force_authenticate(user=self.student_cse)

        # Attempt to forward
        res_fwd = self.client.post(f'/api/v1/applications/{app.application_id}/forward/')
        self.assertEqual(res_fwd.status_code, status.HTTP_403_FORBIDDEN)

        # Attempt to approve
        res_app = self.client.post(f'/api/v1/applications/{app.application_id}/approve/')
        self.assertEqual(res_app.status_code, status.HTTP_403_FORBIDDEN)

        # Attempt to reject
        res_rej = self.client.post(f'/api/v1/applications/{app.application_id}/reject/', {'remarks': 'Self reject'})
        self.assertEqual(res_rej.status_code, status.HTTP_403_FORBIDDEN)

    # 14. Faculty cannot call HOD approval endpoints
    def test_14_faculty_cannot_call_hod_approval_endpoint(self):
        app = LeaveApplication.objects.create(
            student=self.student_cse,
            leave_type=LeaveType.DAY_PASS,
            start_date=date.today(),
            end_date=date.today(),
            reason='Testing faculty calling approve',
            status=LeaveStatus.PENDING_HOD
        )
        self.client.force_authenticate(user=self.faculty_cse)
        response = self.client.post(f'/api/v1/applications/{app.application_id}/approve/')
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    # 15. Duplicate approvals are prevented
    def test_15_duplicate_decisions_prevented(self):
        app = LeaveApplication.objects.create(
            student=self.student_cse,
            leave_type=LeaveType.HOSTEL_OUTPASS,
            start_date=date.today(),
            end_date=date.today() + timedelta(days=2),
            reason='Home visit',
            status=LeaveStatus.PENDING_FACULTY
        )
        self.client.force_authenticate(user=self.faculty_cse)
        res1 = self.client.post(f'/api/v1/applications/{app.application_id}/forward/')
        self.assertEqual(res1.status_code, status.HTTP_200_OK)

        # Duplicate forward call
        res2 = self.client.post(f'/api/v1/applications/{app.application_id}/forward/')
        self.assertEqual(res2.status_code, status.HTTP_400_BAD_REQUEST)

    # 16. Audit records are created correctly and are immutable
    def test_16_audit_record_created_and_immutable(self):
        app = LeaveApplication.objects.create(
            student=self.student_cse,
            leave_type=LeaveType.ON_DUTY,
            start_date=date.today(),
            end_date=date.today() + timedelta(days=1),
            reason='Project demo competition',
            status=LeaveStatus.PENDING_FACULTY
        )
        self.client.force_authenticate(user=self.faculty_cse)
        self.client.post(f'/api/v1/applications/{app.application_id}/forward/', {'remarks': 'Good project'})
        record = ApprovalRecord.objects.filter(leave_application=app).first()
        self.assertIsNotNone(record)
        self.assertEqual(record.reviewer, self.faculty_cse)
        self.assertEqual(record.decision, Decision.FORWARDED_TO_HOD)

    # 17. Rejection without remarks returns 400 Bad Request
    def test_17_rejection_requires_remarks(self):
        app = LeaveApplication.objects.create(
            student=self.student_cse,
            leave_type=LeaveType.DAY_PASS,
            start_date=date.today(),
            end_date=date.today(),
            reason='Quick exit',
            status=LeaveStatus.PENDING_FACULTY
        )
        self.client.force_authenticate(user=self.faculty_cse)
        response = self.client.post(f'/api/v1/applications/{app.application_id}/reject/', {'remarks': '   '})
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        app.refresh_from_db()
        self.assertEqual(app.status, LeaveStatus.PENDING_FACULTY)

    # 18. Application status persists after reauthentication
    def test_18_application_status_persists_after_reauthentication(self):
        # 1. Student creates
        self.client.force_authenticate(user=self.student_cse)
        res_create = self.client.post('/api/v1/applications/', {
            'leave_type': 'Day Pass',
            'start_date': str(date.today()),
            'end_date': str(date.today()),
            'reason': 'Persist test'
        })
        app_id = res_create.data.get('application_id')

        # 2. Faculty logs in and forwards
        self.client.force_authenticate(user=self.faculty_cse)
        self.client.post(f'/api/v1/applications/{app_id}/forward/', {'remarks': 'Forwarded'})

        # 3. HOD logs in and approves
        self.client.force_authenticate(user=self.hod_cse)
        self.client.post(f'/api/v1/applications/{app_id}/approve/', {'remarks': 'Approved'})

        # 4. Student logs in again and verifies HOD Approved
        self.client.force_authenticate(user=self.student_cse)
        res_verify = self.client.get(f'/api/v1/applications/{app_id}/')
        self.assertEqual(res_verify.status_code, status.HTTP_200_OK)
        self.assertEqual(res_verify.data.get('status'), 'HOD Approved')

    # 19. Cross-department HOD cannot approve student from different department
    def test_19_cross_department_hod_rejected(self):
        app = LeaveApplication.objects.create(
            student=self.student_cse,
            leave_type=LeaveType.REGULAR_LEAVE,
            start_date=date.today(),
            end_date=date.today() + timedelta(days=2),
            reason='Cross department test',
            status=LeaveStatus.PENDING_HOD,
            faculty_reviewer=self.faculty_cse
        )
        self.client.force_authenticate(user=self.hod_ece)
        response = self.client.post(f'/api/v1/applications/{app.application_id}/approve/')
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    # 20. Public metadata & health checks remain operational
    def test_20_public_metadata_operational(self):
        res_health = self.client.get('/api/v1/health/')
        self.assertEqual(res_health.status_code, status.HTTP_200_OK)
        res_types = self.client.get('/api/v1/leave-types/')
        self.assertEqual(res_types.status_code, status.HTTP_200_OK)
        self.assertEqual(len(res_types.data), 4)
