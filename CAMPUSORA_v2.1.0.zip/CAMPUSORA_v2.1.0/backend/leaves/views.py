"""
API Views for CAMPUSORA Leave Management.
Includes public health checks, leave metadata, and protected application endpoints:
- List/Create applications
- Retrieve specific application
- Faculty Forward to HOD
- HOD Approve
- Faculty / HOD Reject
"""

from django.utils import timezone
from django.conf import settings
from django.db import transaction, models
from rest_framework import status, permissions
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.generics import ListCreateAPIView, RetrieveAPIView
from .models import LeaveApplication, LeaveType, LeaveStatus
from .serializers import LeaveTypeSerializer, LeaveApplicationSerializer
from accounts.models import Role
from approvals.models import ApprovalRecord, ReviewerRole, Decision
from notifications.services import (
    notify_application_submitted,
    notify_faculty_forwarded,
    notify_faculty_rejected,
    notify_hod_approved,
    notify_hod_rejected,
)


class HealthCheckView(APIView):
    """
    Public health check endpoint providing backend status and security configuration summary.
    """
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        return Response({
            "status": "ok",
            "service": "campusora-backend",
            "version": "1.0.0",
            "timestamp": timezone.now().isoformat(),
            "database_engine": settings.DB_ENGINE,
            "security": {
                "argon2_enabled": True,
                "cors_configured": True,
                "authentication_required_for_records": True,
            }
        }, status=status.HTTP_200_OK)


class LeaveTypesView(APIView):
    """
    Public metadata endpoint listing valid institutional leave categories.
    """
    permission_classes = [permissions.AllowAny]

    DESCRIPTIONS = {
        LeaveType.REGULAR_LEAVE: "Standard personal or family leave during instructional days.",
        LeaveType.ON_DUTY: "Authorized academic competitions, symposiums, or sports events.",
        LeaveType.DAY_PASS: "Same-day off-campus authorization with mandatory return by curfew.",
        LeaveType.HOSTEL_OUTPASS: "Overnight residential hostel clearance for home or weekend visits.",
    }

    def get(self, request):
        data = [
            {
                "id": choice.value,
                "name": choice.label,
                "description": self.DESCRIPTIONS.get(choice.value, "")
            }
            for choice in LeaveType
        ]
        serializer = LeaveTypeSerializer(data, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


class LeaveApplicationListCreateView(ListCreateAPIView):
    """
    Protected endpoint:
    - GET: List leave applications filtered by role
      * Student: own applications only
      * Faculty: advisees or department students
      * HOD: department students
    - POST: Submit a new leave application (Student role only)
    Requires valid authentication token or session. Anonymous requests are rejected (401).
    """
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = LeaveApplicationSerializer

    def get_queryset(self):
        user = self.request.user
        if not user.is_authenticated:
            return LeaveApplication.objects.none()

        base_qs = LeaveApplication.objects.select_related(
            'student', 'faculty_reviewer', 'hod_reviewer'
        ).prefetch_related('approval_records', 'approval_records__reviewer')

        if user.role == Role.STUDENT:
            return base_qs.filter(student=user)
        elif user.role == Role.FACULTY:
            # Faculty views assigned advisees or students in same department
            return base_qs.filter(
                models.Q(student__student_profile__advisor=user) |
                models.Q(student__department=user.department)
            ).distinct()
        elif user.role == Role.HOD:
            # HOD views department students (or all if admin)
            if user.is_superuser or user.department == 'Administration':
                return base_qs.all()
            return base_qs.filter(student__department=user.department)
        elif user.is_staff or user.is_superuser:
            return base_qs.all()

        return LeaveApplication.objects.none()

    def create(self, request, *args, **kwargs):
        if not request.user.is_authenticated or request.user.role != Role.STUDENT:
            return Response(
                {"detail": "Only students are authorized to submit leave applications."},
                status=status.HTTP_403_FORBIDDEN
            )
        return super().create(request, *args, **kwargs)

    def perform_create(self, serializer):
        app = serializer.save()
        notify_application_submitted(app)


class LeaveApplicationDetailView(RetrieveAPIView):
    """
    Protected endpoint:
    - GET: Retrieve a specific leave application by unique application ID.
    Rejects anonymous access (401) and unauthorized cross-student queries (404).
    """
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = LeaveApplicationSerializer
    lookup_field = 'application_id'

    def get_queryset(self):
        user = self.request.user
        if not user.is_authenticated:
            return LeaveApplication.objects.none()

        base_qs = LeaveApplication.objects.select_related(
            'student', 'faculty_reviewer', 'hod_reviewer'
        ).prefetch_related('approval_records', 'approval_records__reviewer')

        if user.role == Role.STUDENT:
            return base_qs.filter(student=user)
        elif user.role == Role.FACULTY:
            return base_qs.filter(
                models.Q(student__student_profile__advisor=user) |
                models.Q(student__department=user.department)
            ).distinct()
        elif user.role == Role.HOD:
            if user.is_superuser or user.department == 'Administration':
                return base_qs.all()
            return base_qs.filter(student__department=user.department)
        elif user.is_staff or user.is_superuser:
            return base_qs.all()

        return LeaveApplication.objects.none()


class ForwardLeaveApplicationView(APIView):
    """
    Faculty endorsement endpoint:
    POST /api/v1/applications/{application_id}/forward/
    - Status transitions from PENDING_FACULTY -> PENDING_HOD
    - Atomically creates immutable ApprovalRecord
    - Row-locked with select_for_update() inside transaction.atomic()
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, application_id):
        user = request.user
        if user.role != Role.FACULTY:
            return Response(
                {"detail": "Only faculty members can forward applications to HOD."},
                status=status.HTTP_403_FORBIDDEN
            )

        with transaction.atomic():
            app = LeaveApplication.objects.select_for_update().filter(application_id=application_id).first()
            if not app:
                return Response(
                    {"detail": "Leave application not found."},
                    status=status.HTTP_404_NOT_FOUND
                )

            # Authorization check: student's assigned advisor or department match
            has_advisor = hasattr(app.student, 'student_profile') and app.student.student_profile.advisor is not None
            if has_advisor:
                is_authorized = (app.student.student_profile.advisor == user)
            else:
                is_authorized = (app.student.department == user.department)

            if not is_authorized:
                return Response(
                    {"detail": "You are not authorized to review this student's leave application."},
                    status=status.HTTP_403_FORBIDDEN
                )

            if app.status != LeaveStatus.PENDING_FACULTY:
                return Response(
                    {"detail": f"Application cannot be forwarded from current status: {app.status}."},
                    status=status.HTTP_400_BAD_REQUEST
                )

            remarks = (request.data.get('remarks') or '').strip()
            if not remarks:
                remarks = "Attendance and academic standing verified. Recommended and forwarded to HOD."

            app.status = LeaveStatus.PENDING_HOD
            app.faculty_reviewer = user
            app.decision_timestamp = timezone.now()
            app.save(update_fields=['status', 'faculty_reviewer', 'decision_timestamp', 'updated_at'])

            ApprovalRecord.objects.create(
                leave_application=app,
                reviewer=user,
                reviewer_role=ReviewerRole.FACULTY,
                decision=Decision.FORWARDED_TO_HOD,
                remarks=remarks
            )

            notify_faculty_forwarded(app, user, remarks)

            serializer = LeaveApplicationSerializer(app, context={'request': request})
            return Response(serializer.data, status=status.HTTP_200_OK)


class ApproveLeaveApplicationView(APIView):
    """
    HOD final approval endpoint:
    POST /api/v1/applications/{application_id}/approve/
    - Status transitions from PENDING_HOD -> HOD_APPROVED
    - Cannot approve application that is still PENDING_FACULTY
    - Atomically creates immutable ApprovalRecord
    - Row-locked with select_for_update() inside transaction.atomic()
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, application_id):
        user = request.user
        if user.role != Role.HOD:
            return Response(
                {"detail": "Only Head of Department (HOD) can grant final leave approval."},
                status=status.HTTP_403_FORBIDDEN
            )

        with transaction.atomic():
            app = LeaveApplication.objects.select_for_update().filter(application_id=application_id).first()
            if not app:
                return Response(
                    {"detail": "Leave application not found."},
                    status=status.HTTP_404_NOT_FOUND
                )

            # Department authorization check
            is_authorized = (
                user.is_superuser or
                user.department == 'Administration' or
                app.student.department == user.department
            )
            if not is_authorized:
                return Response(
                    {"detail": "You are not authorized to approve applications for this department."},
                    status=status.HTTP_403_FORBIDDEN
                )

            # Workflow state validation: must be forwarded by faculty first
            if app.status == LeaveStatus.PENDING_FACULTY:
                return Response(
                    {"detail": "Application must be reviewed and forwarded by a faculty advisor before HOD approval."},
                    status=status.HTTP_400_BAD_REQUEST
                )

            if app.status != LeaveStatus.PENDING_HOD:
                return Response(
                    {"detail": f"Application cannot be approved from current status: {app.status}."},
                    status=status.HTTP_400_BAD_REQUEST
                )

            remarks = (request.data.get('remarks') or '').strip()
            if not remarks:
                remarks = "Final departmental clearance granted. Digital pass authorized for gate exit."

            app.status = LeaveStatus.HOD_APPROVED
            app.hod_reviewer = user
            app.decision_timestamp = timezone.now()
            app.save(update_fields=['status', 'hod_reviewer', 'decision_timestamp', 'updated_at'])

            ApprovalRecord.objects.create(
                leave_application=app,
                reviewer=user,
                reviewer_role=ReviewerRole.HOD,
                decision=Decision.HOD_APPROVED,
                remarks=remarks
            )

            notify_hod_approved(app, user, remarks)

            serializer = LeaveApplicationSerializer(app, context={'request': request})
            return Response(serializer.data, status=status.HTTP_200_OK)


class RejectLeaveApplicationView(APIView):
    """
    Rejection endpoint for Faculty or HOD:
    POST /api/v1/applications/{application_id}/reject/
    - Requires mandatory non-empty remarks/reason
    - Faculty can reject PENDING_FACULTY applications
    - HOD can reject PENDING_HOD applications
    - Atomically creates immutable ApprovalRecord and sets status to REJECTED
    - Row-locked with select_for_update() inside transaction.atomic()
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, application_id):
        user = request.user
        if user.role not in [Role.FACULTY, Role.HOD]:
            return Response(
                {"detail": "Only faculty advisors and HODs can reject leave applications."},
                status=status.HTTP_403_FORBIDDEN
            )

        remarks = (request.data.get('remarks') or request.data.get('reason') or '').strip()
        if not remarks:
            return Response(
                {"detail": "Rejection remarks are mandatory."},
                status=status.HTTP_400_BAD_REQUEST
            )

        with transaction.atomic():
            app = LeaveApplication.objects.select_for_update().filter(application_id=application_id).first()
            if not app:
                return Response(
                    {"detail": "Leave application not found."},
                    status=status.HTTP_404_NOT_FOUND
                )

            if user.role == Role.FACULTY:
                has_advisor = hasattr(app.student, 'student_profile') and app.student.student_profile.advisor is not None
                if has_advisor:
                    is_authorized = (app.student.student_profile.advisor == user)
                else:
                    is_authorized = (app.student.department == user.department)

                if not is_authorized:
                    return Response(
                        {"detail": "You are not authorized to review this student's leave application."},
                        status=status.HTTP_403_FORBIDDEN
                    )

                if app.status != LeaveStatus.PENDING_FACULTY:
                    return Response(
                        {"detail": f"Application cannot be rejected from status: {app.status}."},
                        status=status.HTTP_400_BAD_REQUEST
                    )

                app.status = LeaveStatus.REJECTED
                app.faculty_reviewer = user
                app.rejection_reason = remarks
                app.decision_timestamp = timezone.now()
                app.save(update_fields=['status', 'faculty_reviewer', 'rejection_reason', 'decision_timestamp', 'updated_at'])

                ApprovalRecord.objects.create(
                    leave_application=app,
                    reviewer=user,
                    reviewer_role=ReviewerRole.FACULTY,
                    decision=Decision.REJECTED,
                    remarks=remarks
                )

                notify_faculty_rejected(app, user, remarks)

            elif user.role == Role.HOD:
                is_authorized = (
                    user.is_superuser or
                    user.department == 'Administration' or
                    app.student.department == user.department
                )
                if not is_authorized:
                    return Response(
                        {"detail": "You are not authorized to reject applications for this department."},
                        status=status.HTTP_403_FORBIDDEN
                    )

                if app.status != LeaveStatus.PENDING_HOD:
                    return Response(
                        {"detail": f"Application cannot be rejected from status: {app.status}."},
                        status=status.HTTP_400_BAD_REQUEST
                    )

                app.status = LeaveStatus.REJECTED
                app.hod_reviewer = user
                app.rejection_reason = remarks
                app.decision_timestamp = timezone.now()
                app.save(update_fields=['status', 'hod_reviewer', 'rejection_reason', 'decision_timestamp', 'updated_at'])

                ApprovalRecord.objects.create(
                    leave_application=app,
                    reviewer=user,
                    reviewer_role=ReviewerRole.HOD,
                    decision=Decision.REJECTED,
                    remarks=remarks
                )

                notify_hod_rejected(app, user, remarks)

            serializer = LeaveApplicationSerializer(app, context={'request': request})
            return Response(serializer.data, status=status.HTTP_200_OK)
