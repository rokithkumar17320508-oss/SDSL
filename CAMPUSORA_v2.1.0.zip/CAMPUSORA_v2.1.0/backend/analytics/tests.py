"""
Automated Test Suite for CAMPUSORA Day 9 Analytics Dashboard.
Verifies role-based data segregation for Faculty, HOD, Security, and Student roles.
"""

from datetime import date, timedelta
from django.test import TestCase
from django.utils import timezone
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient
from rest_framework import status

from accounts.models import Role, StudentProfile, FacultyProfile
from leaves.models import LeaveApplication, LeaveType, LeaveStatus
from passes.models import GatePass, GateEvent, GateType, PassStatus, EventType, VerificationOutcome
from passes.utils import derive_pass_token, hash_token

User = get_user_model()


class AnalyticsDashboardTests(TestCase):
    def setUp(self):
        self.client = APIClient()

        # 1. Faculty (CSE)
        self.faculty_cse = User.objects.create_user(
            username='fac_cse',
            password='Password123!',
            role=Role.FACULTY,
            department='Computer Science & Engineering'
        )
        self.faculty_profile = FacultyProfile.objects.create(
            user=self.faculty_cse,
            employee_id='EMP-CSE-99',
            department='Computer Science & Engineering'
        )

        # 2. HOD (CSE)
        self.hod_cse = User.objects.create_user(
            username='hod_cse',
            password='Password123!',
            role=Role.HOD,
            department='Computer Science & Engineering'
        )

        # 3. HOD (ECE - Different Department)
        self.hod_ece = User.objects.create_user(
            username='hod_ece',
            password='Password123!',
            role=Role.HOD,
            department='Electronics & Communication Engineering'
        )

        # 4. Security Officer
        self.security = User.objects.create_user(
            username='sec_terminal',
            password='Password123!',
            role=Role.SECURITY,
            assigned_gate='College Main Gate'
        )

        # 5. Students
        # Student 1: CSE
        self.student_cse = User.objects.create_user(
            username='student_cse',
            password='Password123!',
            role=Role.STUDENT,
            department='Computer Science & Engineering'
        )
        self.sp_cse = StudentProfile.objects.create(
            user=self.student_cse,
            registration_number='2024CSE999',
            department='Computer Science & Engineering',
            advisor=self.faculty_cse
        )

        # Student 2: ECE
        self.student_ece = User.objects.create_user(
            username='student_ece',
            password='Password123!',
            role=Role.STUDENT,
            department='Electronics & Communication Engineering'
        )
        self.sp_ece = StudentProfile.objects.create(
            user=self.student_ece,
            registration_number='2024ECE999',
            department='Electronics & Communication Engineering'
        )

        # Seed sample data:
        # CSE: 2 applications (1 Approved/Used, 1 Pending Faculty)
        today = timezone.localdate()
        self.app_cse_1 = LeaveApplication.objects.create(
            student=self.student_cse,
            leave_type=LeaveType.HOSTEL_OUTPASS,
            start_date=today,
            end_date=today + timedelta(days=2),
            reason='Conference',
            status=LeaveStatus.HOD_APPROVED
        )
        self.pass_cse = GatePass.objects.create(
            leave_application=self.app_cse_1,
            gate_type=GateType.COLLEGE_MAIN_GATE,
            valid_from=timezone.now() - timedelta(hours=2),
            valid_until=timezone.now() + timedelta(days=2),
            status=PassStatus.USED,
            exit_recorded_at=timezone.now() - timedelta(hours=1)
        )
        GateEvent.objects.create(
            gate_pass=self.pass_cse,
            student=self.student_cse,
            security_officer=self.security,
            gate_type='College Main Gate',
            event_type=EventType.EXIT,
            verification_outcome=VerificationOutcome.SUCCESS
        )

        self.app_cse_2 = LeaveApplication.objects.create(
            student=self.student_cse,
            leave_type=LeaveType.REGULAR_LEAVE,
            start_date=today + timedelta(days=5),
            end_date=today + timedelta(days=6),
            reason='Personal',
            status=LeaveStatus.PENDING_FACULTY
        )

        # ECE: 1 application (Pending HOD)
        self.app_ece_1 = LeaveApplication.objects.create(
            student=self.student_ece,
            leave_type=LeaveType.DAY_PASS,
            start_date=today + timedelta(days=1),
            end_date=today + timedelta(days=1),
            reason='Medical',
            status=LeaveStatus.PENDING_HOD
        )

    def test_anonymous_rejected(self):
        """Anonymous requests to /api/v1/analytics/overview/ are rejected (401)."""
        res = self.client.get('/api/v1/analytics/overview/')
        self.assertEqual(res.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_security_officer_analytics_scope(self):
        """Security officer sees operational gate data, outside students, daily movements."""
        self.client.force_authenticate(user=self.security)
        res = self.client.get('/api/v1/analytics/overview/')
        self.assertEqual(res.status_code, status.HTTP_200_OK)

        data = res.data
        self.assertEqual(data['user_role'], Role.SECURITY)
        self.assertEqual(data['off_campus']['students_outside'], 1)
        self.assertEqual(data['off_campus']['students_returned'], 0)
        self.assertIn('daily_stats', data)
        self.assertIn('monthly_stats', data)
        self.assertIn('gate_breakdown', data)
        self.assertIn('College Main Gate', data['gate_breakdown'])
        self.assertEqual(data['gate_breakdown']['College Main Gate']['exits'], 1)

    def test_hod_departmental_scoping(self):
        """HOD CSE sees only CSE applications (2 total), not ECE applications."""
        self.client.force_authenticate(user=self.hod_cse)
        res = self.client.get('/api/v1/analytics/overview/')
        self.assertEqual(res.status_code, status.HTTP_200_OK)

        data = res.data
        self.assertEqual(data['applications']['total'], 2)
        self.assertEqual(data['applications']['approved'], 1)
        self.assertEqual(data['applications']['pending_faculty'], 1)
        self.assertEqual(data['applications']['pending_hod'], 0)
        self.assertEqual(data['off_campus']['students_outside'], 1)

        # Check ECE HOD sees only ECE
        self.client.force_authenticate(user=self.hod_ece)
        res_ece = self.client.get('/api/v1/analytics/overview/')
        self.assertEqual(res_ece.status_code, status.HTTP_200_OK)
        data_ece = res_ece.data
        self.assertEqual(data_ece['applications']['total'], 1)
        self.assertEqual(data_ece['applications']['pending_hod'], 1)
        self.assertEqual(data_ece['off_campus']['students_outside'], 0)

    def test_faculty_advisee_scoping(self):
        """Faculty sees only their advisees / department students."""
        self.client.force_authenticate(user=self.faculty_cse)
        res = self.client.get('/api/v1/analytics/overview/')
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertEqual(res.data['applications']['total'], 2)
