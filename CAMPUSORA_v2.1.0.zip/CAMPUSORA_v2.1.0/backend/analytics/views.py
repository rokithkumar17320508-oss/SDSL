"""
Analytics Views for CAMPUSORA.
Role-protected aggregations for leave volumes, approval velocity,
active off-campus students, curfew overdues, and gate movement trends.
"""

from datetime import timedelta
from django.utils import timezone
from django.db.models import Count, Q
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import permissions, status

from accounts.models import Role
from leaves.models import LeaveApplication, LeaveStatus, LeaveType
from passes.models import (
    GatePass,
    GateEvent,
    PassStatus,
    EventType,
    VerificationOutcome,
)


class AnalyticsOverviewView(APIView):
    """
    Role-protected consolidated metrics:
    GET /api/v1/analytics/overview/
    Returns:
    - Leave application counts (total, pending faculty, pending HOD, approved, rejected)
    - Off-campus status (students currently outside, returned, overdue)
    - Daily and monthly gate movement traffic (exits vs entries)
    - Scoped strictly by user role.
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        user = request.user
        now = timezone.now()
        today = timezone.localdate()

        # 1. Base QuerySets scoped by RBAC
        app_qs = LeaveApplication.objects.all()
        gp_qs = GatePass.objects.all()
        event_qs = GateEvent.objects.all()

        if user.role == Role.FACULTY:
            # Faculty sees advisees or students in same department
            app_qs = app_qs.filter(
                Q(student__student_profile__advisor=user) |
                Q(student__department=user.department)
            ).distinct()
            gp_qs = gp_qs.filter(
                Q(leave_application__student__student_profile__advisor=user) |
                Q(leave_application__student__department=user.department)
            ).distinct()
            event_qs = event_qs.filter(
                Q(student__student_profile__advisor=user) |
                Q(student__department=user.department)
            ).distinct()

        elif user.role == Role.HOD:
            # HOD sees department students
            if not (user.is_superuser or user.department == 'Administration'):
                app_qs = app_qs.filter(student__department=user.department)
                gp_qs = gp_qs.filter(leave_application__student__department=user.department)
                event_qs = event_qs.filter(student__department=user.department)

        elif user.role == Role.STUDENT:
            app_qs = app_qs.filter(student=user)
            gp_qs = gp_qs.filter(leave_application__student=user)
            event_qs = event_qs.filter(student=user)

        # Security, superuser, and staff see full operational gate data

        # 2. Leave Application Metrics
        total_apps = app_qs.count()
        pending_faculty = app_qs.filter(status=LeaveStatus.PENDING_FACULTY).count()
        pending_hod = app_qs.filter(status=LeaveStatus.PENDING_HOD).count()
        approved_apps = app_qs.filter(status=LeaveStatus.HOD_APPROVED).count()
        rejected_apps = app_qs.filter(status=LeaveStatus.REJECTED).count()

        # 3. Off-Campus & Curfew Overdue Metrics (Optimized with select_related)
        active_outside = gp_qs.filter(status=PassStatus.USED).select_related(
            'leave_application', 'leave_application__student', 'leave_application__student__student_profile'
        )
        students_outside_count = active_outside.count()
        students_returned_count = gp_qs.filter(status=PassStatus.RETURNED).count()

        overdue_count = 0
        overdue_students_list = []
        for gp in active_outside:
            if gp.is_overdue:
                overdue_count += 1
                st = gp.leave_application.student
                sp = getattr(st, 'student_profile', None)
                deadline = gp.expected_return_time
                minutes_diff = int((now - deadline).total_seconds() / 60) if deadline else 0
                overdue_students_list.append({
                    'pass_id': gp.pass_id,
                    'student_name': st.get_full_name() or st.username,
                    'registration_number': sp.registration_number if sp else 'N/A',
                    'department': st.department,
                    'hostel_block': sp.hostel_block if sp else '',
                    'room_number': sp.room_number if sp else '',
                    'exit_recorded_at': gp.exit_recorded_at.isoformat() if gp.exit_recorded_at else None,
                    'expected_return_time': deadline.isoformat() if deadline else None,
                    'minutes_overdue': max(0, minutes_diff),
                })

        # 4. Daily Gate Statistics (Last 7 Days)
        daily_stats = []
        for i in range(6, -1, -1):
            d = today - timedelta(days=i)
            day_str = d.strftime('%Y-%m-%d')
            day_label = d.strftime('%a, %d %b')
            exits = event_qs.filter(
                event_type=EventType.EXIT,
                verification_outcome=VerificationOutcome.SUCCESS,
                timestamp__date=d
            ).count()
            entries = event_qs.filter(
                event_type=EventType.ENTRY,
                verification_outcome=VerificationOutcome.SUCCESS,
                timestamp__date=d
            ).count()
            daily_stats.append({
                'date': day_str,
                'label': day_label,
                'exits': exits,
                'entries': entries,
                'total_movements': exits + entries,
            })

        # 5. Monthly Gate Movement Trends (Last 4 Months)
        monthly_stats = []
        for m_offset in range(3, -1, -1):
            target_month = (today.month - m_offset)
            target_year = today.year
            while target_month <= 0:
                target_month += 12
                target_year -= 1

            m_exits = event_qs.filter(
                event_type=EventType.EXIT,
                verification_outcome=VerificationOutcome.SUCCESS,
                timestamp__year=target_year,
                timestamp__month=target_month
            ).count()
            m_entries = event_qs.filter(
                event_type=EventType.ENTRY,
                verification_outcome=VerificationOutcome.SUCCESS,
                timestamp__year=target_year,
                timestamp__month=target_month
            ).count()
            monthly_stats.append({
                'year': target_year,
                'month': target_month,
                'month_name': timezone.datetime(target_year, target_month, 1).strftime('%B %Y'),
                'exits': m_exits,
                'entries': m_entries,
            })

        # 6. Leave Category Distribution (Single aggregated query)
        leave_dist = {c.value: 0 for c in LeaveType}
        grouped_leave_counts = app_qs.values('leave_type').annotate(count=Count('id'))
        for item in grouped_leave_counts:
            lt = item.get('leave_type')
            if lt in leave_dist:
                leave_dist[lt] = item['count']

        # 7. Checkpoint Gate Breakdown
        gate_counts = {}
        gate_events_grouped = event_qs.filter(
            verification_outcome=VerificationOutcome.SUCCESS
        ).values('gate_type', 'event_type').annotate(count=Count('id'))

        for g in gate_events_grouped:
            g_name = g['gate_type'] or 'Unspecified Gate'
            if g_name not in gate_counts:
                gate_counts[g_name] = {'exits': 0, 'entries': 0}
            if g['event_type'] == EventType.EXIT:
                gate_counts[g_name]['exits'] += g['count']
            elif g['event_type'] == EventType.ENTRY:
                gate_counts[g_name]['entries'] += g['count']

        return Response({
            'timestamp': now.isoformat(),
            'user_role': user.role,
            'scope': user.department if user.role in [Role.FACULTY, Role.HOD] else 'All Campus',
            'applications': {
                'total': total_apps,
                'pending_faculty': pending_faculty,
                'pending_hod': pending_hod,
                'approved': approved_apps,
                'rejected': rejected_apps,
                'approval_rate': round((approved_apps / total_apps * 100), 1) if total_apps > 0 else 0.0,
            },
            'off_campus': {
                'students_outside': students_outside_count,
                'students_returned': students_returned_count,
                'overdue_count': overdue_count,
                'overdue_students': overdue_students_list,
            },
            'daily_stats': daily_stats,
            'monthly_stats': monthly_stats,
            'leave_distribution': leave_dist,
            'gate_breakdown': gate_counts,
        }, status=status.HTTP_200_OK)
