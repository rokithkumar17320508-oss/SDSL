"""
URL Routing for CAMPUSORA Analytics and Department Management.
"""

from django.urls import path
from .views import AnalyticsOverviewView
from .section_views import (
    DepartmentSectionsOverviewView,
    DepartmentStudentDirectoryView,
    DepartmentStudentDetailView,
)

app_name = 'analytics'

urlpatterns = [
    path('overview/', AnalyticsOverviewView.as_view(), name='analytics-overview'),
    path('sections/', DepartmentSectionsOverviewView.as_view(), name='department-sections'),
    path('students/', DepartmentStudentDirectoryView.as_view(), name='department-students'),
    path('students/<int:student_id>/', DepartmentStudentDetailView.as_view(), name='department-student-detail'),
]
