"""
CAMPUSORA Analytics Package.
"""
