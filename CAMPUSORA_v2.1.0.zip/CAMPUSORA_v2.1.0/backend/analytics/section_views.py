"""
HOD Department, Section, and Student Directory Analytics Views for CAMPUSORA.
Provides PostgreSQL-backed aggregations for CSE sections (CSE-A, CSE-B, CSE-C, CSE-D),
paginated student leave directories, and individual student leave profiles.
Enforces strict department-level access control and IDOR protections.
"""

from datetime import date
from django.db.models import Q, Count
from django.contrib.auth import get_user_model
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import permissions, status
from rest_framework.exceptions import PermissionDenied, NotFound

from accounts.models import Role, StudentProfile
from leaves.models import LeaveApplication, LeaveStatus, LeaveType
from approvals.models import ApprovalRecord, ReviewerRole, Decision

User = get_user_model()


def normalize_section_label(sec):
    """Normalizes section label to format 'CSE-X'."""
    clean = str(sec).replace('CSE-', '').strip().upper()
    return f"CSE-{clean}" if clean else "CSE-A"


def calc_duration_days(start_date, end_date):
    """Calculates inclusive duration in days."""
    if not start_date or not end_date:
        return 1
    return max(1, (end_date - start_date).days + 1)


class DepartmentSectionsOverviewView(APIView):
    """
    GET /api/v1/analytics/sections/
    Returns aggregated live metrics for CSE sections: CSE-A, CSE-B, CSE-C, CSE-D.
    Strictly scoped to HOD or Faculty of the authorized department.
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        user = request.user

        # Security check: Students, Security, Warden are denied
        if user.role not in (Role.HOD, Role.FACULTY) and not user.is_staff and not user.is_superuser:
            raise PermissionDenied("Access restricted to Department HOD and Faculty officials.")

        # Determine target department
        dept = user.department or 'Computer Science & Engineering'
        if user.is_superuser or dept == 'Administration':
            dept = request.query_params.get('department', 'Computer Science & Engineering')

        year = int(request.query_params.get('year', 1))

        # Expected sections for First Year CSE
        section_codes = ['A', 'B', 'C', 'D']
        sections_data = []

        total_dept_students = 0
        total_dept_apps = 0
        total_dept_pending = 0
        total_dept_approved = 0
        total_dept_rejected = 0

        for code in section_codes:
            section_label = f"CSE-{code}"
            # Match both 'A' and 'CSE-A'
            students_qs = User.objects.filter(
                role=Role.STUDENT,
                department=dept,
                student_profile__section__in=[code, section_label],
                student_profile__year=year
            )
            student_count = students_qs.count()

            # Query all applications for students in this section
            apps_qs = LeaveApplication.objects.filter(student__in=students_qs)
            total_apps = apps_qs.count()
            pending_apps = apps_qs.filter(
                status__in=[LeaveStatus.PENDING_FACULTY, LeaveStatus.PENDING_HOD]
            ).count()
            approved_apps = apps_qs.filter(status=LeaveStatus.HOD_APPROVED).count()
            rejected_apps = apps_qs.filter(status=LeaveStatus.REJECTED).count()

            total_dept_students += student_count
            total_dept_apps += total_apps
            total_dept_pending += pending_apps
            total_dept_approved += approved_apps
            total_dept_rejected += rejected_apps

            sections_data.append({
                "section": section_label,
                "section_code": code,
                "year": year,
                "total_students": student_count,
                "total_applications": total_apps,
                "pending_applications": pending_apps,
                "approved_applications": approved_apps,
                "rejected_applications": rejected_apps,
            })

        return Response({
            "department": dept,
            "year": year,
            "total_students": total_dept_students,
            "total_applications": total_dept_apps,
            "total_pending": total_dept_pending,
            "total_approved": total_dept_approved,
            "total_rejected": total_dept_rejected,
            "sections": sections_data,
        }, status=status.HTTP_200_OK)


class DepartmentStudentDirectoryView(APIView):
    """
    GET /api/v1/analytics/students/
    Paginated student directory with search, section filter, and leave statistics.
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        user = request.user

        # Access Control: Only HOD, Faculty, or Admin
        if user.role not in (Role.HOD, Role.FACULTY) and not user.is_staff and not user.is_superuser:
            raise PermissionDenied("Access restricted to Department Leadership and Faculty.")

        dept = user.department or 'Computer Science & Engineering'
        if user.is_superuser or dept == 'Administration':
            dept = request.query_params.get('department', 'Computer Science & Engineering')

        # Base student query restricted to authorized department
        students_qs = User.objects.filter(
            role=Role.STUDENT,
            department=dept
        ).select_related('student_profile')

        # Faculty Restriction: Restrict faculty strictly to their assigned sections / advisees
        if user.role == Role.FACULTY and not user.is_staff and not user.is_superuser:
            advisee_sections = list(
                StudentProfile.objects.filter(advisor=user)
                .values_list('section', flat=True)
                .distinct()
            )
            allowed_secs = []
            for s in advisee_sections:
                clean = s.replace('CSE-', '').strip().upper()
                allowed_secs.extend([clean, f"CSE-{clean}"])

            if allowed_secs:
                students_qs = students_qs.filter(
                    Q(student_profile__advisor=user) |
                    Q(student_profile__section__in=allowed_secs)
                )
            else:
                students_qs = students_qs.filter(student_profile__advisor=user)

        # Section filter (e.g. 'CSE-C', 'C', or 'all')
        section_param = request.query_params.get('section', '').strip().upper()
        if section_param and section_param != 'ALL':
            clean_sec = section_param.replace('CSE-', '')
            students_qs = students_qs.filter(
                student_profile__section__in=[clean_sec, f"CSE-{clean_sec}"]
            )

        # Year filter (default 1 for First Year CSE Directory)
        year_param = request.query_params.get('year', '1')
        if year_param and year_param.upper() != 'ALL':
            try:
                students_qs = students_qs.filter(student_profile__year=int(year_param))
            except ValueError:
                pass

        # Search query across full name, username, and registration number
        search_query = request.query_params.get('search', '').strip()
        if search_query:
            students_qs = students_qs.filter(
                Q(first_name__icontains=search_query) |
                Q(last_name__icontains=search_query) |
                Q(username__icontains=search_query) |
                Q(student_profile__registration_number__icontains=search_query)
            )

        # Prefetch applications for efficient calculation of leave days and counts
        student_list = list(students_qs)
        student_ids = [s.id for s in student_list]

        # Fetch applications for these students
        apps = LeaveApplication.objects.filter(student_id__in=student_ids)
        apps_by_student = {}
        for app in apps:
            apps_by_student.setdefault(app.student_id, []).append(app)

        # Assemble student summary rows
        records = []
        for s in student_list:
            sp = getattr(s, 'student_profile', None)
            reg_no = sp.registration_number if sp else 'N/A'
            sec_val = sp.section if sp else 'A'
            year_val = sp.year if sp else 1
            sec_label = normalize_section_label(sec_val)

            s_apps = apps_by_student.get(s.id, [])
            total_apps = len(s_apps)
            approved_apps = [a for a in s_apps if a.status == LeaveStatus.HOD_APPROVED]
            pending_apps = [a for a in s_apps if a.status in (LeaveStatus.PENDING_FACULTY, LeaveStatus.PENDING_HOD)]
            rejected_apps = [a for a in s_apps if a.status == LeaveStatus.REJECTED]

            # Calculate total approved leave days accurately: sum((end_date - start_date) + 1)
            approved_days = sum(calc_duration_days(a.start_date, a.end_date) for a in approved_apps)

            # Determine student residence type
            is_hosteler = bool(sp and sp.hostel_block)
            student_type = f"Hosteler ({sp.hostel_block})" if is_hosteler else "Day Scholar"

            records.append({
                "id": s.id,
                "name": s.get_full_name() or s.username,
                "username": s.username,
                "registration_number": reg_no,
                "department": s.department,
                "year": year_val,
                "section": sec_label,
                "year_and_section": f"Year {year_val} • {sec_label}",
                "student_type": student_type,
                "is_hosteler": is_hosteler,
                "hostel_block": sp.hostel_block if sp else "",
                "room_number": sp.room_number if sp else "",
                "total_applications": total_apps,
                "approved_applications": len(approved_apps),
                "approved_leave_days": approved_days,
                "pending_applications": len(pending_apps),
                "rejected_applications": len(rejected_apps),
            })

        # Sorting logic
        ordering = request.query_params.get('ordering', 'reg_no').lower()
        if ordering == 'name':
            records.sort(key=lambda x: x['name'].lower())
        elif ordering == '-name':
            records.sort(key=lambda x: x['name'].lower(), reverse=True)
        elif ordering == 'reg_no':
            records.sort(key=lambda x: x['registration_number'])
        elif ordering == '-reg_no':
            records.sort(key=lambda x: x['registration_number'], reverse=True)
        elif ordering == 'total_leaves' or ordering == '-total_leaves':
            records.sort(key=lambda x: x['total_applications'], reverse=ordering.startswith('-'))
        elif ordering == 'approved_days' or ordering == '-approved_days':
            records.sort(key=lambda x: x['approved_leave_days'], reverse=ordering.startswith('-'))
        elif ordering == 'pending' or ordering == '-pending':
            records.sort(key=lambda x: x['pending_applications'], reverse=ordering.startswith('-'))
        else:
            records.sort(key=lambda x: x['registration_number'])

        # Pagination
        total_count = len(records)
        try:
            page = max(1, int(request.query_params.get('page', 1)))
        except ValueError:
            page = 1
        try:
            page_size = min(100, max(1, int(request.query_params.get('page_size', 20))))
        except ValueError:
            page_size = 20

        start_idx = (page - 1) * page_size
        end_idx = start_idx + page_size
        paged_records = records[start_idx:end_idx]
        total_pages = max(1, (total_count + page_size - 1) // page_size)

        return Response({
            "count": total_count,
            "total_pages": total_pages,
            "current_page": page,
            "page_size": page_size,
            "results": paged_records,
        }, status=status.HTTP_200_OK)


class DepartmentStudentDetailView(APIView):
    """
    GET /api/v1/analytics/students/<int:student_id>/
    Returns comprehensive profile and detailed leave breakdown for an individual student.
    Enforces strict IDOR protections:
    - HOD can only view students in their own department.
    - Students can only view their own record.
    - Security personnel cannot access student directory details.
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, student_id):
        user = request.user

        # Fetch target student
        try:
            student = User.objects.select_related('student_profile').get(id=student_id, role=Role.STUDENT)
        except User.DoesNotExist:
            raise NotFound("Student record not found.")

        # IDOR Protection & Role Boundaries
        if user.role == Role.STUDENT:
            if user.id != student.id:
                raise PermissionDenied("Students may view only their own leave profile.")

        elif user.role == Role.HOD:
            # HOD can only inspect students within authorized department
            if not user.is_superuser and user.department != 'Administration':
                if student.department != user.department:
                    # Return 404 to prevent enumeration of other departments
                    raise NotFound("Student record not found in your department.")

        elif user.role == Role.FACULTY:
            # Faculty can view only their own advisees or students in their assigned sections
            if not user.is_superuser and user.department != 'Administration':
                if student.department != user.department:
                    raise NotFound("Student record not found in your assigned department.")
                
                is_advisee = hasattr(student, 'student_profile') and student.student_profile.advisor_id == user.id
                advisee_sections = list(
                    StudentProfile.objects.filter(advisor=user)
                    .values_list('section', flat=True)
                    .distinct()
                )
                allowed_secs = []
                for s in advisee_sections:
                    clean = s.replace('CSE-', '').strip().upper()
                    allowed_secs.extend([clean, f"CSE-{clean}"])

                student_sec = student.student_profile.section if hasattr(student, 'student_profile') else None
                if not is_advisee and (not student_sec or student_sec not in allowed_secs):
                    raise PermissionDenied("Faculty members may access records only for their assigned class sections or advisees.")

        elif user.role == Role.SECURITY or user.role == Role.WARDEN:
            raise PermissionDenied("Security checkpoint personnel are not authorized to inspect student academic directories.")

        sp = getattr(student, 'student_profile', None)
        sec_val = sp.section if sp else 'A'
        sec_label = normalize_section_label(sec_val)
        is_hosteler = bool(sp and sp.hostel_block)

        # Fetch applications and related approval records
        applications_qs = LeaveApplication.objects.filter(
            student=student
        ).prefetch_related('approval_records', 'approval_records__reviewer').order_by('-created_at')

        app_list = list(applications_qs)

        # Statistics computation
        total_apps = len(app_list)
        approved_apps = [a for a in app_list if a.status == LeaveStatus.HOD_APPROVED]
        rejected_apps = [a for a in app_list if a.status == LeaveStatus.REJECTED]
        pending_apps = [a for a in app_list if a.status in (LeaveStatus.PENDING_FACULTY, LeaveStatus.PENDING_HOD)]

        # Granular leave category categorization
        regular_apps = [a for a in app_list if a.leave_type == LeaveType.REGULAR_LEAVE]
        od_apps = [a for a in app_list if a.leave_type == LeaveType.ON_DUTY]
        hostel_apps = [a for a in app_list if a.leave_type == LeaveType.HOSTEL_OUTPASS]
        day_pass_apps = [a for a in app_list if a.leave_type == LeaveType.DAY_PASS]

        # Approved days calculations (Separate OD and Hostel Outpass from Ordinary Leave Days as requested)
        approved_regular_days = sum(calc_duration_days(a.start_date, a.end_date) for a in regular_apps if a.status == LeaveStatus.HOD_APPROVED)
        approved_od_days = sum(calc_duration_days(a.start_date, a.end_date) for a in od_apps if a.status == LeaveStatus.HOD_APPROVED)
        approved_hostel_days = sum(calc_duration_days(a.start_date, a.end_date) for a in hostel_apps if a.status == LeaveStatus.HOD_APPROVED)
        approved_day_pass_days = len([a for a in day_pass_apps if a.status == LeaveStatus.HOD_APPROVED])

        # Ordinary approved leave days (Regular leave + Day pass)
        ordinary_approved_days = approved_regular_days + approved_day_pass_days
        total_approved_days = ordinary_approved_days + approved_od_days + approved_hostel_days

        # Classify reasons into medical and personal
        medical_keywords = ['medical', 'fever', 'hospital', 'doctor', 'clinic', 'health', 'sick', 'dental']
        medical_count = sum(1 for a in app_list if any(k in a.reason.lower() for k in medical_keywords))
        personal_count = max(0, len(regular_apps) - medical_count)

        # Assemble application history objects
        history_data = []
        for a in app_list:
            duration = calc_duration_days(a.start_date, a.end_date)
            
            # Extract Faculty recommendation
            faculty_rec = None
            for rec in a.approval_records.all():
                if rec.reviewer_role == ReviewerRole.FACULTY:
                    faculty_rec = {
                        "decision": rec.decision,
                        "decision_display": rec.get_decision_display(),
                        "remarks": rec.remarks,
                        "reviewer_name": rec.reviewer.get_full_name() or rec.reviewer.username,
                        "timestamp": rec.timestamp,
                    }
                    break

            # Extract HOD decision
            hod_dec = None
            for rec in a.approval_records.all():
                if rec.reviewer_role == ReviewerRole.HOD:
                    hod_dec = {
                        "decision": rec.decision,
                        "decision_display": rec.get_decision_display(),
                        "remarks": rec.remarks,
                        "reviewer_name": rec.reviewer.get_full_name() or rec.reviewer.username,
                        "timestamp": rec.timestamp,
                    }
                    break

            history_data.append({
                "id": a.id,
                "application_id": a.application_id,
                "submission_date": a.created_at.strftime('%Y-%m-%d'),
                "created_at": a.created_at,
                "leave_type": a.leave_type,
                "start_date": a.start_date.strftime('%Y-%m-%d'),
                "end_date": a.end_date.strftime('%Y-%m-%d'),
                "requested_duration": duration,
                "duration_days": duration,
                "reason": a.reason,
                "status": a.status,
                "rejection_reason": a.rejection_reason,
                "faculty_recommendation": faculty_rec,
                "hod_decision": hod_dec,
            })

        advisor_name = sp.advisor.get_full_name() if (sp and sp.advisor) else "Faculty Advisor"

        return Response({
            "student_information": {
                "id": student.id,
                "name": student.get_full_name() or student.username,
                "username": student.username,
                "register_number": sp.registration_number if sp else "N/A",
                "department": student.department,
                "year": sp.year if sp else 1,
                "section": sec_label,
                "student_type": f"Hosteler ({sp.hostel_block})" if is_hosteler else "Day Scholar",
                "is_hosteler": is_hosteler,
                "hostel_block": sp.hostel_block if sp else "",
                "room_number": sp.room_number if sp else "",
                "email": student.email,
                "phone_number": student.phone_number,
                "emergency_contact": sp.emergency_contact if sp else "",
                "parent_name": sp.parent_name if sp else "",
                "parent_phone": sp.parent_phone if sp else "",
                "parent_email": sp.parent_email if sp else "",
                "advisor_name": advisor_name,
                "photo_url": f"https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=256&h=256",
            },
            "leave_statistics": {
                "total_applications": total_apps,
                "approved_applications": len(approved_apps),
                "rejected_applications": len(rejected_apps),
                "pending_applications": len(pending_apps),
                "total_approved_leave_days": ordinary_approved_days,
                "all_inclusive_approved_days": total_approved_days,
                "medical_leave_count": medical_count,
                "personal_leave_count": personal_count,
                "regular_leave_count": len(regular_apps),
                "regular_leave_days": approved_regular_days,
                "od_count": len(od_apps),
                "od_days": approved_od_days,
                "hostel_leave_count": len(hostel_apps),
                "hostel_leave_days": approved_hostel_days,
                "day_pass_count": len(day_pass_apps),
            },
            "leave_history": history_data,
        }, status=status.HTTP_200_OK)
