"""
Automated Tests for HOD Section Directory, Student Profiles, and IDOR Security Boundaries.
Validates live database calculations, search, pagination, and role-based permissions.
"""

from datetime import date, timedelta
from django.test import TestCase
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient
from rest_framework import status

from accounts.models import Role, StudentProfile, FacultyProfile
from leaves.models import LeaveApplication, LeaveType, LeaveStatus
from approvals.models import ApprovalRecord, ReviewerRole, Decision

User = get_user_model()


class DepartmentSectionAnalyticsTestCase(TestCase):
    """
    Tests for /api/v1/analytics/sections/, /students/, and /students/<id>/.
    """

    def setUp(self):
        self.client = APIClient()
        today = date.today()

        # 1. HOD User (CSE)
        self.hod_cse = User.objects.create_user(
            username='hod_test_cse',
            email='hod.cse@test.edu',
            password='Password123!',
            first_name='Rajesh',
            last_name='Mehra',
            role=Role.HOD,
            department='Computer Science & Engineering',
        )

        # 2. HOD User (Mechanical - for IDOR test)
        self.hod_mech = User.objects.create_user(
            username='hod_test_mech',
            email='hod.mech@test.edu',
            password='Password123!',
            first_name='Sunil',
            last_name='Kumar',
            role=Role.HOD,
            department='Mechanical Engineering',
        )

        # 3. Security User
        self.security_user = User.objects.create_user(
            username='sec_test',
            email='security@test.edu',
            password='Password123!',
            role=Role.SECURITY,
            assigned_gate='College Main Gate',
        )

        # 4. Faculty User (Assigned to Section A)
        self.faculty_a = User.objects.create_user(
            username='faculty_test_a',
            email='faculty.a@test.edu',
            password='Password123!',
            first_name='Anita',
            last_name='Verma',
            role=Role.FACULTY,
            department='Computer Science & Engineering',
        )

        # 5. CSE Students across Section A and C
        self.student_a1 = User.objects.create_user(
            username='student_a1',
            email='student.a1@test.edu',
            password='Password123!',
            first_name='Aarav',
            last_name='Sharma',
            role=Role.STUDENT,
            department='Computer Science & Engineering',
        )
        StudentProfile.objects.create(
            user=self.student_a1,
            registration_number='2026CSE001',
            department='Computer Science & Engineering',
            year=1,
            section='A',
            hostel_block='BH-1',
            room_number='BH-1, Room 101',
            advisor=self.faculty_a,
        )

        self.student_c1 = User.objects.create_user(
            username='student_c1',
            email='student.c1@test.edu',
            password='Password123!',
            first_name='Ananya',
            last_name='Iyer',
            role=Role.STUDENT,
            department='Computer Science & Engineering',
        )
        StudentProfile.objects.create(
            user=self.student_c1,
            registration_number='2026CSE121',
            department='Computer Science & Engineering',
            year=1,
            section='C',
            hostel_block='',
            room_number='Day Scholar',
        )

        # 5. Mechanical Student (for cross-department boundary testing)
        self.student_mech = User.objects.create_user(
            username='student_mech1',
            email='student.mech@test.edu',
            password='Password123!',
            first_name='Karthik',
            last_name='Rao',
            role=Role.STUDENT,
            department='Mechanical Engineering',
        )
        StudentProfile.objects.create(
            user=self.student_mech,
            registration_number='2026ME001',
            department='Mechanical Engineering',
            year=1,
            section='A',
            hostel_block='BH-2',
            room_number='BH-2, Room 202',
        )

        # 6. Sample Applications for student_c1 (Section C)
        # Regular Leave (Approved, 3 days)
        self.app_c1 = LeaveApplication.objects.create(
            application_id='APP-TEST-C01',
            student=self.student_c1,
            leave_type=LeaveType.REGULAR_LEAVE,
            start_date=today,
            end_date=today + timedelta(days=2),
            reason='Fever and doctor prescribed medical rest.',
            status=LeaveStatus.HOD_APPROVED,
        )

        # On-Duty (Approved, 2 days)
        self.app_c2 = LeaveApplication.objects.create(
            application_id='APP-TEST-C02',
            student=self.student_c1,
            leave_type=LeaveType.ON_DUTY,
            start_date=today + timedelta(days=5),
            end_date=today + timedelta(days=6),
            reason='IEEE State Hackathon presentation.',
            status=LeaveStatus.HOD_APPROVED,
        )

        # Pending Application
        self.app_c3 = LeaveApplication.objects.create(
            application_id='APP-TEST-C03',
            student=self.student_c1,
            leave_type=LeaveType.DAY_PASS,
            start_date=today + timedelta(days=8),
            end_date=today + timedelta(days=8),
            reason='Passport document verification.',
            status=LeaveStatus.PENDING_HOD,
        )

    def test_department_sections_overview_as_hod(self):
        """HOD receives accurate live section metrics for their department."""
        self.client.force_authenticate(user=self.hod_cse)
        response = self.client.get('/api/v1/analytics/sections/')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['department'], 'Computer Science & Engineering')
        self.assertEqual(len(response.data['sections']), 4)

        # Check section C stats
        sec_c = next(s for s in response.data['sections'] if s['section'] == 'CSE-C')
        self.assertEqual(sec_c['total_students'], 1)
        self.assertEqual(sec_c['total_applications'], 3)
        self.assertEqual(sec_c['approved_applications'], 2)
        self.assertEqual(sec_c['pending_applications'], 1)

    def test_student_directory_filtering_and_search(self):
        """Directory correctly filters by section and searches by name or reg no."""
        self.client.force_authenticate(user=self.hod_cse)

        # Filter by section C
        res = self.client.get('/api/v1/analytics/students/?section=CSE-C')
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertEqual(res.data['count'], 1)
        student = res.data['results'][0]
        self.assertEqual(student['registration_number'], '2026CSE121')
        self.assertEqual(student['total_applications'], 3)
        self.assertEqual(student['approved_applications'], 2)
        # Approved leave days calculation: 3 days of regular leave + 2 days of OD = 5 days total
        self.assertEqual(student['approved_leave_days'], 5)

        # Search by registration number
        res_search = self.client.get('/api/v1/analytics/students/?search=2026CSE001')
        self.assertEqual(res_search.status_code, status.HTTP_200_OK)
        self.assertEqual(res_search.data['count'], 1)
        self.assertEqual(res_search.data['results'][0]['username'], 'student_a1')

        # Search by student name
        res_name = self.client.get('/api/v1/analytics/students/?search=Ananya')
        self.assertEqual(res_name.status_code, status.HTTP_200_OK)
        self.assertEqual(res_name.data['count'], 1)
        self.assertEqual(res_name.data['results'][0]['registration_number'], '2026CSE121')

    def test_student_detail_profile_and_history(self):
        """Detailed student endpoint separates OD, hostel, and regular leave statistics."""
        self.client.force_authenticate(user=self.hod_cse)
        res = self.client.get(f'/api/v1/analytics/students/{self.student_c1.id}/')
        self.assertEqual(res.status_code, status.HTTP_200_OK)

        info = res.data['student_information']
        self.assertEqual(info['register_number'], '2026CSE121')
        self.assertEqual(info['section'], 'CSE-C')
        self.assertEqual(info['student_type'], 'Day Scholar')

        stats = res.data['leave_statistics']
        self.assertEqual(stats['total_applications'], 3)
        self.assertEqual(stats['approved_applications'], 2)
        self.assertEqual(stats['pending_applications'], 1)
        self.assertEqual(stats['regular_leave_days'], 3)
        self.assertEqual(stats['od_count'], 1)
        self.assertEqual(stats['od_days'], 2)
        self.assertEqual(stats['total_approved_leave_days'], 3)  # Ordinary leaves
        self.assertEqual(stats['all_inclusive_approved_days'], 5)  # Ordinary + OD

        # History list
        history = res.data['leave_history']
        self.assertEqual(len(history), 3)

    def test_security_idor_protection_cross_department(self):
        """HOD cannot view students from other departments (IDOR defense returns 404)."""
        self.client.force_authenticate(user=self.hod_cse)
        # Attempt to access student in Mechanical Engineering
        res = self.client.get(f'/api/v1/analytics/students/{self.student_mech.id}/')
        self.assertEqual(res.status_code, status.HTTP_404_NOT_FOUND)

    def test_security_role_forbidden_access(self):
        """Security checkpoint officers cannot browse the departmental student directory."""
        self.client.force_authenticate(user=self.security_user)
        res_sections = self.client.get('/api/v1/analytics/sections/')
        self.assertEqual(res_sections.status_code, status.HTTP_403_FORBIDDEN)

        res_students = self.client.get('/api/v1/analytics/students/')
        self.assertEqual(res_students.status_code, status.HTTP_403_FORBIDDEN)

        res_detail = self.client.get(f'/api/v1/analytics/students/{self.student_c1.id}/')
        self.assertEqual(res_detail.status_code, status.HTTP_403_FORBIDDEN)

    def test_student_cannot_view_other_student(self):
        """Student cannot view another student's detailed profile."""
        self.client.force_authenticate(user=self.student_a1)
        # Student A1 attempts to inspect Student C1
        res = self.client.get(f'/api/v1/analytics/students/{self.student_c1.id}/')
        self.assertEqual(res.status_code, status.HTTP_403_FORBIDDEN)

        # Student A1 can inspect their own record
        res_self = self.client.get(f'/api/v1/analytics/students/{self.student_a1.id}/')
        self.assertEqual(res_self.status_code, status.HTTP_200_OK)

    def test_unauthenticated_requests_strictly_rejected(self):
        """Unauthenticated requests must be rejected with HTTP 401 across all analytics endpoints."""
        self.client.force_authenticate(user=None)
        
        # Test sections overview
        res_sec = self.client.get('/api/v1/analytics/sections/')
        self.assertEqual(res_sec.status_code, status.HTTP_401_UNAUTHORIZED)

        # Test student directory
        res_dir = self.client.get('/api/v1/analytics/students/')
        self.assertEqual(res_dir.status_code, status.HTTP_401_UNAUTHORIZED)

        # Test individual student profile
        res_detail = self.client.get(f'/api/v1/analytics/students/{self.student_c1.id}/')
        self.assertEqual(res_detail.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_faculty_assigned_section_isolation(self):
        """Faculty advisor assigned to Section A cannot access student profile of Section C student."""
        self.client.force_authenticate(user=self.faculty_a)

        # Query directory: Faculty A only sees Section A advisees, Section C students excluded
        res_dir = self.client.get('/api/v1/analytics/students/')
        self.assertEqual(res_dir.status_code, status.HTTP_200_OK)
        returned_regs = [s['registration_number'] for s in res_dir.data['results']]
        self.assertIn('2026CSE001', returned_regs)
        self.assertNotIn('2026CSE121', returned_regs)

        # Direct access to Section A student succeeds
        res_a = self.client.get(f'/api/v1/analytics/students/{self.student_a1.id}/')
        self.assertEqual(res_a.status_code, status.HTTP_200_OK)

        # Direct access to unassigned Section C student fails with 403 Forbidden
        res_c = self.client.get(f'/api/v1/analytics/students/{self.student_c1.id}/')
        self.assertEqual(res_c.status_code, status.HTTP_403_FORBIDDEN)

    def test_hod_department_tampering_prevented(self):
        """HOD cannot view other departments by tampering with the department query parameter."""
        self.client.force_authenticate(user=self.hod_mech)
        # Attempt to spoof department query param
        res = self.client.get('/api/v1/analytics/sections/?department=Computer+Science+%26+Engineering')
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        # The response must remain strictly scoped to user's assigned department
        self.assertEqual(res.data['department'], 'Mechanical Engineering')

    def test_student_role_escalation_to_sections_prevented(self):
        """Students attempting privilege escalation to HOD sections/directory are blocked."""
        self.client.force_authenticate(user=self.student_a1)

        res_sec = self.client.get('/api/v1/analytics/sections/')
        self.assertEqual(res_sec.status_code, status.HTTP_403_FORBIDDEN)

        res_dir = self.client.get('/api/v1/analytics/students/')
        self.assertEqual(res_dir.status_code, status.HTTP_403_FORBIDDEN)
