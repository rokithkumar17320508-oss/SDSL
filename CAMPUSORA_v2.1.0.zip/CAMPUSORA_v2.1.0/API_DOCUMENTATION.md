# CAMPUSORA — REST API Reference Manual
**Base URL:** `https://campusora.edu/api/v1` (Production) / `http://localhost:8000/api/v1` (Development)  
**API Version:** `v1`  
**Authentication Scheme:** Dual (HttpOnly Cookies `campusora_access_token` or Header `Authorization: Bearer <JWT>`)  
**Data Format:** JSON (`application/json`)  

---

## Standard Response Envelopes

### Success (200 / 201)
```json
{
  "message": "Operation completed successfully",
  "data": { ... }
}
```

### Error (400 / 401 / 403 / 404 / 429)
```json
{
  "detail": "Descriptive institutional policy violation or error message.",
  "outcome": "ERROR_CODE"
}
```

---

## 1. Authentication Endpoints (`/api/v1/auth/`)

### 1.1 User Login
- **Endpoint:** `POST /api/v1/auth/login/`
- **Rate Limit:** 15 req/min
- **Request Body:**
  ```json
  {
    "username": "arjun",
    "password": "StudentPassword123!"
  }
  ```
- **Response (200 OK):**
  Sets `campusora_access_token` and `campusora_refresh_token` HttpOnly cookies.
  ```json
  {
    "message": "Login successful",
    "user": {
      "id": 1,
      "username": "arjun",
      "name": "Arjun Sharma",
      "email": "arjun.sharma@campusora.edu",
      "role": "STUDENT",
      "department": "Computer Science & Engineering"
    },
    "access": "<sample_jwt_access_token>",
    "refresh": "<sample_jwt_refresh_token>"
  }
  ```

### 1.2 Token Refresh
- **Endpoint:** `POST /api/v1/auth/refresh/`
- **Request Body (Optional if cookie set):**
  ```json
  { "refresh": "<sample_jwt_refresh_token>" }
  ```
- **Response (200 OK):** Issues rotated access/refresh tokens and blacklists prior refresh token.

### 1.3 User Logout
- **Endpoint:** `POST /api/v1/auth/logout/`
- **Response (200 OK):** Blacklists active refresh token and clears HttpOnly session cookies.

### 1.4 Current User Profile
- **Endpoint:** `GET /api/v1/auth/me/`
- **Permission:** Authenticated
- **Response (200 OK):** User identity, role, department, and linked student/faculty/warden profile metadata.

---

## 2. Leave Management Endpoints (`/api/v1/leaves/`)

### 2.1 List Applications
- **Endpoint:** `GET /api/v1/leaves/`
- **Permission:** Authenticated (Role-filtered)
- **Response (200 OK):**
  ```json
  [
    {
      "id": 12,
      "application_id": "APP-5610",
      "student": 1,
      "student_name": "Arjun Sharma",
      "student_registration": "2024CSE1084",
      "department": "Computer Science & Engineering",
      "leave_type": "Day Pass",
      "start_date": "2026-11-20",
      "end_date": "2026-11-20",
      "reason": "Technical symposium participation at IIT.",
      "status": "HOD Approved",
      "created_at": "2026-11-19T06:15:00Z"
    }
  ]
  ```

### 2.2 Submit Leave Application
- **Endpoint:** `POST /api/v1/leaves/`
- **Permission:** Student Only
- **Request Body:**
  ```json
  {
    "leave_type": "Hostel Outpass",
    "start_date": "2026-11-21",
    "end_date": "2026-11-23",
    "reason": "Family engagement over the weekend."
  }
  ```
- **Response (201 Created):** Created leave application in `Pending Faculty Review` status.

### 2.3 Faculty Forward Application
- **Endpoint:** `POST /api/v1/leaves/{id}/forward/`
- **Permission:** Faculty Advisor / Same Department
- **Request Body:**
  ```json
  { "remarks": "Academic standing verified. Endorsed for HOD clearance." }
  ```
- **Response (200 OK):** Transitions status to `Pending HOD Review`.

### 2.4 HOD Approve Application
- **Endpoint:** `POST /api/v1/leaves/{id}/approve/`
- **Permission:** Head of Department (HOD)
- **Request Body:**
  ```json
  { "remarks": "Approved. Gate clearance pass authorized." }
  ```
- **Response (200 OK):** Transitions status to `HOD Approved` and automatically provisions `GatePass` record.

### 2.5 Reject Application
- **Endpoint:** `POST /api/v1/leaves/{id}/reject/`
- **Permission:** Faculty or HOD
- **Request Body:**
  ```json
  { "reason": "Attendance below required 75% threshold." }
  ```
- **Response (200 OK):** Transitions status to `Rejected`.

---

## 3. Cryptographic Gate Pass Endpoints (`/api/v1/gate-passes/`)

### 3.1 Get Active Student Gate Pass
- **Endpoint:** `GET /api/v1/gate-passes/active/`
- **Permission:** Student (Own pass)
- **Response (200 OK):**
  ```json
  {
    "pass_id": "GP-7323",
    "application_id": "APP-5610",
    "student_name": "Arjun Sharma",
    "student_registration": "2024CSE1084",
    "gate_type": "College Main Gate",
    "status": "ACTIVE",
    "valid_from": "2026-11-20T00:00:00Z",
    "valid_until": "2026-11-20T23:59:59Z",
    "raw_token": "CAMPUSORA:GP-7323:<SAMPLE_GATE_PASS_TOKEN>",
    "qr_code_image": "data:image/png;base64,iVBORw0KGgo..."
  }
  ```

### 3.2 Security Verify Departure (Inspection Only)
- **Endpoint:** `POST /api/v1/gate-passes/verify/`
- **Permission:** Security Personnel Only
- **Rate Limit:** 120 req/min
- **Request Body:**
  ```json
  { "token": "CAMPUSORA:GP-7323:<SAMPLE_GATE_PASS_TOKEN>" }
  ```
- **Response (200 OK):** Validates token hash, status, gate authorization, and returns student photo likeness. Does **not** consume pass.

### 3.3 Security Confirm Departure Exit
- **Endpoint:** `POST /api/v1/gate-passes/confirm-exit/`
- **Permission:** Security Personnel Only
- **Request Body:**
  ```json
  {
    "token": "CAMPUSORA:GP-7323:<SAMPLE_GATE_PASS_TOKEN>",
    "remarks": "Identity likeness verified; exiting on two-wheeler."
  }
  ```
- **Response (200 OK):** Row-locked state transition to `USED`, logs departure timestamp, creates `GateEvent(event_type=EXIT)`, and dispatches parent safety alerts.

### 3.4 Security Verify Return Entry
- **Endpoint:** `POST /api/v1/gate-passes/verify-return/`
- **Permission:** Security Personnel Only
- **Rate Limit:** 120 req/min
- **Request Body:**
  ```json
  { "token": "CAMPUSORA:GP-8507:<SAMPLE_GATE_PASS_TOKEN>" }
  ```
- **Response (200 OK):**
  ```json
  {
    "valid": true,
    "mode": "ENTRY",
    "pass_id": "GP-8507",
    "student": {
      "name": "Arjun Sharma",
      "registration_number": "2024CSE1084",
      "department": "Computer Science & Engineering"
    },
    "exit_recorded_at": "2026-11-17T03:57:15Z",
    "expected_return_time": "2026-11-18T21:00:00Z",
    "is_overdue": true,
    "photo_url": "/photos/students/arjun.jpg"
  }
  ```

### 3.5 Security Confirm Return Entry
- **Endpoint:** `POST /api/v1/gate-passes/confirm-return/`
- **Permission:** Security Personnel Only
- **Request Body:**
  ```json
  {
    "token": "CAMPUSORA:GP-8507:<SAMPLE_GATE_PASS_TOKEN>",
    "remarks": "Baggage checked, physical likeness verified, returning past curfew."
  }
  ```
- **Response (200 OK):** Row-locked transition to `RETURNED`, creates `GateEvent(event_type=ENTRY)`, and dispatches parent/warden return notifications.

### 3.6 Active Outside Students Registry
- **Endpoint:** `GET /api/v1/gate-passes/outside/?overdue=true`
- **Permission:** Security / HOD / Admin
- **Response (200 OK):** Lists all active off-campus students (`status == USED`), curfew deadlines, parent phone numbers, and minutes overdue.

---

## 4. Gate Events Audit Ledger (`/api/v1/gate-events/`)

### 4.1 Chronological Movement Ledger
- **Endpoint:** `GET /api/v1/gate-events/`
- **Permission:** Security / Admin
- **Response (200 OK):** Returns last 100 gate events with `event_type` (`EXIT` / `ENTRY`), outcome, officer name, and remarks.

---

## 5. Analytics Dashboard Endpoints (`/api/v1/analytics/`)

### 5.1 Institutional & Departmental Overview
- **Endpoint:** `GET /api/v1/analytics/overview/`
- **Permission:** Authenticated (Role-scoped: Faculty advisees, HOD department, Security gate traffic)
- **Response (200 OK):**
  ```json
  {
    "timestamp": "2026-11-19T13:30:00Z",
    "user_role": "HOD",
    "scope": "Computer Science & Engineering",
    "applications": {
      "total": 15,
      "pending_faculty": 0,
      "pending_hod": 0,
      "approved": 11,
      "rejected": 4,
      "approval_rate": 73.3
    },
    "off_campus": {
      "students_outside": 5,
      "students_returned": 2,
      "overdue_count": 0,
      "overdue_students": []
    },
    "daily_stats": [ ... ],
    "monthly_stats": [ ... ],
    "leave_distribution": {
      "Regular Leave": 3,
      "On-Duty": 2,
      "Day Pass": 6,
      "Hostel Outpass": 4
    },
    "gate_breakdown": {
      "College Main Gate": { "exits": 7, "entries": 2 }
    }
  }
  ```
